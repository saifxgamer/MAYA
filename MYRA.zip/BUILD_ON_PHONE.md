# Build MYRA on a phone / desktop

## 1. One-time setup

```sh
sh bootstrap.sh
```

If your SDK folder is not auto-detected:

```sh
sh bootstrap.sh --sdk /storage/emulated/0/Android/Sdk
```

This checks Java, writes `local.properties`, downloads Gradle 8.5, and runs the first build.
The first build downloads ~400 MB of dependencies. Slow is normal — do it on Wi-Fi.

## 2. Build the APK

```sh
sh gradlew assembleDebug
```

Output: `app/build/outputs/apk/debug/app-debug.apk`

Install it:

```sh
adb install -r app/build/outputs/apk/debug/app-debug.apk
```

Or copy the APK to the phone and tap it (enable "install from unknown sources").

## 3. Requirements checklist

| Need | Version |
| --- | --- |
| Java | **JDK 17** (required by Android Gradle Plugin 8.x) |
| Gradle | 8.5 (auto-downloaded by `bootstrap.sh`) |
| Android SDK Platform | android-34 |
| Android SDK Build-Tools | 34.x |

On AndroidIDE, use its bundled JDK 17 and install the SDK platform from its SDK Manager.
On Termux: `pkg install openjdk-17`.

## 4. Error fixes

**`Android Gradle plugin requires Java 17`**
Switch the JDK to 17 in the IDE, or lower the versions in `gradle.properties`:
```
agpVersion=7.4.2
kotlinVersion=1.8.10
```
and delete the `sourceCompatibility`/`jvmTarget` 17 lines in `app/build.gradle` (change both to `11`).

**`SDK location not found`**
`local.properties` is missing or wrong. Re-run `sh bootstrap.sh --sdk /full/path/to/Android/Sdk`.

**`Failed to find target with hash string 'android-34'`**
Install Android SDK Platform 34 in the IDE's SDK Manager.

**`OutOfMemoryError` / device hangs**
In `gradle.properties` change `-Xmx1536m` to `-Xmx1024m`, and set `org.gradle.parallel=false`.

**`Execution failed for task ':app:compileDebugKotlin'`**
Read the last error line — it names the file and line. `lint.abortOnError` is already `false`,
so lint warnings will not stop the build.

**`Duplicate class org.json`**
Do not add `org.json:json` as a dependency; `org.json` ships inside Android.

## 5. What was changed for mobile builds

- Removed `kotlin-kapt` and DataBinding (not used; both slow builds down and need extra jars).
- Removed unused dependencies: `constraintlayout`, `fragment-ktx`, `androidx.security:security-crypto`,
  `org.json:json`, explicit `lifecycle-runtime-ktx`, explicit `kotlinx-coroutines-core`.
- 10 libraries remain, all used by the code.
- `minifyEnabled false` for release so R8 does not exhaust device memory.
- `gradlew` does not require `gradle-wrapper.jar`; it locates or downloads Gradle itself.
- AGP and Kotlin versions are read from `gradle.properties`, so you can switch them in one place.
- `lint.abortOnError false` so lint notes never fail the build.

## 6. After installing

1. Open MYRA, go to Settings, paste your Gemini API key.
2. Grant microphone permission.
3. Enable "MYRA Assistant" in Android Settings → Accessibility (required for app control).
4. Grant "Display over other apps" for the floating orb.
5. Double-tap the power button for the orb overlay.
