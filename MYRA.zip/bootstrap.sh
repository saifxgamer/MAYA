#!/usr/bin/env sh
#
# One-time setup for building MYRA on a phone (AndroidIDE / Termux) or desktop.
# Checks Java, writes local.properties with your SDK path, then builds the APK.
#
#   sh bootstrap.sh
#   sh bootstrap.sh --sdk /storage/emulated/0/Android/Sdk
#

APP_HOME=$(cd "$(dirname "$0")" && pwd)
cd "$APP_HOME"

SDK_DIR=""
if [ "$1" = "--sdk" ]; then SDK_DIR="$2"; fi

echo "=== 1/4  Java check ==="
if [ -n "$JAVA_HOME" ] && [ -x "$JAVA_HOME/bin/java" ]; then
    JAVA_BIN="$JAVA_HOME/bin/java"
elif command -v java >/dev/null 2>&1; then
    JAVA_BIN=$(command -v java)
else
    echo "ERROR: no Java found."
    echo "  AndroidIDE: use its built-in JDK 17 (Settings -> Java)."
    echo "  Termux:     pkg install openjdk-17"
    exit 1
fi
echo "java: $JAVA_BIN"
"$JAVA_BIN" -version 2>&1 | head -2

echo
echo "=== 2/4  Android SDK check ==="
if [ -z "$SDK_DIR" ]; then
    for c in "$ANDROID_HOME" "$ANDROID_SDK_ROOT" \
             "$HOME/Android/Sdk" "$HOME/android-sdk" \
             "/storage/emulated/0/Android/Sdk" \
             "/data/data/com.itsaky.androidide/files/home/sdk"
    do
        if [ -n "$c" ] && [ -d "$c" ]; then SDK_DIR="$c"; break; fi
    done
fi

if [ -z "$SDK_DIR" ] || [ ! -d "$SDK_DIR" ]; then
    echo "ERROR: Android SDK not found. Re-run with:  sh bootstrap.sh --sdk /path/to/sdk"
    exit 1
fi
echo "sdk: $SDK_DIR"

for pkg in "platforms/android-34" "build-tools"; do
    if [ ! -d "$SDK_DIR/$pkg" ]; then
        echo "WARNING: $SDK_DIR/$pkg is missing. Install it from your IDE SDK Manager."
    fi
done

printf 'sdk.dir=%s\n' "$SDK_DIR" > local.properties
echo "wrote local.properties"

echo
echo "=== 3/4  Warm up dependency cache (first run downloads a lot) ==="
sh gradlew --version || exit 1

echo
echo "=== 4/4  Build debug APK ==="
sh gradlew assembleDebug

APK="$APP_HOME/app/build/outputs/apk/debug/app-debug.apk"
if [ -f "$APK" ]; then
    echo
    echo "BUILD OK -> $APK"
else
    echo
    echo "BUILD FAILED. See the error above."
    exit 1
fi
