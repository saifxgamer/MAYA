package com.myra.assistant.social

import java.util.UUID

interface SocialAgentHost {
    fun isAccessibilityEnabled(): Boolean
    fun isAppInstalled(platform: SocialPlatform): Boolean
    fun hasShareHandler(platform: SocialPlatform): Boolean
    fun shareActivityClass(platform: SocialPlatform): String?
    fun launchApp(platform: SocialPlatform): Boolean
    fun sendShareIntent(platform: SocialPlatform, activityClass: String, media: PendingMedia): Boolean
    fun pendingMedia(): List<PendingMedia>
    fun currentTimeMs(): Long
    fun speak(message: String)
}

interface SocialAgentListener {
    fun onState(state: AgentState, task: SocialMediaTask)
    fun onOutcome(outcome: SocialOutcome)
}

class SocialMediaAgent(
    private val driver: ScreenDriver,
    private val host: SocialAgentHost,
    private val config: AgentConfig = AgentConfig(),
    private val clock: AgentClock = WallClock,
    private val log: AgentLog = NoopAgentLog
) {

    private var listener: SocialAgentListener? = null
    private var machine = TaskStateMachine()
    private var activeTask: SocialMediaTask? = null
    private var running = false

    val state: AgentState get() = machine.state
    val currentTask: SocialMediaTask? get() = activeTask

    /** True while a task is parked on an explicit publish confirmation. */
    val awaitingConfirmation: Boolean
        get() = activeTask?.status == TaskStatus.AWAITING_CONFIRMATION

    /** True while a task is parked waiting for the user to do something on screen. */
    val waitingForUser: Boolean
        get() = activeTask?.status == TaskStatus.WAITING_FOR_USER

    fun setListener(l: SocialAgentListener?) {
        listener = l
    }

    fun submit(request: SocialRequest): SocialOutcome = synchronized(this) {
        if (running) return SocialOutcome.Busy(activeTask?.taskId)

        // A task stopped for a user action continues where it stopped when the user speaks
        // again, instead of starting over and re-opening the picker the user just used.
        val waiting = activeTask
        if (waiting != null && waiting.status == TaskStatus.WAITING_FOR_USER &&
            waiting.platform == request.platform && waiting.action == request.action
        ) {
            running = true
            try {
                val merged = waiting.copy(
                    caption = request.caption ?: waiting.caption,
                    mediaRef = request.mediaRef ?: waiting.mediaRef,
                    mode = request.mode,
                    status = TaskStatus.RUNNING
                )
                return drive(merged)
            } finally {
                running = false
            }
        }

        if (activeTask?.status == TaskStatus.AWAITING_CONFIRMATION) {
            return SocialOutcome.Busy(activeTask?.taskId)
        }
        running = true
        try {
            val task = request.toTask()
            activeTask = task
            machine.reset()
            // drive() updates activeTask as it goes, so the finished task must not overwrite it.
            drive(task)
        } finally {
            running = false
        }
    }

    fun control(command: SocialCommand, taskId: String?): SocialOutcome = synchronized(this) {
        if (running) return SocialOutcome.Busy(activeTask?.taskId)
        val task = activeTask
        if (task == null || (taskId != null && taskId != task.taskId)) {
            return SocialOutcome.Finished(SocialResultCode.FAILED, "no matching task")
        }
        when (command) {
            SocialCommand.CANCEL -> {
                safeMove(AgentState.CANCELLED)
                activeTask = task.copy(status = TaskStatus.CANCELLED, confirmed = false)
                publish(SocialOutcome.Finished(SocialResultCode.CANCELLED))
            }

            SocialCommand.REJECT -> {
                safeMove(AgentState.CANCELLED)
                activeTask = task.copy(status = TaskStatus.REJECTED, confirmed = false)
                publish(SocialOutcome.Finished(SocialResultCode.REJECTED))
            }

            SocialCommand.STATUS -> publish(SocialOutcome.Finished(statusCode(task), "step=${task.currentStep}"))

            SocialCommand.RESUME -> {
                if (task.status != TaskStatus.WAITING_FOR_USER) {
                    return SocialOutcome.Finished(statusCode(task), "not waiting for the user")
                }
                running = true
                try {
                    drive(task.copy(status = TaskStatus.RUNNING))
                } finally {
                    running = false
                }
            }

            SocialCommand.CONFIRM -> {
                if (task.status != TaskStatus.AWAITING_CONFIRMATION) {
                    return SocialOutcome.Finished(statusCode(task), "nothing is waiting for confirmation")
                }
                running = true
                try {
                    drive(task.copy(status = TaskStatus.RUNNING, confirmed = true))
                } finally {
                    running = false
                }
            }
        }
    }

    /** Cancellation and completion are always allowed, even from a terminal state. */
    private fun safeMove(target: AgentState) {
        if (machine.state == target) return
        if (machine.isLegalTarget(target)) {
            machine.moveTo(target)
            return
        }
        machine.resynchronise()
        if (!machine.advanceTo(target)) {
            log.error("could not reach $target")
        }
    }

    private fun statusCode(task: SocialMediaTask): SocialResultCode = when (task.status) {
        TaskStatus.IDLE -> SocialResultCode.FAILED
        TaskStatus.RUNNING -> SocialResultCode.FAILED
        TaskStatus.AWAITING_CONFIRMATION -> SocialResultCode.AWAITING_CONFIRMATION
        TaskStatus.WAITING_FOR_USER -> SocialResultCode.USER_ACTION_REQUIRED
        TaskStatus.COMPLETED -> SocialResultCode.PUBLISHED
        TaskStatus.FAILED -> SocialResultCode.FAILED
        TaskStatus.CANCELLED -> SocialResultCode.CANCELLED
        TaskStatus.REJECTED -> SocialResultCode.REJECTED
    }

    private fun drive(task: SocialMediaTask): SocialOutcome {
        var current = task

        if (!host.isAccessibilityEnabled()) {
            return finish(current, SocialResultCode.ACCESSIBILITY_NOT_ENABLED)
        }
        if (!host.isAppInstalled(current.platform)) {
            return finish(current, SocialResultCode.APP_NOT_INSTALLED)
        }
        if (current.action == SocialAction.POST_TEXT && current.platform == SocialPlatform.INSTAGRAM) {
            return finish(current, SocialResultCode.UNSUPPORTED_ACTION, "Instagram has no text-only post")
        }

        val steps = SocialMediaPlan.stepsFor(current, host.hasShareHandler(current.platform))
        log.step("plan for ${current.platform}/${current.action}: ${steps.joinToString(">")}")

        // Media is only required when the plan hands a file to the app. The manual fallback
        // has the user pick inside the app, so an empty inbox is correct there.
        val needsInboxMedia = steps.contains(SocialStep.SHARE_MEDIA)
        val media = if (!needsInboxMedia) {
            null
        } else {
            when (val resolution = MediaResolver.resolve(
                current.mediaRef, host.pendingMedia(), host.currentTimeMs()
            )) {
                is MediaResolution.Resolved -> resolution.media
                is MediaResolution.Required -> return finish(current, SocialResultCode.MEDIA_REQUIRED)
                is MediaResolution.Rejected -> return finish(current, resolution.code, resolution.reason)
            }
        }

        var index = stepIndexOf(current, steps)
        while (index < steps.size) {
            val step = steps[index]
            current = current.copy(currentStep = step.name, status = TaskStatus.RUNNING)
            notifyState(current)

            when (val result = runStep(current, step, media)) {
                is StepResult.Gate -> {
                    current = result.task.copy(resumeStep = steps.getOrNull(index + 1)?.name.orEmpty())
                    activeTask = current
                    return publish(
                        SocialOutcome.AwaitingConfirmation(current.taskId, result.question, result.detail)
                    )
                }

                is StepResult.NeedUser -> {
                    current = result.task.copy(resumeStep = steps.getOrNull(index + 1)?.name.orEmpty())
                    activeTask = current
                    return publish(SocialOutcome.NeedsUser(current.taskId, result.code, result.instruction))
                }

                is StepResult.Done -> {
                    current = result.task
                    index++
                }

                is StepResult.Stop -> {
                    current = result.task
                    activeTask = current
                    return publish(result.outcome)
                }
            }
        }
        return finish(current, SocialResultCode.PUBLISHED)
    }

    private fun stepIndexOf(task: SocialMediaTask, steps: List<SocialStep>): Int {
        task.resumeStep.takeIf { it.isNotBlank() }?.let { resume ->
            val idx = steps.indexOfFirst { it.name == resume }
            if (idx >= 0) return idx
        }
        val name = task.currentStep
        if (name.isBlank()) return 0
        val idx = steps.indexOfFirst { it.name == name }
        return if (idx < 0) 0 else idx + 1
    }

    private fun runStep(
        task: SocialMediaTask,
        step: SocialStep,
        media: PendingMedia?
    ): StepResult {
        val allowed = task.packageAllowList

        // Guards run before every single action, not only before publishing.
        val guard = FlowGuards.check(driver.observe())
        if (guard is FlowGuards.GuardVerdict.Blocked) {
            return StepResult.NeedUser(
                task.copy(status = TaskStatus.WAITING_FOR_USER),
                guard.code,
                guard.message
            )
        }

        enterStepState(step)

        return try {
            when (step) {
                SocialStep.OPEN_APP -> openApp(task)
                SocialStep.SHARE_MEDIA -> shareMedia(task, media, allowed)
                SocialStep.OPEN_COMPOSER -> openComposer(task, allowed)
                SocialStep.TAP_CREATE -> tapCreate(task, allowed)
                SocialStep.TAP_OPTION -> tapOption(task, allowed)
                SocialStep.WAIT_FOR_USER_SELECT_MEDIA ->
                    StepResult.NeedUser(
                        task.copy(status = TaskStatus.WAITING_FOR_USER),
                        SocialResultCode.MEDIA_REQUIRED,
                        "Select the photo in the app, then say done"
                    )

                SocialStep.TAP_NEXT -> tapNext(task, allowed)
                SocialStep.TYPE_CAPTION -> typeCaption(task, allowed)
                SocialStep.TYPE_POST_TEXT -> typePostText(task, allowed)
                SocialStep.CONFIRM_PUBLISH -> confirmPublish(task, allowed)
                SocialStep.TAP_SHARE -> tapShare(task, allowed)
                SocialStep.TAP_STORY_TARGET -> tapStoryTarget(task, allowed)
                SocialStep.VERIFY_POST -> verifyPost(task, allowed)
            }
        } catch (t: IllegalStateTransitionException) {
            log.error("illegal transition at $step: ${t.message}")
            StepResult.Stop(task.copy(status = TaskStatus.FAILED), SocialOutcome.Finished(SocialResultCode.FAILED, "bad internal state at $step"))
        }
    }

    /**
     * Moves into the state a step needs. Steps do not inherit a half finished state from the
     * previous step: the machine is re-synchronised and then walked along a legal path, so a
     * step that needs EXECUTING_ACTION still passes through observe and validate first.
     */
    private fun enterStepState(step: SocialStep) {
        val target = stateFor(step)
        if (machine.isLegalTarget(target)) {
            machine.moveTo(target)
            return
        }
        if (machine.resynchronise()) log.step("re-synchronised before $step")
        if (!machine.advanceTo(target)) {
            log.error("no legal path to $target for $step")
        }
    }

    private fun openApp(task: SocialMediaTask): StepResult {
        if (!host.launchApp(task.platform)) {
            return StepResult.Stop(task.copy(status = TaskStatus.FAILED), SocialOutcome.Finished(SocialResultCode.APP_NOT_INSTALLED))
        }
        machine.moveTo(AgentState.WAITING_FOR_UI)
        clock.sleep(LAUNCH_SETTLE_MS)
        return StepResult.Done(task)
    }

    private fun shareMedia(task: SocialMediaTask, media: PendingMedia?, allowed: Set<String>): StepResult {
        if (media == null) {
            return StepResult.Stop(task.copy(status = TaskStatus.FAILED), SocialOutcome.Finished(SocialResultCode.MEDIA_REQUIRED))
        }
        val activityClass = host.shareActivityClass(task.platform)
            ?: return StepResult.Stop(
                task.copy(status = TaskStatus.FAILED),
                SocialOutcome.Finished(SocialResultCode.SHARE_TARGET_NOT_FOUND)
            )

        val windowStampBefore = driver.windowStamp()
        if (!host.sendShareIntent(task.platform, activityClass, media)) {
            return StepResult.Stop(
                task.copy(status = TaskStatus.FAILED),
                SocialOutcome.Finished(SocialResultCode.SHARE_TARGET_NOT_FOUND, "could not send media to $activityClass")
            )
        }

        val ok = waitForNewWindow(windowStampBefore, task, allowed)
        if (!ok) {
            return StepResult.Stop(
                task.copy(status = TaskStatus.FAILED),
                SocialOutcome.Finished(SocialResultCode.FAILED, "no new window from the app after sharing")
            )
        }
        return StepResult.Done(task)
    }

    private fun waitForNewWindow(before: Int, task: SocialMediaTask, allowed: Set<String>): Boolean {
        machine.moveTo(AgentState.WAITING_FOR_UI)
        val start = clock.nowMs()
        while (clock.elapsed(start) < config.newWindowTimeoutMs) {
            val observation = driver.observe()
            val fromApp = task.packageAllowList.any { observation.packageName.startsWith(it) }
            if (fromApp && Freshness.isNewerWindow(observation, before)) {
                return true
            }
            clock.sleep(NEW_WINDOW_POLL_MS)
        }
        return false
    }

    private fun openComposer(task: SocialMediaTask, allowed: Set<String>): StepResult {
        val executor = newExecutor()
        val outcome = executor.tap(
            FacebookSelectors.composerEntry,
            allowed,
            Expectation.Appears(listOf(FacebookSelectors.postTextField))
        )
        return if (outcome is TapOutcome.Success) StepResult.Done(task) else {
            StepResult.Stop(task.copy(status = TaskStatus.FAILED), SocialOutcome.Finished(SocialResultCode.FAILED, "could not open the composer"))
        }
    }

    private fun tapCreate(task: SocialMediaTask, allowed: Set<String>): StepResult {
        val executor = newExecutor()
        val outcome = executor.tap(InstagramSelectors.createButton, allowed, Expectation.ScreenChanges)
        return if (outcome is TapOutcome.Success) StepResult.Done(task) else {
            StepResult.Stop(task.copy(status = TaskStatus.FAILED), SocialOutcome.Finished(SocialResultCode.FAILED, "could not find the Create button"))
        }
    }

    private fun tapOption(task: SocialMediaTask, allowed: Set<String>): StepResult {
        val executor = newExecutor()
        val specs = InstagramSelectors.createOptionSpecs(task.action)
        for (spec in specs) {
            val found = executor.scrollUntilVisible(spec, allowed, ScrollDirection.DOWN)
            if (found !is TargetWait.Found) continue
            val outcome = executor.tap(found.spec, allowed, Expectation.ScreenChanges)
            if (outcome is TapOutcome.Success) return StepResult.Done(task)
        }
        return StepResult.NeedUser(
            task.copy(status = TaskStatus.WAITING_FOR_USER),
            SocialResultCode.MEDIA_REQUIRED,
            "Open the gallery yourself and pick the media"
        )
    }

    private fun tapNext(task: SocialMediaTask, allowed: Set<String>): StepResult {
        val executor = newExecutor()
        val specs = PlatformSelectors.nextSpecs(task.platform)
        val captionOrShare = when (task.platform) {
            SocialPlatform.INSTAGRAM -> listOf(InstagramSelectors.captionField, InstagramSelectors.shareFeed)
            SocialPlatform.FACEBOOK -> listOf(FacebookSelectors.postSettingsShare)
        }

        repeat(MAX_NEXT_TAPS) {
            val observation = driver.observe()
            val landed = TargetResolver.resolveAny(observation, captionOrShare, allowed)
            if (landed != null) return StepResult.Done(task)

            val nextSpec = specs.firstOrNull { spec ->
                TargetResolver.resolve(observation, spec, allowed).elementOrNull != null
            } ?: return StepResult.Done(task)

            val outcome = executor.tap(
                nextSpec,
                allowed,
                Expectation.AnyOf(
                    listOf(
                        Expectation.Appears(captionOrShare),
                        Expectation.ScreenChanges
                    )
                ),
                requireStableBounds = false
            )
            if (outcome is TapOutcome.Failed) {
                log.warn("next tap failed: ${outcome.detail}")
                return StepResult.Done(task)
            }
        }
        return StepResult.Done(task)
    }

    private fun typeCaption(task: SocialMediaTask, allowed: Set<String>): StepResult {
        val caption = task.caption?.trim().orEmpty()
        if (caption.isEmpty()) return StepResult.Done(task)
        val spec = when (task.platform) {
            SocialPlatform.INSTAGRAM -> InstagramSelectors.captionField
            SocialPlatform.FACEBOOK -> FacebookSelectors.captionField
        }
        val text = TextInputExecutor(driver, newExecutor(), log)
        return when (val outcome = text.setText(spec, allowed, caption)) {
            is TextOutcome.Success -> StepResult.Done(task)
            is TextOutcome.Failed -> StepResult.Stop(
                task.copy(status = TaskStatus.FAILED),
                SocialOutcome.Finished(SocialResultCode.FAILED, "caption not typed: ${outcome.reason}")
            )
        }
    }

    private fun typePostText(task: SocialMediaTask, allowed: Set<String>): StepResult {
        val body = task.caption?.trim().orEmpty()
        if (body.isEmpty()) {
            return StepResult.Stop(
                task.copy(status = TaskStatus.FAILED),
                SocialOutcome.Finished(SocialResultCode.FAILED, "nothing to post")
            )
        }
        val text = TextInputExecutor(driver, newExecutor(), log)
        val outcome = text.setText(FacebookSelectors.postTextField, allowed, body)
        return when (outcome) {
            is TextOutcome.Success -> StepResult.Done(task)
            is TextOutcome.Failed -> StepResult.Stop(
                task.copy(status = TaskStatus.FAILED),
                SocialOutcome.Finished(SocialResultCode.FAILED, "text not typed: ${outcome.reason}")
            )
        }
    }

    private fun confirmPublish(task: SocialMediaTask, allowed: Set<String>): StepResult {
        val observation = driver.observe()
        val guard = FlowGuards.check(observation)
        if (guard is FlowGuards.GuardVerdict.Blocked) {
            return StepResult.NeedUser(task.copy(status = TaskStatus.WAITING_FOR_USER), guard.code, guard.message)
        }

        val publishSpecs = if (task.action == SocialAction.POST_STORY) {
            PlatformSelectors.storyTargetSpecs(task.platform)
        } else {
            PlatformSelectors.shareSpecs(task.platform)
        }
        val found = TargetResolver.resolveUniqueAny(observation, publishSpecs, allowed)
        if (found is ResolveResult.NotFound) {
            return StepResult.Stop(
                task.copy(status = TaskStatus.FAILED),
                SocialOutcome.Finished(SocialResultCode.FAILED, "publish control is not on screen")
            )
        }
        if (found is ResolveResult.Ambiguous) {
            // Two publish controls are on screen, so it is not safe to guess which one to press.
            return StepResult.NeedUser(
                task.copy(status = TaskStatus.WAITING_FOR_USER),
                SocialResultCode.USER_ACTION_REQUIRED,
                "There is more than one Share button on screen. Close the extra sheet, then say done."
            )
        }
        val publishElement = (found as ResolveResult.Resolved).element
        if (!publishElement.enabled || !publishElement.visible) {
            return StepResult.Stop(
                task.copy(status = TaskStatus.FAILED),
                SocialOutcome.Finished(SocialResultCode.FAILED, "publish control is disabled")
            )
        }

        safeMove(AgentState.WAITING_FOR_CONFIRMATION)
        if (task.mode == SocialMode.DRAFT) {
            log.step("draft mode, stopping before publish")
            host.speak(SocialResultCode.DRAFT_READY.speakable)
            return StepResult.Stop(
                task.copy(status = TaskStatus.COMPLETED),
                SocialOutcome.Finished(SocialResultCode.DRAFT_READY)
            )
        }

        val question = task.question()
        host.speak(question)
        return StepResult.Gate(
            task.copy(status = TaskStatus.AWAITING_CONFIRMATION),
            question,
            "control=${publishElement.elementId}"
        )
    }

    private fun tapShare(task: SocialMediaTask, allowed: Set<String>): StepResult {
        if (!task.confirmed) {
            log.error("publish refused: task was not confirmed")
            return StepResult.Stop(
                task.copy(status = TaskStatus.FAILED),
                SocialOutcome.Finished(SocialResultCode.SECURITY_BLOCKED, "publish needs an explicit yes")
            )
        }
        return publishTap(
            task,
            allowed,
            PlatformSelectors.shareSpecs(task.platform),
            "Share"
        )
    }

    private fun tapStoryTarget(task: SocialMediaTask, allowed: Set<String>): StepResult {
        if (!task.confirmed) {
            return StepResult.Stop(
                task.copy(status = TaskStatus.FAILED),
                SocialOutcome.Finished(SocialResultCode.SECURITY_BLOCKED, "publish needs an explicit yes")
            )
        }
        return publishTap(
            task,
            allowed,
            PlatformSelectors.storyTargetSpecs(task.platform),
            "Your stories"
        )
    }

    /**
     * Publishes with a single tap. The control is re-resolved immediately before the tap so a
     * screen that changed after the confirmation is not published through blindly, and it is
     * never retried: a blind second tap could post twice.
     */
    private fun publishTap(
        task: SocialMediaTask,
        allowed: Set<String>,
        specs: List<TargetSpec>,
        what: String
    ): StepResult {
        val resolved = TargetResolver.resolveUniqueAny(driver.observe(), specs, allowed)
        if (resolved !is ResolveResult.Resolved) {
            return StepResult.Stop(
                task.copy(status = TaskStatus.FAILED),
                SocialOutcome.Finished(
                    SocialResultCode.POSTED_NO,
                    "$what is no longer on screen, so nothing was published"
                )
            )
        }
        val publishSpec = resolved.spec ?: specs.first()

        val indicators = PlatformSelectors.postedIndicatorSpecs(task.platform)
        val outcome = newExecutor().tap(
            publishSpec,
            allowed,
            Expectation.AnyOf(
                listOf(
                    Expectation.Appears(indicators, requireEnabled = false),
                    Expectation.TargetGone
                )
            ),
            goneSpec = publishSpec,
            maxRetries = 1
        )
        return when (outcome) {
            is TapOutcome.Success -> StepResult.Done(task)
            is TapOutcome.Failed -> StepResult.Stop(
                task.copy(status = TaskStatus.FAILED),
                SocialOutcome.Finished(SocialResultCode.POSTED_UNKNOWN, "tapped $what but could not confirm")
            )
        }
    }

    private fun verifyPost(task: SocialMediaTask, allowed: Set<String>): StepResult {
        safeMove(AgentState.VERIFYING)
        val indicators = PlatformSelectors.postedIndicatorSpecs(task.platform)
        val shareSpecs = PlatformSelectors.shareSpecs(task.platform)
        val result = newExecutor().awaitExpectation(
            Expectation.Appears(indicators, requireEnabled = false),
            allowed,
            goneSpec = shareSpecs.first(),
            alreadyReacted = false,
            timeoutMs = config.publishVerifyTimeoutMs
        )
        if (result is UiActionExecutor.ExpectationResult.Satisfied) {
            return StepResult.Done(task.copy(status = TaskStatus.COMPLETED))
        }

        val publishGone = TargetResolver.resolveUniqueAny(driver.observe(), shareSpecs, allowed) !is ResolveResult.Resolved
        val detail = if (publishGone) "" else "the publish control is still on screen"
        return StepResult.Stop(
            task.copy(status = TaskStatus.COMPLETED),
            SocialOutcome.Finished(SocialResultCode.SUBMITTED_UNVERIFIED, detail)
        )
    }

    private fun newExecutor() = UiActionExecutor(driver, config, clock, log)

    private fun finish(task: SocialMediaTask, code: SocialResultCode, detail: String = ""): SocialOutcome {
        val status = when (code) {
            SocialResultCode.PUBLISHED, SocialResultCode.SUBMITTED_UNVERIFIED, SocialResultCode.DRAFT_READY ->
                TaskStatus.COMPLETED

            SocialResultCode.CANCELLED -> TaskStatus.CANCELLED
            SocialResultCode.REJECTED -> TaskStatus.REJECTED
            SocialResultCode.AWAITING_CONFIRMATION -> TaskStatus.AWAITING_CONFIRMATION
            SocialResultCode.USER_ACTION_REQUIRED -> TaskStatus.WAITING_FOR_USER
            else -> TaskStatus.FAILED
        }
        val done = task.copy(status = status)
        if (status == TaskStatus.COMPLETED) safeMove(AgentState.COMPLETED)
        if (status == TaskStatus.FAILED) safeMove(AgentState.FAILED)
        activeTask = done
        return publish(SocialOutcome.Finished(code, detail))
    }

    private fun publish(outcome: SocialOutcome): SocialOutcome {
        listener?.onOutcome(outcome)
        return outcome
    }

    private fun notifyState(task: SocialMediaTask) {
        listener?.onState(machine.state, task)
    }

    private fun stateFor(step: SocialStep): AgentState = when (step) {
        SocialStep.OPEN_APP -> AgentState.OPENING_APP
        SocialStep.SHARE_MEDIA -> AgentState.EXECUTING_ACTION
        SocialStep.OPEN_COMPOSER, SocialStep.TAP_CREATE, SocialStep.TAP_OPTION, SocialStep.TAP_NEXT ->
            AgentState.EXECUTING_ACTION

        SocialStep.WAIT_FOR_USER_SELECT_MEDIA -> AgentState.WAITING_FOR_USER
        SocialStep.TYPE_CAPTION, SocialStep.TYPE_POST_TEXT -> AgentState.EXECUTING_ACTION
        SocialStep.CONFIRM_PUBLISH -> AgentState.VERIFYING
        SocialStep.TAP_SHARE, SocialStep.TAP_STORY_TARGET -> AgentState.EXECUTING_ACTION
        SocialStep.VERIFY_POST -> AgentState.VERIFYING
    }

    private sealed class StepResult {
        data class Done(val task: SocialMediaTask) : StepResult()
        data class Gate(val task: SocialMediaTask, val question: String, val detail: String) : StepResult()
        data class NeedUser(
            val task: SocialMediaTask,
            val code: SocialResultCode,
            val instruction: String
        ) : StepResult()

        data class Stop(val task: SocialMediaTask, val outcome: SocialOutcome) : StepResult()
    }

    companion object {
        private const val LAUNCH_SETTLE_MS = 2_200L
        private const val NEW_WINDOW_POLL_MS = 300L
        private const val MAX_NEXT_TAPS = 4
    }
}

data class SocialRequest(
    val platform: SocialPlatform,
    val action: SocialAction,
    val mediaRef: String? = null,
    val caption: String? = null,
    val mode: SocialMode = SocialMode.PUBLISH,
    val targetAccount: String? = null
) {
    fun toTask(id: String = UUID.randomUUID().toString()): SocialMediaTask = SocialMediaTask(
        taskId = id,
        platform = platform,
        action = action,
        mediaRef = mediaRef,
        caption = caption,
        mode = mode,
        targetAccount = targetAccount
    )
}

enum class SocialCommand { CONFIRM, REJECT, RESUME, CANCEL, STATUS }
