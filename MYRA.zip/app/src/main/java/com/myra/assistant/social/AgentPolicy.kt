package com.myra.assistant.social

data class AgentConfig(
    val minUiSettleMs: Long = 350,
    val maxUiSettleMs: Long = 3_500,
    val actionTimeoutMs: Long = 8_000,
    val targetResolutionTimeoutMs: Long = 5_000,
    val maxRetries: Int = 2,
    val publishTapMaxRetries: Int = 1,
    val publishVerifyTimeoutMs: Long = 14_000,
    val newWindowTimeoutMs: Long = 8_000,
    val maxSwipesPerScroll: Int = 6,
    val maxObservationsRetained: Int = 40
)

sealed class Expectation {
    object Nothing : Expectation()
    object ScreenChanges : Expectation()
    object TargetGone : Expectation()

    data class Appears(
        val specs: List<TargetSpec>,
        val requireEnabled: Boolean = false
    ) : Expectation()

    data class AnyOf(val options: List<Expectation>) : Expectation() {
        init {
            require(options.size >= 2) { "AnyOf needs at least two options" }
        }
    }
}

interface AgentClock {
    fun nowMs(): Long
    fun sleep(ms: Long)
    fun elapsed(startMs: Long): Long = nowMs() - startMs
}

object WallClock : AgentClock {
    override fun nowMs(): Long = System.currentTimeMillis()
    override fun sleep(ms: Long) {
        if (ms > 0) {
            try {
                Thread.sleep(ms)
            } catch (_: InterruptedException) {
                Thread.currentThread().interrupt()
            }
        }
    }
}

interface AgentLog {
    fun step(message: String) {}
    fun warn(message: String) {}
    fun error(message: String) {}
    fun resolution(spec: TargetSpec, result: ResolveResult) {}
    fun observation(observation: ScreenObservation) {}
    fun action(message: String) {}
}

object NoopAgentLog : AgentLog

class RecordingAgentLog : AgentLog {
    val steps = mutableListOf<String>()
    val warnings = mutableListOf<String>()
    val actions = mutableListOf<String>()

    override fun step(message: String) {
        steps += message
    }

    override fun warn(message: String) {
        warnings += message
    }

    override fun error(message: String) {
        warnings += "ERROR $message"
    }

    override fun action(message: String) {
        actions += message
    }
}
