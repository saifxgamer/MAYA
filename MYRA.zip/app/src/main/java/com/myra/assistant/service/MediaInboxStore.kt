package com.myra.assistant.service

import android.content.Context
import android.net.Uri
import android.util.Log
import androidx.core.content.FileProvider
import com.myra.assistant.social.MediaResolver
import com.myra.assistant.social.PendingMedia
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.UUID

class MediaInboxStore(context: Context) {

    private val appContext = context.applicationContext
    private val prefs = appContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    private val inboxDir: File
        get() = File(appContext.filesDir, INBOX_DIR).apply { if (!exists()) mkdirs() }

    private val authority: String get() = "${appContext.packageName}.fileprovider"

    fun isSupported(mime: String?): Boolean =
        mime != null && MediaResolver.isSupportedMime(mime.lowercase())

    fun store(displayName: String, mimeType: String, bytes: ByteArray): PendingMedia? {
        if (!MediaResolver.isSupportedMime(mimeType)) return null
        if (bytes.isEmpty()) return null

        val id = UUID.randomUUID().toString()
        val extension = extensionFor(mimeType, displayName)
        val file = File(inboxDir, "$id$extension")
        return try {
            file.outputStream().use { it.write(bytes) }
            val entry = PendingMedia(
                id = id,
                uri = uriFor(file).toString(),
                mimeType = mimeType,
                sizeBytes = file.length(),
                receivedAtMs = System.currentTimeMillis()
            )
            if (entry.sizeBytes <= 0L) {
                file.delete()
                null
            } else {
                insertAtTop(entry)
                trim()
                entry
            }
        } catch (e: Exception) {
            Log.e(TAG, "could not store shared media: ${e.message}")
            file.delete()
            null
        }
    }

    /**
     * Copies a uri into the inbox without ever holding the whole file in memory, so a large
     * video cannot crash MYRA. A size cap stops an unbounded copy.
     */
    fun storeFromUri(uri: Uri, mimeType: String?): PendingMedia? {
        if (!isSupported(mimeType)) return null
        val resolverMime = (mimeType ?: appContext.contentResolver.getType(uri).orEmpty())
            .ifBlank { return null }
        if (!MediaResolver.isSupportedMime(resolverMime)) return null

        val id = UUID.randomUUID().toString()
        val file = File(inboxDir, "$id${extensionFor(resolverMime, "")}")
        var written = 0L
        return try {
            appContext.contentResolver.openInputStream(uri)?.use { input ->
                file.outputStream().use { out ->
                    val buffer = ByteArray(COPY_BUFFER)
                    while (true) {
                        val read = input.read(buffer)
                        if (read <= 0) break
                        written += read
                        if (written > MAX_BYTES) throw IllegalStateException("shared media is too large")
                        out.write(buffer, 0, read)
                    }
                    out.flush()
                }
            } ?: return null

            val entry = PendingMedia(
                id = id,
                uri = uriFor(file).toString(),
                mimeType = resolverMime,
                sizeBytes = written,
                receivedAtMs = System.currentTimeMillis()
            )
            insertAtTop(entry)
            trim()
            entry
        } catch (e: Exception) {
            Log.e(TAG, "could not read shared uri: ${e.message}")
            file.delete()
            null
        }
    }

    fun list(): List<PendingMedia> {
        val raw = prefs.getString(KEY_ENTRIES, null) ?: return emptyList()
        return try {
            val arr = JSONArray(raw)
            val out = ArrayList<PendingMedia>()
            val keep = JSONArray()
            for (i in 0 until arr.length()) {
                val obj = arr.optJSONObject(i) ?: continue
                val id = obj.optString("id")
                val uri = obj.optString("uri")
                val mime = obj.optString("mime")
                val size = obj.optLong("size")
                val at = obj.optLong("at")
                if (id.isBlank() || uri.isBlank()) continue
                if (!fileFor(id).exists()) continue
                val entry = PendingMedia(id, uri, mime, size, at)
                out += entry
                keep.put(toJson(entry))
            }
            if (keep.length() != arr.length()) persist(keep)
            out
        } catch (e: Exception) {
            Log.e(TAG, "inbox corrupt: ${e.message}")
            emptyList()
        }
    }

    fun latest(): PendingMedia? = list().maxByOrNull { it.receivedAtMs }

    fun clear() {
        inboxDir.listFiles()?.forEach { it.delete() }
        prefs.edit().remove(KEY_ENTRIES).apply()
    }

    fun fileFor(id: String): File = File(inboxDir, fileNameFor(id))

    fun uriFor(entry: PendingMedia): Uri =
        FileProvider.getUriForFile(appContext, authority, fileFor(entry.id))

    private fun uriFor(file: File): Uri = FileProvider.getUriForFile(appContext, authority, file)

    private fun fileNameFor(id: String): String =
        inboxDir.listFiles()?.firstOrNull { it.name.startsWith("$id.") }?.name ?: "$id.bin"

    private fun insertAtTop(entry: PendingMedia) {
        val existing = list().toMutableList()
        existing.removeAll { it.id == entry.id }
        existing.add(0, entry)
        persist(existing)
    }

    private fun trim() {
        val kept = list().take(MAX_ITEMS)
        val dropped = list().drop(MAX_ITEMS)
        dropped.forEach { fileFor(it.id).delete() }
        persist(kept)
    }

    private fun persist(entries: List<PendingMedia>) {
        val arr = JSONArray()
        entries.forEach { arr.put(toJson(it)) }
        prefs.edit().putString(KEY_ENTRIES, arr.toString()).apply()
    }

    private fun persist(arr: JSONArray) {
        prefs.edit().putString(KEY_ENTRIES, arr.toString()).apply()
    }

    private fun toJson(entry: PendingMedia) = JSONObject().apply {
        put("id", entry.id)
        put("uri", entry.uri)
        put("mime", entry.mimeType)
        put("size", entry.sizeBytes)
        put("at", entry.receivedAtMs)
    }

    private fun extensionFor(mime: String, name: String): String {
        val fromName = name.substringAfterLast('.', "").lowercase()
        if (fromName.length in 2..5 && fromName.all { it.isLetterOrDigit() }) return ".$fromName"
        return when {
            mime.startsWith("image/gif") -> ".gif"
            mime.startsWith("image/png") -> ".png"
            mime.startsWith("image/webp") -> ".webp"
            mime.startsWith("image/heic") -> ".heic"
            mime.startsWith("image/") -> ".jpg"
            mime.startsWith("video/mp4") -> ".mp4"
            mime.startsWith("video/") -> ".mp4"
            else -> ".bin"
        }
    }

    companion object {
        private const val TAG = "MediaInbox"
        private const val PREFS = "myra_inbox"
        private const val KEY_ENTRIES = "entries"
        private const val INBOX_DIR = "myra_inbox"
        private const val COPY_BUFFER = 64 * 1024

        /** Anything larger is refused rather than copied, so a video cannot fill the disk. */
        const val MAX_BYTES = 200L * 1024 * 1024
        const val MAX_ITEMS = 5
    }
}
