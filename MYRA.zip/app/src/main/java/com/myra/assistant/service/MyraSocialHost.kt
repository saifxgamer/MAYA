package com.myra.assistant.service

import android.content.Context
import com.myra.assistant.social.PendingMedia
import com.myra.assistant.social.SocialAgentHost
import com.myra.assistant.social.SocialPlatform

class MyraSocialHost(private val context: Context) : SocialAgentHost {

    private val picker = ShareTargetPicker(context)
    private val inbox = MediaInboxStore(context)
    private var speaker: ((String) -> Unit)? = null

    fun setSpeaker(speaker: (String) -> Unit) {
        this.speaker = speaker
    }

    override fun isAccessibilityEnabled(): Boolean = AccessibilityHelperService.isEnabled(context)

    override fun isAppInstalled(platform: SocialPlatform): Boolean = picker.isInstalled(platform)

    override fun hasShareHandler(platform: SocialPlatform): Boolean = picker.hasHandler(platform)

    override fun shareActivityClass(platform: SocialPlatform): String? = picker.pick(platform)

    override fun launchApp(platform: SocialPlatform): Boolean = picker.launchApp(platform)

    override fun sendShareIntent(
        platform: SocialPlatform,
        activityClass: String,
        media: PendingMedia
    ): Boolean = picker.send(platform, activityClass, media)

    override fun pendingMedia(): List<PendingMedia> = inbox.list()

    override fun currentTimeMs(): Long = System.currentTimeMillis()

    override fun speak(message: String) {
        speaker?.invoke(message)
    }
}
