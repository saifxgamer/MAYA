package com.myra.assistant.social

object FlowGuards {

    sealed class GuardVerdict {
        object Clear : GuardVerdict()
        data class Blocked(val code: SocialResultCode, val message: String) : GuardVerdict()
    }

    private val CAPTCHA_MARKERS = listOf(
        "captcha", "i m not a robot", "not a robot", "select all images",
        "confirm you are human", "security check", "verify it s you"
    )

    private val TWO_FA_MARKERS = listOf(
        "verification code", "enter the code", "one time code", "one-time code",
        "2-step", "two-step", "two step verification", "otp", "authenticator",
        "confirm it s you", "confirm its you", "suspicious login", "was this you"
    )

    private val LOGIN_MARKERS = listOf(
        "log in", "login", "sign in", "signin", "continue with", "password"
    )

    private val PERMISSION_PACKAGES = setOf(
        "com.android.permissioncontroller",
        "com.google.android.permissioncontroller"
    )

    fun check(observation: ScreenObservation): GuardVerdict {
        val labels = observation.labels().map { TargetResolver.normalize(it) }
        val joined = labels.joinToString(" ")

        if (observation.packageName in PERMISSION_PACKAGES) {
            return GuardVerdict.Blocked(
                SocialResultCode.USER_ACTION_REQUIRED,
                "A permission dialog is open. Allow or deny it yourself, then say done"
            )
        }

        if (CAPTCHA_MARKERS.any { joined.contains(it) }) {
            return GuardVerdict.Blocked(
                SocialResultCode.USER_ACTION_REQUIRED,
                "A captcha is showing. Solve it yourself, then say done"
            )
        }

        if (TWO_FA_MARKERS.any { joined.contains(it) }) {
            return GuardVerdict.Blocked(
                SocialResultCode.USER_ACTION_REQUIRED,
                "A verification code is being asked for. Enter it yourself, then say done"
            )
        }

        if (AgentSecurity.looksLikeCredentialScreen(observation)) {
            return GuardVerdict.Blocked(
                SocialResultCode.USER_ACTION_REQUIRED,
                "A login form is showing. Log in yourself, then say done"
            )
        }

        if (labels.any { AgentSecurity.isHarmlessDismissLabel(it) } &&
            observation.elements.any { it.clickable && it.text.isNotBlank() }
        ) {
            return GuardVerdict.Clear
        }

        if (LOGIN_MARKERS.any { joined.contains(it) } && !joined.contains("phone")) {
            return GuardVerdict.Blocked(
                SocialResultCode.USER_ACTION_REQUIRED,
                "This looks like a sign-in screen. Sign in yourself, then say done"
            )
        }

        return GuardVerdict.Clear
    }

    fun harmlessDismissSpec(observation: ScreenObservation): TargetSpec? {
        val match = observation.elements.firstOrNull { element ->
            element.clickable && element.text.isNotBlank() &&
                AgentSecurity.isHarmlessDismissLabel(element.text)
        } ?: return null
        return TargetSpec(
            name = "harmless_dismiss",
            text = match.text,
            requireClickable = true
        )
    }
}
