package com.myra.assistant.service

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.Window
import android.widget.TextView
import com.myra.assistant.R
import com.myra.assistant.social.PendingMedia

class ShareTargetActivity : Activity() {

    private var inbox: MediaInboxStore? = null
    private var copying = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestWindowFeature(Window.FEATURE_NO_TITLE)
        setContentView(R.layout.activity_share_target)

        inbox = MediaInboxStore(this)

        val uri: Uri? = intent?.getParcelableExtra(Intent.EXTRA_STREAM)
        val mime = intent?.type ?: ""
        val clipUri = intent?.clipData?.getItemAt(0)?.uri

        val source = uri ?: clipUri
        if (source == null || !inboxIsSupported(mime)) {
            finishWith(accepted = false)
            return
        }

        val preview = findViewById<TextView>(R.id.share_media_name)
        preview?.text = displayNameOf(source, mime)

        findViewById<TextView>(R.id.share_allow)?.setOnClickListener { accept(source, mime) }
        findViewById<TextView>(R.id.share_deny)?.setOnClickListener { finishWith(accepted = false) }
    }

    private fun inboxIsSupported(mime: String): Boolean =
        mime.startsWith("image/") || mime.startsWith("video/")

    private fun displayNameOf(uri: Uri, mime: String): String {
        val type = mime.ifBlank { contentResolver.getType(uri).orEmpty() }
        val kind = if (type.startsWith("video/")) "video" else "photo"
        return when (type) {
            "image/gif" -> "GIF"
            "image/png" -> "PNG"
            else -> if (kind == "video") "Video" else "Photo"
        }
    }

    /** Copying a video can take seconds, so it never runs on the main thread. */
    private fun accept(uri: Uri, mime: String) {
        val store = inbox ?: run {
            finishWith(false)
            return
        }
        if (copying) return
        copying = true
        setButtonsEnabled(false)
        findViewById<TextView>(R.id.share_media_name)?.text = getString(R.string.share_target_copying)

        Thread {
            val entry: PendingMedia? = store.storeFromUri(uri, mime)
            runOnUiThread {
                if (isFinishing) return@runOnUiThread
                if (entry == null) {
                    finishWith(accepted = false)
                    return@runOnUiThread
                }
                setResult(RESULT_OK, Intent().putExtra(EXTRA_MEDIA_ID, entry.id))
                finish()
            }
        }.start()
    }

    private fun setButtonsEnabled(enabled: Boolean) {
        findViewById<TextView>(R.id.share_allow)?.isEnabled = enabled
        findViewById<TextView>(R.id.share_deny)?.isEnabled = enabled
        findViewById<TextView>(R.id.share_allow)?.alpha = if (enabled) 1f else 0.5f
        findViewById<TextView>(R.id.share_deny)?.alpha = if (enabled) 1f else 0.5f
    }

    private fun finishWith(accepted: Boolean) {
        if (!accepted) setResult(RESULT_CANCELED)
        finish()
        overridePendingTransition(0, 0)
    }

    override fun onBackPressed() {
        setResult(RESULT_CANCELED)
        super.onBackPressed()
    }

    companion object {
        const val EXTRA_MEDIA_ID = "com.myra.assistant.MEDIA_ID"
    }
}
