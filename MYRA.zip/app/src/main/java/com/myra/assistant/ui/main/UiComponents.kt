package com.myra.assistant.ui.main

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.util.AttributeSet
import android.view.View
import androidx.core.content.ContextCompat
import com.myra.assistant.R
import com.myra.assistant.databinding.ItemChatMyraBinding
import com.myra.assistant.databinding.ItemChatUserBinding
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.max
import kotlin.math.min

class WaveformView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : View(context, attrs, defStyleAttr) {

    companion object {
        private const val BAR_COUNT = 20
        private const val LERP = 0.3f
    }

    private val barPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val barRect = RectF()
    private val barHeights = FloatArray(BAR_COUNT) { 0.06f }
    private val targets = FloatArray(BAR_COUNT) { 0.06f }
    private val baseColor = ContextCompat.getColor(context, R.color.myra_red)
    private var amplitude = 0f
    private var running = false
    private var phase = 0f
    private var lastFrameNanos = 0L

    private val frameRunnable = object : Runnable {
        override fun run() {
            if (!running) return
            advance()
            postOnAnimation(this)
        }
    }

    init {
        barPaint.color = baseColor
    }

    fun startAnimation() {
        if (running) return
        running = true
        lastFrameNanos = 0L
        postOnAnimation(frameRunnable)
    }

    fun stopAnimation() {
        running = false
        removeCallbacks(frameRunnable)
    }

    fun setAmplitude(rms: Float) {
        amplitude = rms.coerceIn(0f, 1f)
    }

    fun reset() {
        amplitude = 0f
        for (i in barHeights.indices) {
            barHeights[i] = 0.06f
            targets[i] = 0.06f
        }
        invalidate()
    }

    private fun advance() {
        val now = System.nanoTime()
        val delta = if (lastFrameNanos == 0L) 0.016f else (now - lastFrameNanos) / 1_000_000_000f
        lastFrameNanos = now
        val clampedDelta = delta.coerceIn(0.001f, 0.05f)
        phase = (phase + clampedDelta * 90f) % 360f

        for (i in 0 until BAR_COUNT) {
            val wave = (kotlin.math.sin(Math.toRadians((phase + i * (360f / BAR_COUNT)).toDouble())) + 1.0) / 2.0
            val jitter = (kotlin.math.sin(Math.toRadians((phase * 1.7f + i * 47f).toDouble())) + 1.0) / 2.0
            val mixed = (wave * 0.65 + jitter * 0.35).toFloat()
            targets[i] = 0.06f + amplitude * (0.25f + mixed * 0.75f)
            barHeights[i] += (targets[i] - barHeights[i]) * LERP
        }
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0f || h <= 0f) return
        val gap = w * 0.012f
        val barWidth = (w - gap * (BAR_COUNT - 1)) / BAR_COUNT
        val half = h / 2f

        for (i in 0 until BAR_COUNT) {
            val left = i * (barWidth + gap)
            val barHeight = max(min(barHeights[i], 1f) * h, h * 0.06f)
            val alpha = (150 + (barHeight / h) * 105f).toInt().coerceIn(0, 255)
            barPaint.color = Color.argb(alpha, Color.red(baseColor), Color.green(baseColor), Color.blue(baseColor))
            barRect.set(left, half - barHeight / 2f, left + barWidth, half + barHeight / 2f)
            val radius = barWidth / 2f
            canvas.drawRoundRect(barRect, radius, radius, barPaint)
        }
    }

    override fun onDetachedFromWindow() {
        super.onDetachedFromWindow()
        stopAnimation()
    }
}

data class ChatMessage(
    val text: String,
    val isUser: Boolean,
    val timestamp: Long = System.currentTimeMillis()
)

class ChatAdapter : androidx.recyclerview.widget.RecyclerView.Adapter<androidx.recyclerview.widget.RecyclerView.ViewHolder>() {

    companion object {
        private const val TYPE_USER = 0
        private const val TYPE_MYRA = 1
    }

    private val items = ArrayList<ChatMessage>()
    private val timeFormat = SimpleDateFormat("HH:mm", Locale.getDefault())

    override fun getItemViewType(position: Int): Int =
        if (items[position].isUser) TYPE_USER else TYPE_MYRA

    override fun onCreateViewHolder(parent: android.view.ViewGroup, viewType: Int): androidx.recyclerview.widget.RecyclerView.ViewHolder {
        val inflater = android.view.LayoutInflater.from(parent.context)
        return if (viewType == TYPE_USER) {
            UserHolder(ItemChatUserBinding.inflate(inflater, parent, false))
        } else {
            MyraHolder(ItemChatMyraBinding.inflate(inflater, parent, false))
        }
    }

    override fun onBindViewHolder(holder: androidx.recyclerview.widget.RecyclerView.ViewHolder, position: Int) {
        val message = items[position]
        val time = timeFormat.format(Date(message.timestamp))
        when (holder) {
            is UserHolder -> holder.bind(message.text, time)
            is MyraHolder -> holder.bind(message.text, time)
        }
    }

    override fun getItemCount(): Int = items.size

    fun addMessage(message: ChatMessage): Boolean {
        if (message.text.isBlank()) return false
        if (!message.isUser && items.lastOrNull()?.let { !it.isUser && it.text == message.text } == true) {
            return false
        }
        items.add(message)
        notifyItemInserted(items.size - 1)
        return true
    }

    fun replaceAll(messages: List<ChatMessage>) {
        items.clear()
        items.addAll(messages)
        notifyDataSetChanged()
    }

    fun clear() {
        items.clear()
        notifyDataSetChanged()
    }

    fun lastMyraText(): String? = items.lastOrNull { !it.isUser }?.text

    fun snapshot(): List<ChatMessage> = ArrayList(items)

    class UserHolder(private val binding: ItemChatUserBinding) :
        androidx.recyclerview.widget.RecyclerView.ViewHolder(binding.root) {
        fun bind(text: String, time: String) {
            binding.chatUserText.text = text
            binding.chatUserTime.text = time
        }
    }

    class MyraHolder(private val binding: ItemChatMyraBinding) :
        androidx.recyclerview.widget.RecyclerView.ViewHolder(binding.root) {
        fun bind(text: String, time: String) {
            binding.chatMyraText.text = text
            binding.chatMyraTime.text = time
        }
    }
}
