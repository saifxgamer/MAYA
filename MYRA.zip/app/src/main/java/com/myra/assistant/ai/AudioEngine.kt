package com.myra.assistant.ai

import android.annotation.SuppressLint
import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioRecord
import android.media.AudioTrack
import android.media.MediaRecorder
import android.os.Handler
import android.os.Looper
import android.util.Log
import java.util.concurrent.ConcurrentLinkedQueue
import java.util.concurrent.TimeUnit
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

class AudioEngine(private val context: Context) {

    companion object {
        private const val TAG = "AudioEngine"
        const val SAMPLE_RATE_IN = 16000
        const val SAMPLE_RATE_OUT = 24000
        const val CHUNK_SIZE = 1024
        private const val SILENCE_LEVEL = 0.012f
    }

    var onAudioCaptured: ((ByteArray) -> Unit)? = null
    var onAmplitudeChanged: ((Float) -> Unit)? = null
    var onSpeakingStarted: (() -> Unit)? = null
    var onSpeakingStopped: (() -> Unit)? = null
    var onError: ((String) -> Unit)? = null

    private val audioManager: AudioManager? =
        context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager

    private val mainHandler = Handler(Looper.getMainLooper())

    private var previousAudioMode: Int = AudioManager.MODE_NORMAL

    private var record: AudioRecord? = null
    private var track: AudioTrack? = null

    private val playbackQueue = ConcurrentLinkedQueue<ByteArray>()

    @Volatile
    private var recordingRunning = false

    @Volatile
    private var playbackRunning = false

    @Volatile
    private var muted = false

    @Volatile
    private var suppressCapture = false

    @Volatile
    private var isSpeaking = false

    @Volatile
    var lastRms: Float = 0f
        private set

    private var recordThread: Thread? = null
    private var playbackThread: Thread? = null

    val isMuted: Boolean get() = muted
    val isSpeakingNow: Boolean get() = isSpeaking
    val isCapturing: Boolean get() = recordingRunning && !muted && !suppressCapture

    // region capture

    @SuppressLint("MissingPermission")
    fun startRecording() {
        if (recordingRunning) return
        try {
            val minBuffer = AudioRecord.getMinBufferSize(
                SAMPLE_RATE_IN,
                AudioFormat.CHANNEL_IN_MONO,
                AudioFormat.ENCODING_PCM_16BIT
            )
            if (minBuffer == AudioRecord.ERROR || minBuffer == AudioRecord.ERROR_BAD_VALUE) {
                reportError("Mic minimum buffer unavailable on this device")
                return
            }
            val bufferSize = max(minBuffer, CHUNK_SIZE * 4)
            val audioRecord = createRecord(bufferSize) ?: run {
                reportError("Could not initialise microphone")
                return
            }
            if (audioRecord.state != AudioRecord.STATE_INITIALIZED) {
                audioRecord.release()
                reportError("Microphone failed to initialise")
                return
            }
            record = audioRecord
            enterAudioMode()
            recordingRunning = true
            audioRecord.startRecording()
            recordThread = Thread({ recordLoop(audioRecord) }, "MyraMicThread").also { it.start() }
        } catch (e: SecurityException) {
            reportError("RECORD_AUDIO permission is not granted")
        } catch (e: IllegalStateException) {
            reportError("Microphone is busy: ${e.message}")
        }
    }

    @SuppressLint("MissingPermission")
    private fun createRecord(bufferSize: Int): AudioRecord? {
        val format = AudioFormat.Builder()
            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
            .setSampleRate(SAMPLE_RATE_IN)
            .setChannelMask(AudioFormat.CHANNEL_IN_MONO)
            .build()

        val primary = runCatching {
            AudioRecord.Builder()
                .setAudioSource(MediaRecorder.AudioSource.VOICE_RECOGNITION)
                .setAudioFormat(format)
                .setBufferSizeInBytes(bufferSize)
                .build()
        }.getOrNull()

        if (primary != null && primary.state == AudioRecord.STATE_INITIALIZED) return primary
        primary?.release()

        val fallback = runCatching {
            AudioRecord.Builder()
                .setAudioSource(MediaRecorder.AudioSource.MIC)
                .setAudioFormat(format)
                .setBufferSizeInBytes(bufferSize)
                .build()
        }.getOrNull()
        if (fallback != null && fallback.state == AudioRecord.STATE_INITIALIZED) return fallback
        fallback?.release()
        return null
    }

    private fun recordLoop(audioRecord: AudioRecord) {
        val buffer = ByteArray(CHUNK_SIZE)
        while (recordingRunning) {
            val read = try {
                audioRecord.read(buffer, 0, CHUNK_SIZE)
            } catch (e: IllegalStateException) {
                Log.e(TAG, "read failed: ${e.message}")
                -1
            }
            if (read <= 0) {
                if (read < 0) Thread.sleep(10)
                continue
            }
            val chunk = if (read == CHUNK_SIZE) buffer.copyOf() else buffer.copyOf(read)
            val rms = computeRms(chunk)
            lastRms = rms
            notifyAmplitude(if (muted) 0f else rms)
            if (muted || suppressCapture || isSpeaking) continue
            onAudioCaptured?.invoke(chunk)
        }
    }

    fun stopRecording() {
        recordingRunning = false
        recordThread?.interrupt()
        recordThread = null
        try {
            record?.stop()
        } catch (e: IllegalStateException) {
            Log.w(TAG, "stop on record threw: ${e.message}")
        }
        record?.release()
        record = null
    }

    // endregion

    // region playback

    fun startPlayback() {
        if (playbackRunning) return
        try {
            val minBuffer = AudioTrack.getMinBufferSize(
                SAMPLE_RATE_OUT,
                AudioFormat.CHANNEL_OUT_MONO,
                AudioFormat.ENCODING_PCM_16BIT
            )
            if (minBuffer == AudioTrack.ERROR || minBuffer == AudioTrack.ERROR_BAD_VALUE) {
                reportError("Speaker buffer unavailable on this device")
                return
            }
            val bufferSize = max(minBuffer, CHUNK_SIZE * 4)
            val attributes = AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_ASSISTANT)
                .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                .build()
            val format = AudioFormat.Builder()
                .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                .setSampleRate(SAMPLE_RATE_OUT)
                .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                .build()
            val audioTrack = AudioTrack.Builder()
                .setAudioAttributes(attributes)
                .setAudioFormat(format)
                .setTransferMode(AudioTrack.MODE_STREAM)
                .setBufferSizeInBytes(bufferSize)
                .build()
            if (audioTrack.state != AudioTrack.STATE_INITIALIZED) {
                audioTrack.release()
                reportError("Speaker failed to initialise")
                return
            }
            track = audioTrack
            audioTrack.play()
            playbackRunning = true
            playbackThread = Thread({ playbackLoop(audioTrack) }, "MyraSpeakerThread").also { it.start() }
        } catch (e: IllegalStateException) {
            reportError("Speaker is busy: ${e.message}")
        }
    }

    private fun playbackLoop(audioTrack: AudioTrack) {
        while (playbackRunning) {
            val chunk = playbackQueue.poll(60, TimeUnit.MILLISECONDS)
            if (chunk == null) {
                markSpeakingStoppedIfIdle()
                continue
            }
            var offset = 0
            while (offset < chunk.size && playbackRunning) {
                val written = try {
                    audioTrack.write(chunk, offset, chunk.size - offset, AudioTrack.WRITE_BLOCKING)
                } catch (e: IllegalStateException) {
                    Log.e(TAG, "write failed: ${e.message}")
                    -1
                }
                if (written <= 0) break
                offset += written
            }
            markSpeakingStoppedIfIdle()
        }
    }

    @Synchronized
    fun queueAudio(data: ByteArray) {
        if (data.isEmpty()) return
        val wasIdle = playbackQueue.isEmpty()
        playbackQueue.add(data)
        if (wasIdle && !isSpeaking) {
            isSpeaking = true
            notifySpeakingStarted()
        }
    }

    @Synchronized
    private fun markSpeakingStoppedIfIdle() {
        if (playbackQueue.isNotEmpty() || !isSpeaking) return
        isSpeaking = false
        notifySpeakingStopped()
    }

    @Synchronized
    fun interruptPlayback() {
        playbackQueue.clear()
        val audioTrack = track
        if (audioTrack != null) {
            runCatching {
                audioTrack.pause()
                audioTrack.flush()
                audioTrack.play()
            }.onFailure { Log.w(TAG, "flush failed: ${it.message}") }
        }
        if (isSpeaking) {
            isSpeaking = false
            notifySpeakingStopped()
        }
    }

    fun stopPlayback() {
        playbackRunning = false
        interruptPlayback()
        playbackThread?.interrupt()
        playbackThread = null
        try {
            track?.stop()
        } catch (e: IllegalStateException) {
            Log.w(TAG, "stop on track threw: ${e.message}")
        }
        track?.release()
        track = null
    }

    // endregion

    fun setMuted(value: Boolean) {
        muted = value
        if (value) notifyAmplitude(0f)
    }

    fun toggleMute(): Boolean {
        setMuted(!muted)
        return muted
    }

    fun setCaptureSuppressed(value: Boolean) {
        suppressCapture = value
    }

    fun release() {
        stopRecording()
        stopPlayback()
        audioManager?.mode = previousAudioMode
    }

    private fun notifyAmplitude(rms: Float) {
        val callback = onAmplitudeChanged ?: return
        if (Looper.myLooper() == Looper.getMainLooper()) {
            callback(rms)
        } else {
            mainHandler.post { callback(rms) }
        }
    }

    private fun notifySpeakingStarted() {
        val callback = onSpeakingStarted ?: return
        if (Looper.myLooper() == Looper.getMainLooper()) {
            callback()
        } else {
            mainHandler.post { callback() }
        }
    }

    private fun notifySpeakingStopped() {
        val callback = onSpeakingStopped ?: return
        if (Looper.myLooper() == Looper.getMainLooper()) {
            callback()
        } else {
            mainHandler.post { callback() }
        }
    }

    private fun enterAudioMode() {
        runCatching {
            val am = audioManager ?: return
            previousAudioMode = am.mode
            am.mode = AudioManager.MODE_IN_COMMUNICATION
        }
    }

    private fun reportError(message: String) {
        Log.e(TAG, message)
        val callback = onError ?: return
        if (Looper.myLooper() == Looper.getMainLooper()) {
            callback(message)
        } else {
            mainHandler.post { callback(message) }
        }
    }

    private fun computeRms(bytes: ByteArray): Float {
        if (bytes.isEmpty()) return 0f
        val samples = bytes.size / 2
        if (samples <= 0) return 0f
        var sum = 0.0
        var index = 0
        while (index < bytes.size - 1) {
            val sample = ((bytes[index + 1].toInt() shl 8) or (bytes[index].toInt() and 0xFF)).toShort()
            val value = sample / 32768f
            sum += (value * value).toDouble()
            index += 2
        }
        val rms = sqrt(sum / samples).toFloat()
        val boosted = (rms - SILENCE_LEVEL) / 0.25f
        return min(1f, max(0f, boosted))
    }
}
