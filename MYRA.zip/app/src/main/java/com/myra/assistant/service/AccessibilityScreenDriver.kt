package com.myra.assistant.service

import android.graphics.Rect
import android.view.accessibility.AccessibilityNodeInfo
import androidx.core.view.accessibility.AccessibilityNodeInfoCompat
import com.myra.assistant.social.ActionFailure
import com.myra.assistant.social.ActionResult
import com.myra.assistant.social.ElementBounds
import com.myra.assistant.social.ScrollDirection
import com.myra.assistant.social.ScreenDriver
import com.myra.assistant.social.ScreenObservation
import java.util.ArrayDeque
import java.util.concurrent.atomic.AtomicLong

class AccessibilityScreenDriver(
    private val service: AccessibilityHelperService
) : ScreenDriver {

    private val observationCounter = AtomicLong(0L)
    private val latestObservation = AtomicLong(0L)

    @Volatile
    private var lastObservation: ScreenObservation? = null

    private val cache = HashMap<String, AccessibilityNodeInfoCompat>()
    private val order = ArrayList<String>()

    override fun isAvailable(): Boolean = service.isReady

    override fun observe(): ScreenObservation {
        val stamp = service.uiEventCounter()
        val id = observationCounter.incrementAndGet()
        val root = service.activeRoot()
        val elements = ArrayList<UiElementSnapshot>()
        val packageName = service.activePackageName()

        if (root != null) {
            collect(root, elements, id, packageName)
        }

        cache.keys.toList().forEach { key ->
            if (!key.startsWith("$id#")) cache.remove(key)
        }
        order.retainAll(cache.keys.toList())
        cache.keys.toList().forEach { key ->
            if (!key.startsWith("$id#")) cache.remove(key)
        }

        val bounds = screenBounds()
        val observation = ScreenObservation(
            observationId = id,
            packageName = packageName,
            windowClass = service.activeWindowClass(),
            screenWidth = bounds.width(),
            screenHeight = bounds.height(),
            eventStamp = stamp,
            windowStamp = service.windowStamp(),
            capturedAtMs = System.currentTimeMillis(),
            elements = elements.map { it.toElement() }
        )
        lastObservation = observation
        latestObservation.set(id)
        return observation
    }

    private fun screenBounds(): Rect = try {
        val metrics = service.resources.displayMetrics
        Rect(0, 0, metrics.widthPixels, metrics.heightPixels)
    } catch (_: Exception) {
        Rect(0, 0, 1080, 1920)
    }

    private class UiElementSnapshot(
        val node: AccessibilityNodeInfoCompat,
        val index: Int,
        val observationId: Long,
        val packageName: String,
        val className: String,
        val text: String,
        val contentDescription: String,
        val hintText: String,
        val resourceId: String,
        val bounds: ElementBounds,
        val clickable: Boolean,
        val longClickable: Boolean,
        val enabled: Boolean,
        val selected: Boolean,
        val focused: Boolean,
        val focusable: Boolean,
        val scrollable: Boolean,
        val editable: Boolean,
        val checkable: Boolean,
        val checked: Boolean,
        val password: Boolean,
        val visible: Boolean,
        val depth: Int,
        val parentIndex: Int,
        val parentPath: String
    ) {
        fun toElement() = com.myra.assistant.social.UiElement(
            elementId = "$observationId#$index",
            observationId = observationId,
            index = index,
            packageName = packageName,
            className = className,
            text = text,
            contentDescription = contentDescription,
            hintText = hintText,
            resourceId = resourceId,
            bounds = bounds,
            clickable = clickable,
            longClickable = longClickable,
            enabled = enabled,
            selected = selected,
            focused = focused,
            focusable = focusable,
            scrollable = scrollable,
            editable = editable,
            checkable = checkable,
            checked = checked,
            password = password,
            visible = visible,
            depth = depth,
            parentIndex = parentIndex,
            parentPath = parentPath
        )
    }

    private fun collect(
        root: AccessibilityNodeInfoCompat,
        out: MutableList<UiElementSnapshot>,
        observationId: Long,
        packageName: String
    ) {
        val queue = ArrayDeque<Pair<AccessibilityNodeInfoCompat, Int>>()
        queue.add(root to 0)
        var count = 0
        val parentIds = HashMap<AccessibilityNodeInfoCompat, String>()

        while (queue.isNotEmpty() && count < MAX_NODES) {
            val (node, depth) = queue.poll() ?: break
            count++

            val parent = try { node.parent } catch (_: Exception) { null }
            val parentId = parent?.let { parentIds[it] }
            val index = out.size
            val elementId = "$observationId#$index"
            parentIds[node] = elementId

            val password = try { node.isPassword } catch (_: Exception) { false }
            val rawText = try { node.text?.toString().orEmpty() } catch (_: Exception) { "" }
            val desc = try { node.contentDescription?.toString().orEmpty() } catch (_: Exception) { "" }
            val hint = try { node.hintText?.toString().orEmpty() } catch (_: Exception) { "" }
            val parentClickable = try { parent?.isClickable ?: false } catch (_: Exception) { false }

            out += UiElementSnapshot(
                node = node,
                index = index,
                observationId = observationId,
                packageName = packageName,
                className = try { node.className?.toString().orEmpty() } catch (_: Exception) { "" },
                text = if (password) REDACTED else rawText,
                contentDescription = desc,
                hintText = hint,
                resourceId = try { node.viewIdResourceName.orEmpty() } catch (_: Exception) { "" },
                bounds = readBounds(node),
                clickable = try { node.isClickable } catch (_: Exception) { false } || parentClickable,
                longClickable = try { node.isLongClickable } catch (_: Exception) { false },
                enabled = try { node.isEnabled } catch (_: Exception) { true },
                selected = try { node.isSelected } catch (_: Exception) { false },
                focused = try { node.isFocused } catch (_: Exception) { false },
                focusable = try { node.isFocusable } catch (_: Exception) { false },
                scrollable = try { node.isScrollable } catch (_: Exception) { false },
                editable = try { node.isEditable } catch (_: Exception) { false },
                checkable = try { node.isCheckable } catch (_: Exception) { false },
                checked = try { node.isChecked } catch (_: Exception) { false },
                password = password,
                visible = try { node.isVisibleToUser } catch (_: Exception) { true },
                depth = depth,
                parentIndex = parentIds[parent]?.substringAfter('#')?.toIntOrNull() ?: -1,
                parentPath = parentId ?: "root"
            )
            cache[elementId] = node

            try {
                for (i in 0 until node.childCount) {
                    node.getChild(i)?.let { queue.add(it to depth + 1) }
                }
            } catch (_: Exception) {
            }
        }
    }

    private fun readBounds(node: AccessibilityNodeInfoCompat): ElementBounds = try {
        val rect = Rect()
        node.getBoundsInScreen(rect)
        ElementBounds(rect.left, rect.top, rect.right, rect.bottom)
    } catch (_: Exception) {
        ElementBounds(0, 0, 0, 0)
    }

    override fun currentPackageName(): String = service.activePackageName()

    override fun currentWindowClass(): String = service.activeWindowClass()

    override fun uiEventStamp(): Long = service.uiEventCounter()

    override fun windowStamp(): Int = service.windowStamp()

    override fun latestObservationId(): Long = latestObservation.get()

    override fun screenSize(): Pair<Int, Int> {
        val bounds = screenBounds()
        return bounds.width() to bounds.height()
    }

    override fun click(elementId: String): ActionResult {
        val node = resolveFresh(elementId) ?: return ActionResult.fail(ActionFailure.ELEMENT_GONE)
        val direct = try {
            node.performAction(AccessibilityNodeInfo.ACTION_CLICK)
        } catch (_: Exception) {
            false
        }
        if (direct) return ActionResult.ok(service.awaitUiChange(CLICK_SETTLE_MS))

        var parent = try { node.parent } catch (_: Exception) { null }
        var hops = 0
        while (parent != null && hops < 5) {
            val ok = try { parent.isClickable && parent.performAction(AccessibilityNodeInfo.ACTION_CLICK) } catch (_: Exception) { false }
            if (ok) return ActionResult.ok(service.awaitUiChange(CLICK_SETTLE_MS))
            parent = try { parent.parent } catch (_: Exception) { null }
            hops++
        }
        return ActionResult.fail(ActionFailure.NOT_CLICKABLE, "no clickable self or ancestor")
    }

    override fun gestureTap(elementId: String): ActionResult {
        val node = resolveFresh(elementId) ?: return ActionResult.fail(ActionFailure.ELEMENT_GONE)
        val bounds = readBounds(node)
        if (bounds.isEmpty) return ActionResult.fail(ActionFailure.EMPTY_BOUNDS)
        return service.tapAt(bounds.centerX, bounds.centerY)
    }

    override fun focus(elementId: String): ActionResult {
        val node = resolveFresh(elementId) ?: return ActionResult.fail(ActionFailure.ELEMENT_GONE)
        val ok = try { node.performAction(AccessibilityNodeInfo.ACTION_FOCUS) } catch (_: Exception) { false }
        return if (ok) ActionResult.ok(true) else ActionResult.fail(ActionFailure.NOT_CLICKABLE, "focus refused")
    }

    override fun setText(elementId: String, text: String): ActionResult {
        val node = resolveFresh(elementId) ?: return ActionResult.fail(ActionFailure.ELEMENT_GONE)
        val password = try { node.isPassword } catch (_: Exception) { false }
        if (password) return ActionResult.fail(ActionFailure.PASSWORD_FIELD)
        val args = android.os.Bundle().apply {
            putCharSequence(
                AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text
            )
        }
        val ok = try {
            node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
        } catch (_: Exception) {
            false
        }
        return if (ok) ActionResult.ok(true) else ActionResult.fail(ActionFailure.NOT_EDITABLE, "setText refused")
    }

    override fun scroll(elementId: String, direction: ScrollDirection, amountPx: Int): ActionResult {
        if (elementId.isNotBlank()) {
            val node = resolveFresh(elementId)
            if (node != null) {
                val forward = direction == ScrollDirection.DOWN || direction == ScrollDirection.RIGHT
                val ok = try {
                    node.performAction(
                        if (forward) AccessibilityNodeInfo.ACTION_SCROLL_FORWARD
                        else AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD
                    )
                } catch (_: Exception) {
                    false
                }
                if (ok) return ActionResult.ok(true)
            }
        }
        return service.swipe(direction)
    }

    override fun invalidateObservations() {
        lastObservation = null
        // Burn the current generation. latestObservation now holds a value that was never
        // handed out as an observation id, so any tree captured before the action is no
        // longer current and can never be acted on again.
        latestObservation.set(observationCounter.incrementAndGet())
    }

    override fun awaitUiChange(timeoutMs: Long): Boolean = service.awaitUiChange(timeoutMs)

    private fun resolveFresh(elementId: String): AccessibilityNodeInfoCompat? {
        val observationId = elementId.substringBefore('#').toLongOrNull() ?: return null
        if (observationId != latestObservation.get()) {
            return null
        }
        val node = cache[elementId] ?: return null
        val stillThere = try { node.refresh() } catch (_: Exception) { false }
        if (!stillThere) return null
        val expected = lastObservation?.byId(elementId)?.bounds
        if (expected != null && readBounds(node) != expected) {
            return null
        }
        return node
    }

    companion object {
        private const val MAX_NODES = 3000
        private const val CLICK_SETTLE_MS = 900L
        const val REDACTED = "«password»"
    }
}
