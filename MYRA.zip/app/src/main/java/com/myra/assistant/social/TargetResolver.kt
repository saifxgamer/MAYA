package com.myra.assistant.social

object TargetResolver {

    fun normalize(value: String): String = value
        .lowercase()
        .replace(NON_WORD, " ")
        .replace(ELLIPSIS, " ")
        .replace(WS, " ")
        .trim()

    fun bareResourceId(value: String): String = value.substringAfterLast('/')

    fun matchesSimpleClass(className: String, wanted: String): Boolean {
        val a = className.substringAfterLast('.')
        val b = wanted.substringAfterLast('.')
        return a.equals(b, ignoreCase = true)
    }

    fun resolve(
        observation: ScreenObservation,
        spec: TargetSpec,
        allowedPackages: Set<String> = emptySet()
    ): ResolveResult {
        if (!spec.hasStrategy()) {
            return ResolveResult.NotFound(spec, "spec has no selector")
        }

        val candidates = observation.elements.filter { passesFilters(it, spec, observation, allowedPackages) }
        if (candidates.isEmpty()) {
            return ResolveResult.NotFound(spec, "no element passed filters")
        }

        val strategies = listOfNotNull(
            spec.resourceId?.let { MatchStrategy.RESOURCE_ID to filterByResourceId(candidates, it) },
            spec.contentDescription?.let { MatchStrategy.CONTENT_DESCRIPTION to filterByDescription(candidates, it) },
            spec.text?.let { MatchStrategy.TEXT_EXACT to filterByExactText(candidates, it) },
            spec.text?.let { MatchStrategy.TEXT_NORMALIZED to filterByNormalizedText(candidates, it) },
            spec.shortLabelHint?.let { MatchStrategy.SHORT_LABEL_HINT to filterByShortHint(candidates, it, spec) },
            if (spec.className != null || spec.nearbyText != null) {
                MatchStrategy.CLASS_WITH_NEARBY_TEXT to filterByClassAndNearby(observation, candidates, spec)
            } else null,
            spec.anchor?.let { MatchStrategy.STRUCTURAL_ANCHOR to filterByAnchor(observation, candidates, spec) }
        )

        strategies.forEach { (strategy, matches) ->
            if (matches.isEmpty()) return@forEach
            val ordered = sortDeterministically(matches, spec)
            if (spec.requireUniqueMatch && ordered.size > 1) {
                return ResolveResult.Ambiguous(spec, ordered.take(5))
            }
            return ResolveResult.Resolved(ordered.first(), strategy, ordered.size - 1, spec)
        }

        return ResolveResult.NotFound(spec, "no selector matched")
    }

    fun resolveAny(
        observation: ScreenObservation,
        specs: List<TargetSpec>,
        allowedPackages: Set<String> = emptySet()
    ): Pair<TargetSpec, ResolveResult>? {
        specs.forEach { spec ->
            when (val result = resolve(observation, spec, allowedPackages)) {
                is ResolveResult.Resolved -> return spec to result
                is ResolveResult.Ambiguous -> return spec to result
                is ResolveResult.NotFound -> Unit
            }
        }
        return null
    }

    fun find(spec: TargetSpec, observation: ScreenObservation, allowed: Set<String> = emptySet()): UiElement? =
        resolve(observation, spec, allowed).elementOrNull

    /**
     * Resolves against several specs at once and refuses to guess. Two specs can match two
     * different elements on the same screen (a feed "Share" and a reel "Share", for example),
     * so the union of matched elements is checked and ambiguity is reported instead of
     * silently taking the first one.
     */
    fun resolveUniqueAny(
        observation: ScreenObservation,
        specs: List<TargetSpec>,
        allowedPackages: Set<String> = emptySet()
    ): ResolveResult {
        if (specs.isEmpty()) return ResolveResult.NotFound(
            TargetSpec(name = "publish"),
            "no publish selector supplied"
        )
        val hits = LinkedHashMap<String, ResolveResult.Resolved>()
        for (spec in specs) {
            val result = resolve(observation, spec, allowedPackages)
            if (result is ResolveResult.Resolved) hits[result.element.elementId] = result
        }
        return when {
            hits.isEmpty() -> ResolveResult.NotFound(specs.first(), "no publish control on screen")
            hits.size > 1 -> ResolveResult.Ambiguous(
                specs.first(),
                hits.values.map { it.element },
                "more than one publish control on screen"
            )
            else -> hits.values.first()
        }
    }

    private fun passesFilters(
        element: UiElement,
        spec: TargetSpec,
        observation: ScreenObservation,
        allowedPackages: Set<String>
    ): Boolean {
        if (element.password) return false
        if (!element.visible) return false
        if (element.bounds.isEmpty) return false
        if (observation.screenWidth > 0 && !onScreen(element, observation)) return false
        if (spec.requireEnabled && !element.enabled) return false
        if (spec.requireEditable && !element.editable) return false
        if (spec.requireClickable && !isTappable(element)) return false
        if (spec.packageNames.isNotEmpty() && element.packageName !in spec.packageNames) return false
        if (allowedPackages.isNotEmpty() && element.packageName !in allowedPackages) return false
        if (spec.excludeTexts.any { isExcludedLabel(element.label, it) }) return false
        if (spec.excludeResourceIds.any { bareResourceId(element.resourceId).equals(bareResourceId(it), true) }) {
            return false
        }
        return true
    }

    private fun isExcludedLabel(label: String, excluded: String): Boolean {
        if (excluded.isBlank()) return false
        if (label.equals(excluded.trim(), ignoreCase = true)) return true
        val want = normalize(excluded)
        return want.isNotEmpty() && normalize(label) == want
    }

    private fun onScreen(element: UiElement, observation: ScreenObservation): Boolean {
        val b = element.bounds
        if (b.left < -20 || b.top < -20) return false
        if (observation.screenWidth > 0 && b.right > observation.screenWidth + 20) return false
        if (observation.screenHeight > 0 && b.bottom > observation.screenHeight + 20) return false
        return true
    }

    private fun isTappable(element: UiElement): Boolean =
        element.clickable || element.longClickable || element.focusable || element.editable

    private fun filterByResourceId(candidates: List<UiElement>, wanted: String): List<UiElement> {
        val bare = bareResourceId(wanted)
        return candidates.filter { element ->
            val mine = bareResourceId(element.resourceId)
            mine.isNotBlank() && (mine.equals(bare, ignoreCase = true) ||
                element.resourceId.equals(wanted, ignoreCase = true))
        }
    }

    private fun filterByDescription(candidates: List<UiElement>, wanted: String): List<UiElement> =
        candidates.filter { it.contentDescription.trim().equals(wanted.trim(), ignoreCase = true) }

    private fun filterByExactText(candidates: List<UiElement>, wanted: String): List<UiElement> =
        candidates.filter { it.text.trim().equals(wanted.trim(), ignoreCase = true) }

    private fun filterByNormalizedText(candidates: List<UiElement>, wanted: String): List<UiElement> {
        val target = normalize(wanted)
        if (target.isEmpty()) return emptyList()
        return candidates.filter { normalize(it.text) == target }
    }

    private fun filterByShortHint(
        candidates: List<UiElement>,
        hint: String,
        spec: TargetSpec
    ): List<UiElement> {
        val needle = normalize(hint)
        if (needle.isEmpty()) return emptyList()
        return candidates.filter { element ->
            val labels = listOf(element.text, element.contentDescription, element.hintText)
            labels.any { raw ->
                if (raw.isBlank()) return@any false
                if (raw.length > spec.maxHintLabelLength) return@any false
                normalize(raw).contains(needle)
            }
        }
    }

    private fun filterByClassAndNearby(
        observation: ScreenObservation,
        candidates: List<UiElement>,
        spec: TargetSpec
    ): List<UiElement> {
        val classFiltered = if (spec.className == null) candidates else candidates.filter {
            matchesSimpleClass(it.className, spec.className)
        }
        val nearby = spec.nearbyText?.let { normalize(it) } ?: return classFiltered
        if (nearby.isEmpty()) return classFiltered

        val siblingText = observation.elements
            .filter { normalize(it.label).contains(nearby) }
            .map { it.bounds }

        return classFiltered.filter { element ->
            siblingText.any { bounds ->
                element.bounds.horizontallyOverlaps(bounds) || element.bounds.verticallyOverlaps(bounds)
            }
        }
    }

    private fun filterByAnchor(
        observation: ScreenObservation,
        candidates: List<UiElement>,
        spec: TargetSpec
    ): List<UiElement> {
        val anchor = spec.anchor ?: return emptyList()
        val references = observation.elements.filter { ref ->
            when {
                anchor.referenceContentDescription != null ->
                    ref.contentDescription.trim()
                        .equals(anchor.referenceContentDescription.trim(), ignoreCase = true)

                anchor.referenceText != null ->
                    ref.text.trim().equals(anchor.referenceText.trim(), ignoreCase = true)

                anchor.referenceResourceId != null ->
                    bareResourceId(ref.resourceId)
                        .equals(bareResourceId(anchor.referenceResourceId), ignoreCase = true)

                else -> false
            }
        }
        if (references.isEmpty()) return emptyList()

        return candidates.filter { element ->
            if (anchor.candidateClassNames.isNotEmpty() &&
                anchor.candidateClassNames.none { matchesSimpleClass(element.className, it) }
            ) return@filter false
            if (anchor.requireCandidateClickable && !isTappable(element)) return@filter false
            if (anchor.requireSameRow && references.none { element.bounds.sameRow(it) }) return@filter false

            references.any { ref -> gapSatisfies(element.bounds, ref.bounds, anchor) }
        }
    }

    private fun gapSatisfies(
        candidate: ElementBounds,
        reference: ElementBounds,
        anchor: StructuralAnchor
    ): Boolean {
        val gap = when (anchor.relation) {
            AnchorRelation.LEFT_OF -> candidate.gapToLeftOf(reference)
            AnchorRelation.RIGHT_OF -> candidate.gapToRightOf(reference)
            AnchorRelation.ABOVE -> candidate.gapAbove(reference)
            AnchorRelation.BELOW -> candidate.gapBelow(reference)
        }
        if (gap < anchor.minGapPx) return false
        return gap <= anchor.maxGapPx
    }

    private fun sortDeterministically(
        matches: List<UiElement>,
        spec: TargetSpec
    ): List<UiElement> = matches.sortedWith(
        compareByDescending<UiElement> { it.clickable }
            .thenByDescending { it.enabled }
            .thenBy { regionRank(it, spec.region) }
            .thenBy { it.bounds.area }
            .thenBy { it.bounds.top }
            .thenBy { it.bounds.left }
            .thenBy { it.index }
    )

    private fun regionRank(element: UiElement, region: RegionPreference): Int = when (region) {
        RegionPreference.ANY -> 0
        RegionPreference.TOP -> if (element.bounds.top < element.bounds.bottom) 0 else 1
        RegionPreference.BOTTOM -> if (element.bounds.top >= element.bounds.bottom) 0 else 1
    }

    private val NON_WORD = Regex("[^a-z0-9\\u0900-\\u097F\\s]")
    private val ELLIPSIS = Regex("[…\\.]{2,}")
    private val WS = Regex("\\s+")
}
