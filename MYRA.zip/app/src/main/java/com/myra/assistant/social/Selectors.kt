package com.myra.assistant.social

import com.myra.assistant.social.SocialPlatform.FACEBOOK
import com.myra.assistant.social.SocialPlatform.INSTAGRAM

object InstagramSelectors {

    val homeFeedTitle = TargetSpec(
        name = "ig_home_feed_title",
        resourceId = "title_logo",
        contentDescription = "Instagram Home Feed",
        requireClickable = false
    )

    val createButton = TargetSpec(
        name = "ig_create_button",
        anchor = StructuralAnchor(
            referenceContentDescription = "Instagram Home Feed",
            candidateClassNames = setOf("ImageView"),
            relation = AnchorRelation.LEFT_OF,
            requireCandidateClickable = true,
            requireSameRow = true,
            region = RegionPreference.TOP
        ),
        excludeTexts = listOf("Create Mode button", "Reels", "Profile")
    )

    val nextGallery = TargetSpec(
        name = "ig_next_gallery",
        resourceId = "next_button_textview",
        contentDescription = "Next",
        text = "Next",
        requireClickable = true
    )

    val nextEditor = TargetSpec(
        name = "ig_next_editor",
        resourceId = "media_thumbnail_tray_button",
        contentDescription = "Next"
    )

    val nextReelEditor = TargetSpec(
        name = "ig_next_reel_editor",
        resourceId = "clips_right_action_button",
        contentDescription = "Next"
    )

    val nextAny = listOf(nextEditor, nextReelEditor, nextGallery)

    val captionField = TargetSpec(
        name = "ig_caption_field",
        resourceId = "caption_input_text_view",
        className = "AutoCompleteTextView",
        requireEditable = true,
        requireClickable = false
    )

    val optionPost = TargetSpec(
        name = "ig_option_post",
        shortLabelHint = "post",
        className = "TextView",
        requireClickable = true
    )

    val optionReel = TargetSpec(
        name = "ig_option_reel",
        shortLabelHint = "reel",
        className = "TextView",
        requireClickable = true
    )

    fun createOptionSpecs(action: SocialAction): List<TargetSpec> = when (action) {
        SocialAction.POST_REEL -> listOf(optionReel, optionPost)
        else -> listOf(optionPost, optionReel)
    }

    val shareFeed = TargetSpec(
        name = "ig_share_feed",
        resourceId = "share_footer_button",
        contentDescription = "Share",
        requireUniqueMatch = true
    )

    val shareReel = TargetSpec(
        name = "ig_share_reel",
        resourceId = "share_button",
        contentDescription = "Share",
        excludeTexts = listOf("Save draft"),
        requireUniqueMatch = true
    )

    val yourStories = TargetSpec(
        name = "ig_your_stories",
        resourceId = "your_story_share_shortcut_button",
        contentDescription = "Your stories",
        excludeTexts = listOf("Subscribers"),
        requireUniqueMatch = true
    )

    val yourStory = TargetSpec(
        name = "ig_your_story",
        contentDescription = "Your story",
        excludeTexts = listOf("Add Yours", "Your stories")
    )

    val tabFeed = TargetSpec(name = "ig_tab_feed", resourceId = "cam_dest_feed")
    val tabStory = TargetSpec(name = "ig_tab_story", resourceId = "cam_dest_story")
    val tabReels = TargetSpec(name = "ig_tab_reels", resourceId = "cam_dest_clips")

    val startOver = TargetSpec(
        name = "ig_start_over",
        text = "Start over",
        requireClickable = false
    )

    val saveDraft = TargetSpec(name = "ig_save_draft", text = "Save draft", requireClickable = false)
    val keepEditing = TargetSpec(name = "ig_keep_editing", text = "Keep editing", requireClickable = false)

    val postedIndicators = listOf(
        TargetSpec(
            name = "ig_post_shared",
            shortLabelHint = "has been shared",
            requireClickable = false,
            requireEnabled = false
        ),
        TargetSpec(
            name = "ig_reel_processing",
            shortLabelHint = "is being processed",
            requireClickable = false,
            requireEnabled = false
        ),
        TargetSpec(
            name = "ig_story_added",
            shortLabelHint = "story added",
            requireClickable = false,
            requireEnabled = false
        )
    )

    val draftSheetIndicators = listOf(startOver, saveDraft, keepEditing)

    fun platform(): SocialPlatform = INSTAGRAM
}

object FacebookSelectors {

    val composerEntry = TargetSpec(
        name = "fb_composer_entry",
        text = "What's on your mind?",
        contentDescription = "What's on your mind?",
        requireClickable = true
    )

    val next = TargetSpec(name = "fb_next", text = "Next", contentDescription = "Next")

    val postSettingsShare = TargetSpec(
        name = "fb_post_settings_share",
        contentDescription = "SHARE",
        text = "Share",
        requireUniqueMatch = true,
        excludeTexts = listOf("Share to story...", "Share to groups...", "Share to")
    )

    val shareToStory = TargetSpec(
        name = "fb_share_to_story",
        shortLabelHint = "share to story",
        requireClickable = false
    )

    val saveAsDraft = TargetSpec(
        name = "fb_save_as_draft",
        text = "Save as draft",
        requireClickable = false
    )

    val discardPost = TargetSpec(
        name = "fb_discard_post",
        text = "Discard post",
        requireClickable = false
    )

    val continueEditing = TargetSpec(
        name = "fb_continue_editing",
        text = "Continue editing",
        requireClickable = false
    )

    val postedIndicators = listOf(
        TargetSpec(
            name = "fb_post_live",
            shortLabelHint = "now live",
            requireClickable = false,
            requireEnabled = false
        ),
        TargetSpec(
            name = "fb_post_published",
            shortLabelHint = "your post is",
            requireClickable = false,
            requireEnabled = false
        )
    )

    val postTextField = TargetSpec(
        name = "fb_post_text_field",
        className = "EditText",
        requireEditable = true,
        requireClickable = false
    )

    /** Facebook media posts caption in a "Say something about this photo" box. */
    val captionField = TargetSpec(
        name = "fb_caption_field",
        resourceId = "com.facebook.photo.editor.text_field",
        className = "EditText",
        requireEditable = true,
        requireClickable = false
    )

    val closeDialogIndicators = listOf(saveAsDraft, discardPost, continueEditing)

    fun platform(): SocialPlatform = FACEBOOK
}

object PlatformSelectors {

    fun nextSpecs(platform: SocialPlatform): List<TargetSpec> = when (platform) {
        INSTAGRAM -> InstagramSelectors.nextAny
        FACEBOOK -> listOf(FacebookSelectors.next)
    }

    /**
     * Feed first: the feed post composer is far more common, and the reel selector also
     * matches the feed Share button through its content description. Callers must use
     * [TargetResolver.resolveUniqueAny] so a screen holding two different Share controls
     * is reported as ambiguous instead of being published through the wrong one.
     */
    fun shareSpecs(platform: SocialPlatform): List<TargetSpec> = when (platform) {
        INSTAGRAM -> listOf(InstagramSelectors.shareFeed, InstagramSelectors.shareReel)
        FACEBOOK -> listOf(FacebookSelectors.postSettingsShare)
    }

    fun storyTargetSpecs(platform: SocialPlatform): List<TargetSpec> = when (platform) {
        INSTAGRAM -> listOf(InstagramSelectors.yourStories, InstagramSelectors.yourStory)
        FACEBOOK -> listOf(FacebookSelectors.shareToStory)
    }

    fun postedIndicatorSpecs(platform: SocialPlatform): List<TargetSpec> = when (platform) {
        INSTAGRAM -> InstagramSelectors.postedIndicators
        FACEBOOK -> FacebookSelectors.postedIndicators
    }

    fun blockedDialogSpecs(platform: SocialPlatform): List<TargetSpec> = when (platform) {
        INSTAGRAM -> InstagramSelectors.draftSheetIndicators
        FACEBOOK -> FacebookSelectors.closeDialogIndicators
    }
}
