package com.myra.assistant.ai

import com.myra.assistant.model.AppCommand
import com.myra.assistant.model.PrimeContact
import com.myra.assistant.service.AccessibilityHelperService

object CommandParser {

    val APP_MAP: Map<String, String> = mapOf(
        "youtube" to "com.google.android.youtube",
        "yt" to "com.google.android.youtube",
        "whatsapp" to "com.whatsapp",
        "whats app" to "com.whatsapp",
        "instagram" to "com.instagram.android",
        "insta" to "com.instagram.android",
        "facebook" to "com.facebook.katana",
        "fb" to "com.facebook.katana",
        "chrome" to "com.android.chrome",
        "google chrome" to "com.android.chrome",
        "browser" to "com.android.chrome",
        "gmail" to "com.google.android.gm",
        "mail" to "com.google.android.gm",
        "maps" to "com.google.android.apps.maps",
        "google maps" to "com.google.android.apps.maps",
        "spotify" to "com.spotify.music",
        "netflix" to "com.netflix.mediaclient",
        "twitter" to "com.twitter.android",
        "x" to "com.twitter.android",
        "telegram" to "org.telegram.messenger",
        "snapchat" to "com.snapchat.android",
        "settings" to "com.android.settings",
        "setting" to "com.android.settings",
        "calculator" to "com.android.calculator2",
        "calc" to "com.android.calculator2",
        "calendar" to "com.android.calendar",
        "clock" to "com.android.deskclock",
        "alarm" to "com.android.deskclock",
        "phone" to "com.android.dialer",
        "dialer" to "com.android.dialer",
        "contacts" to "com.android.contacts",
        "play store" to "com.android.vending",
        "playstore" to "com.android.vending",
        "amazon" to "in.amazon.mShop.android.shopping",
        "shopping" to "in.amazon.mShop.android.shopping",
        "flipkart" to "com.flipkart.android",
        "paytm" to "net.one97.paytm",
        "phonepe" to "com.phonepe.app",
        "gpay" to "com.google.android.apps.nbu.paisa.user",
        "google pay" to "com.google.android.apps.nbu.paisa.user",
        "zoom" to "us.zoom.videomeetings",
        "meet" to "com.google.android.apps.meet",
        "google meet" to "com.google.android.apps.meet",
        "teams" to "com.microsoft.teams",
        "tiktok" to "com.zhiliaoapp.musically",
        "discord" to "com.discord",
        "linkedin" to "com.linkedin.android"
    )

    private val APP_ALIASES: List<String> =
        APP_MAP.keys.sortedByDescending { it.length }

    private val OPEN_VERBS = listOf(
        "kholo", "khol", "khol do", "open", "open karo", "chalu", "chalao", "chalo",
        "start", "launch", "run", "on karo"
    )

    private val CLOSE_VERBS = listOf(
        "band karo", "band kar", "band kro", "band", "close", "close karo",
        "band kar do", "kill", "exit"
    )

    private val CALL_VERBS = listOf(
        "call karo", "call kro", "call kar", "call kijiye", "phone karo", "phone kar",
        "phone kijiye", "ring karo", "dial karo", "call", "phone", "ring", "dial"
    )

    private val MESSAGE_VERBS = listOf(
        "message karo", "msg karo", "message bhejo", "msg bhejo", "sms bhejo",
        "text karo", "message", "msg", "sms", "text", "bhejo", "bhej", "likho", "ping"
    )

    private val OFF_WORDS = listOf("off", "band", "banda", "bando", "band karo", "rkf", "shut")
    private val ON_WORDS = listOf("on", "chalu", "chalao", "chalo", "start", "kholo", "enable", "activate")

    private val FILLER = setOf(
        "ko", "to", "karo", "kro", "kar", "do", "please", "plz", "jaldi", "abhi",
        "mere", "meri", "mera", "mujhe", "mujhko", "aapko", "usko", "isko",
        "kya", "hai", "number", "par", "pe", "aur", "or", "then", "phir",
        "karke", "kar", "karna", "karte", "bhej", "bhejo", "msg", "message",
        "sms", "text", "call", "phone", "ring", "dial", "ko", "bhi", "hi",
        "mera", "meraa", "mujhe", "jaldi", "abhi", "ek", "number", "par"
    )

    private val GENERIC_PRIME_HINTS = listOf(
        "close friend", "best friend", "bestie", "prime", "pf", "special one",
        "darling", "sweetheart", "jaan", "hubby", "wife", "husband", "girlfriend", "boyfriend"
    )

    private val ORDINAL_WORDS = mapOf(
        "first" to 0, "1st" to 0, "ek" to 0, "one" to 0,
        "second" to 1, "2nd" to 1, "do" to 1, "two" to 1,
        "third" to 2, "3rd" to 2, "teen" to 2, "three" to 2,
        "fourth" to 3, "4th" to 3, "four" to 3
    )

    private val CONTACT_STOPWORDS = listOf(
        "ko", "ka", "ki", "ke", "karo", "kro", "kar", "do", "please", "jaldi",
        "abhi", "ring", "phone", "call", "number", "par", "pe", "ko", "bhejo"
    )

    private val NAME_NOISE = listOf(
        "chhoota", "chhoot", "gaya", "gayi", "phat", "kharab", "dead", "off",
        "chalu", "band", "battery", "signal", "charge", "wifi", "network", "hua",
        "nahi", "haan", "kuch", "jaldi", "abhi", "acha", "theek", "sorry"
    )

    /**
     * [socialGatePending] is true while a social task is parked on a confirmation or a user
     * action. A bare "haan" or "done" belongs to that task then, because the user is
     * answering MYRA's own question and is not naming the app.
     */
    fun parse(
        raw: String,
        primeContacts: List<PrimeContact> = emptyList(),
        socialGatePending: Boolean = false
    ): AppCommand? {
        if (raw.isBlank()) return null
        val text = normalize(raw)
        if (text.isBlank()) return null
        val has = { s: String -> text.contains(s) }

        if (socialGatePending) {
            socialGateReply(text)?.let { return it }
        }

        primeCommand(text, primeContacts)?.let { return it }

        volumeCommand(text)?.let { return it }

        if (has("torch") || has("flashlight") || has("torchlight") || has("flash ")) {
            val off = OFF_WORDS.any { has(it) }
            return if (off) {
                AppCommand(AppCommand.Type.FLASHLIGHT_OFF)
            } else {
                AppCommand(AppCommand.Type.FLASHLIGHT_ON)
            }
        }

        if (has("wifi") || has("wi fi") || has("wireless")) {
            val off = OFF_WORDS.any { has(it) }
            return if (off) AppCommand(AppCommand.Type.WIFI_OFF) else AppCommand(AppCommand.Type.WIFI_ON)
        }

        if (has("bluetooth") || text == "bt" || has("bt ")) {
            val off = OFF_WORDS.any { has(it) }
            return if (off) {
                AppCommand(AppCommand.Type.BLUETOOTH_OFF)
            } else {
                AppCommand(AppCommand.Type.BLUETOOTH_ON)
            }
        }

        if (has("screen") && (has("on") || has("unlock") || has("wake") || has("jaga")) &&
            !has("off")
        ) {
            return AppCommand(AppCommand.Type.SCREEN_ON)
        }

        if (has("scroll") || has("neeche") || has("upar") || has("aage") || has("peeche")) {
            if (has("upar") || has("scroll up") || has("aage")) {
                return AppCommand(AppCommand.Type.SCROLL_UP)
            }
            if (has("neeche") || has("scroll down") || has("peeche")) {
                return AppCommand(AppCommand.Type.SCROLL_DOWN)
            }
        }

        if (has("back") || has("pichhe") || has("wapas jao")) {
            return AppCommand(AppCommand.Type.GO_BACK)
        }

        whatsappCommand(text)?.let { return it }
        socialCommand(text)?.let { return it }
        appCommand(text)?.let { return it }
        smsCommand(text)?.let { return it }
        callCommand(text)?.let { return it }
        searchCommand(text)?.let { return it }
        return null
    }

    private fun primeCommand(text: String, contacts: List<PrimeContact>): AppCommand? {
        if (contacts.isEmpty()) return null
        val index = matchPrime(text, contacts) ?: return null
        if (index !in contacts.indices) return null
        val contact = contacts[index]
        val hasMessageVerb = MESSAGE_VERBS.any { text.contains(it) }
        val hasCallVerb = CALL_VERBS.any { text.contains(it) }
        return when {
            hasCallVerb && !hasMessageVerb ->
                AppCommand(AppCommand.Type.PRIME_CALL, mapOf("index" to "$index", "name" to contact.name, "number" to contact.number))
            hasMessageVerb ->
                AppCommand(AppCommand.Type.PRIME_MSG, mapOf("index" to "$index", "name" to contact.name, "number" to contact.number))
            else -> null
        }
    }

    private fun matchPrime(text: String, contacts: List<PrimeContact>): Int? {
        contacts.forEachIndexed { index, contact ->
            val tokens = contact.name.lowercase()
                .split(Regex("[^a-z0-9]+"))
                .filter { it.length > 1 }
            if (tokens.isEmpty()) return@forEachIndexed
            if (tokens.any { token ->
                    Regex("\\b" + Regex.escape(token) + "\\b").containsMatchIn(text)
                }
            ) {
                return index
            }
        }
        text.split(" ").forEach { w ->
            ORDINAL_WORDS[w]?.let { return it }
        }
        if (GENERIC_PRIME_HINTS.any { text.contains(it) }) return 0
        return null
    }

    private fun volumeCommand(text: String): AppCommand? {
        val volume = text.contains("volume") || text.contains("awaaz") || text.contains("awaz") ||
            text.contains("sound")
        if (!volume) return null
        val up = text.contains("up") || text.contains("badha") || text.contains("bada") ||
            text.contains("increase") || text.contains("inc") || text.contains("aur")
        val down = text.contains("down") || text.contains("kam") || text.contains("ghata") ||
            text.contains("ghat") || text.contains("kam karo") || text.contains("low")
        return when {
            text.contains("mute") || text.contains("chup") -> AppCommand(AppCommand.Type.VOLUME_MUTE)
            text.contains("maximum") || text.contains("full") || text.contains("max") || text.contains("poori") ->
                AppCommand(AppCommand.Type.VOLUME_MAX)
            down -> AppCommand(AppCommand.Type.VOLUME_DOWN)
            up -> AppCommand(AppCommand.Type.VOLUME_UP)
            else -> null
        }
    }

    private fun whatsappCommand(text: String): AppCommand? {
        if (!text.contains("whatsapp") && !text.contains("whats app") && !text.contains("watsapp")) {
            return null
        }
        if (CLOSE_VERBS.any { text.contains(it) }) return null

        val cleaned = stripPhrase(text, listOf("whatsapp", "whats app", "watsapp"))
        val isMessage = MESSAGE_VERBS.any { text.contains(it) }
        val isCall = CALL_VERBS.any { text.contains(it) }
        val isOpen = OPEN_VERBS.any { text.contains(it) } && !isMessage

        if (isOpen && !isCall) {
            return AppCommand(AppCommand.Type.OPEN_APP, mapOf("app_name" to "WhatsApp"))
        }
        if (isCall && !isMessage) {
            val name = extractName(stripPhrase(cleaned, CALL_VERBS)) ?: return null
            return AppCommand(AppCommand.Type.WHATSAPP_CALL, mapOf("name" to name))
        }
        if (isMessage || isOpen || isCall) {
            val (name, message) = splitNameAndMessage(cleaned)
            if (name.isEmpty()) return null
            return AppCommand(
                AppCommand.Type.WHATSAPP_MSG,
                mapOf("name" to name, "message" to message)
            )
        }
        val name = extractName(cleaned).orEmpty()
        if (name.isEmpty()) return null
        return AppCommand(AppCommand.Type.WHATSAPP_MSG, mapOf("name" to name, "message" to ""))
    }

    /**
     * Answers a pending social gate. Only a whole utterance that is nothing but the
     * confirmation word counts, so a normal sentence is never mistaken for a yes.
     */
    private fun socialGateReply(text: String): AppCommand? = when {
        SOCIAL_CONFIRM_WORDS.any { text == it } ->
            AppCommand(AppCommand.Type.SOCIAL_CONFIRM, mapOf("platform" to pendingPlatform))

        SOCIAL_REJECT_WORDS.any { text == it } ->
            AppCommand(AppCommand.Type.SOCIAL_REJECT, mapOf("platform" to pendingPlatform))

        SOCIAL_DONE_WORDS.any { text == it } ->
            AppCommand(AppCommand.Type.SOCIAL_RESUME, mapOf("platform" to pendingPlatform))

        else -> null
    }

    private fun socialCommand(text: String): AppCommand? {        val hasInstagram = Regex("\\b(instagram|insta|ig)\\b").containsMatchIn(text)
        val hasFacebook = Regex("\\b(facebook|fb)\\b").containsMatchIn(text)
        if (!hasInstagram && !hasFacebook) return null
        val platform = if (hasInstagram) "instagram" else "facebook"

        if (SOCIAL_CONFIRM_WORDS.any { text == it }) {
            return AppCommand(AppCommand.Type.SOCIAL_CONFIRM, mapOf("platform" to platform))
        }
        if (SOCIAL_REJECT_WORDS.any { text == it }) {
            return AppCommand(AppCommand.Type.SOCIAL_REJECT, mapOf("platform" to platform))
        }
        if (SOCIAL_STATUS_WORDS.any { text == it }) {
            return AppCommand(AppCommand.Type.SOCIAL_STATUS, mapOf("platform" to platform))
        }

        val isStory = text.contains("story")
        val isReel = text.contains("reel")
        val isText = text.contains("text") || text.contains("likh") || text.contains("message")
        val hasPostVerb = SOCIAL_POST_VERBS.any { text.contains(it) }
        if (!isStory && !isReel && !hasPostVerb) return null
        if (isStory && hasInstagram && text.contains("story") && !hasPostVerb) {
            // "instagram story" alone is an open, not a post
            if (!SOCIAL_POST_VERBS.any { text.contains(it) }) return null
        }

        val action = when {
            isStory -> "post_story"
            isReel -> "post_reel"
            isText -> "post_text"
            else -> "post_media"
        }

        val caption = extractCaption(text)
        return AppCommand(
            AppCommand.Type.SOCIAL_POST,
            mapOf(
                "platform" to platform,
                "action" to action,
                "media_uri" to "",
                "caption" to caption,
                "mode" to if (text.contains("draft")) "draft" else "publish"
            )
        )
    }

    private fun extractCaption(text: String): String {
        val markers = listOf("caption", "likh", "sath", "ke sath", "with", "text", "saying", "bol")
        var best = ""
        markers.forEach { marker ->
            if (!text.contains(marker)) return@forEach
            val after = text.substringAfter(marker).trim()
            if (after.length > best.length) best = after
        }
        if (best.isBlank()) return ""
        val cleanup = listOf(
            "karo", "kro", "kar", "do", "par", "pe", "par", "ko", "aur", "please", "post",
            "instagram", "facebook", "insta", "fb", "story", "reel", "photo", "picture", "video"
        )
        return best
            .split(" ")
            .filter { it.isNotBlank() && !cleanup.contains(it) }
            .joinToString(" ")
            .trim()
    }

    private val SOCIAL_POST_VERBS = listOf(
        "post", "post karo", "post kro", "post kar", "post kar do", "daal", "daalo",
        "dalo", "lagana", "lagao", "laga do", "publish", "share karo"
    )

    private val SOCIAL_CONFIRM_WORDS = listOf(
        "haan", "han", "yes", "ha", "post karo", "post kar do", "kar do", "bhej do",
        "publish karo", "ho jaye", "chal", "chalo", "theek hai", "kar de"
    )

    private val SOCIAL_REJECT_WORDS = listOf(
        "nahi", "no", "rehne de", "mat karo", "cancel", "ruk", "stop", "mat karna"
    )

    private val SOCIAL_STATUS_WORDS = listOf(
        "kya hua", "status", "kya hua post", "post hua ya", "check karo"
    )

    private val SOCIAL_DONE_WORDS = listOf(
        "done", "ho gaya", "ho gaya hai", "kar diya", "ready hai", "le lo", "theek hai"
    )

    private val pendingPlatform: String
        get() = AccessibilityHelperService.instance?.activeTask()?.platform?.name?.lowercase() ?: ""

    private fun appCommand(text: String): AppCommand? {
        val app = APP_ALIASES.firstOrNull { alias ->
            Regex("\\b" + Regex.escape(alias) + "\\b").containsMatchIn(text)
        } ?: return null

        val close = CLOSE_VERBS.any { text.contains(it) }
        val open = OPEN_VERBS.any { text.contains(it) }

        return when {
            close -> AppCommand(AppCommand.Type.CLOSE_APP, mapOf("app_name" to app))
            open -> AppCommand(AppCommand.Type.OPEN_APP, mapOf("app_name" to app))
            else -> null
        }
    }

    private fun smsCommand(text: String): AppCommand? {
        val hasSmsVerb = text.contains("sms") || text.contains("message") || text.contains("msg") ||
            text.contains("text ") || text.contains("bhej")
        if (!hasSmsVerb) return null
        val cleaned = stripPhrase(text, listOf("sms", "message", "msg", "text"))
        val (name, message) = splitNameAndMessage(cleaned)
        if (name.isEmpty()) return null
        return AppCommand(AppCommand.Type.SMS, mapOf("name" to name, "message" to message))
    }

    private fun callCommand(text: String): AppCommand? {
        if (text.contains("ringtone")) return null
        if (text.length > 60) return null
        if (CALL_VERBS.none { text.contains(it) }) return null
        val cleaned = stripPhrase(text, CALL_VERBS)
        val name = extractName(cleaned) ?: return null
        if (name.isEmpty()) return null
        val words = name.split(" ")
        if (words.any { word -> NAME_NOISE.contains(word) }) return null
        if (APP_ALIASES.any { Regex("\\b" + Regex.escape(it) + "\\b").containsMatchIn(name) }) {
            return null
        }
        return AppCommand(AppCommand.Type.CALL, mapOf("name" to name))
    }

    private fun searchCommand(text: String): AppCommand? {
        val isSearch = text.contains("search") || text.contains("google") || text.contains("dhundo") ||
            text.contains("find out")
        if (!isSearch) return null
        val query = listOf("search karo", "search kro", "search kar", "search", "google karo", "google kro", "google kar", "google", "dhundo", "find out")
            .firstOrNull { text.contains(it) }
            ?.let { text.substringAfter(it).trim() }
            ?: return null
        if (query.isBlank()) return null
        return AppCommand(AppCommand.Type.SEARCH, mapOf("query" to query))
    }

    private fun splitNameAndMessage(text: String): Pair<String, String> {
        val koIdx = indexOfWord(text, "ko")
        if (koIdx >= 0) {
            val name = text.substring(0, koIdx).trim()
            val message = text.substring(koIdx + 2).trim()
            return stripMessageVerbs(name) to stripMessageVerbs(message)
        }
        return extractName(text).orEmpty() to ""
    }

    private fun stripMessageVerbs(s: String): String = s
        .split(" ")
        .filter { it.isNotBlank() && !CONTACT_STOPWORDS.contains(it) }
        .joinToString(" ")
        .trim()

    private fun extractName(text: String): String? {
        val words = text.split(" ")
            .filter { it.isNotBlank() }
            .filterNot { FILLER.contains(it) }
            .filterNot { OFF_WORDS.contains(it) || ON_WORDS.contains(it) }
        if (words.isEmpty()) return null
        val trimmed = words.take(3).joinToString(" ")
        return trimmed.ifBlank { null }
    }

    private fun stripPhrase(text: String, phrases: List<String>): String {
        var out = text
        phrases.forEach { phrase ->
            if (phrase.isBlank()) return@forEach
            val re = Regex("\\b" + Regex.escape(phrase) + "\\b")
            out = re.replace(out, " ")
        }
        return out.replace(Regex("\\s+"), " ").trim()
    }

    private fun indexOfWord(text: String, word: String): Int =
        text.split(" ").indexOfFirst { it == word }

    fun normalize(raw: String): String = raw
        .lowercase()
        .replace(Regex("[^a-z0-9\\u0900-\\u097F\\s]"), " ")
        .replace(Regex("\\s+"), " ")
        .trim()
}
