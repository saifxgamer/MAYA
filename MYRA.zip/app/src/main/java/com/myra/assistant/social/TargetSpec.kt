package com.myra.assistant.social

enum class RegionPreference { TOP, BOTTOM, ANY }

enum class AnchorRelation { LEFT_OF, RIGHT_OF, ABOVE, BELOW }

enum class MatchStrategy(val priority: Int) {
    RESOURCE_ID(1),
    CONTENT_DESCRIPTION(2),
    TEXT_EXACT(3),
    TEXT_NORMALIZED(4),
    SHORT_LABEL_HINT(5),
    CLASS_WITH_NEARBY_TEXT(6),
    STRUCTURAL_ANCHOR(7)
}

data class StructuralAnchor(
    val referenceContentDescription: String? = null,
    val referenceText: String? = null,
    val referenceResourceId: String? = null,
    val candidateClassNames: Set<String> = emptySet(),
    val relation: AnchorRelation = AnchorRelation.LEFT_OF,
    val requireCandidateClickable: Boolean = true,
    val requireSameRow: Boolean = false,
    val minGapPx: Int = 0,
    val maxGapPx: Int = 100_000,
    val region: RegionPreference = RegionPreference.ANY
)

data class TargetSpec(
    val name: String,
    val resourceId: String? = null,
    val contentDescription: String? = null,
    val text: String? = null,
    val shortLabelHint: String? = null,
    val className: String? = null,
    val nearbyText: String? = null,
    val anchor: StructuralAnchor? = null,
    val packageNames: Set<String> = emptySet(),
    val requireClickable: Boolean = true,
    val requireEnabled: Boolean = true,
    val requireEditable: Boolean = false,
    val requireUniqueMatch: Boolean = false,
    val excludeTexts: List<String> = emptyList(),
    val excludeResourceIds: List<String> = emptyList(),
    val region: RegionPreference = RegionPreference.ANY,
    val maxHintLabelLength: Int = 48
) {
    init {
        require(name.isNotBlank()) { "TargetSpec name must not be blank" }
    }

    fun hasStrategy(): Boolean =
        resourceId != null || contentDescription != null || text != null ||
            shortLabelHint != null || className != null || anchor != null
}

sealed class ResolveResult {
    data class Resolved(
        val element: UiElement,
        val strategy: MatchStrategy,
        val alternates: Int = 0,
        /** The spec that produced this match, so callers never have to guess which one won. */
        val spec: TargetSpec? = null
    ) : ResolveResult()

    data class Ambiguous(
        val spec: TargetSpec,
        val candidates: List<UiElement>,
        val reason: String = "more than one element matched"
    ) : ResolveResult()

    data class NotFound(
        val spec: TargetSpec,
        val reason: String
    ) : ResolveResult()

    val elementOrNull: UiElement? get() = (this as? Resolved)?.element
}
