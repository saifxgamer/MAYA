package com.myra.assistant.ai

import android.os.Handler
import android.os.Looper
import android.util.Base64
import android.util.Log
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

data class LiveConfig(
    val apiKey: String,
    val model: String,
    val voice: String,
    val systemInstruction: String,
    val temperature: Double = 0.9,
    val responseModalities: List<String> = listOf("AUDIO"),
    val toolDeclarations: JSONArray = JSONArray()
)

interface LiveListener {
    fun onConnecting() {}
    fun onSetupComplete() {}
    fun onAudioReceived(data: ByteArray) {}
    fun onOutputTranscript(text: String) {}
    fun onInputTranscript(text: String) {}
    fun onTurnComplete() {}
    fun onInterrupted() {}
    fun onDisconnected(reason: String) {}
    fun onError(message: String) {}
    fun onToolCall(id: String, name: String, args: JSONObject) {}
}

class GeminiLiveClient(
    private val config: LiveConfig,
    private val listener: LiveListener
) {

    companion object {
        private const val TAG = "GeminiLive"
        const val BASE_URL =
            "wss://generativelanguage.googleapis.com/ws/google.ai.generativelanguage.v1alpha.GenerativeService.BidiGenerateContent"
        const val SESSION_RENEW_AFTER_MS = 540_000L
        const val KEEPALIVE_INTERVAL_MS = 8_000L
        const val RECONNECT_DELAY_MS = 3_000L
        const val SILENT_CHUNK_BYTES = 1024
        private const val INPUT_MIME = "audio/pcm;rate=16000"
        private const val OUTPUT_MIME_PREFIX = "audio/pcm;rate=24000"
    }

    private val main = Handler(Looper.getMainLooper())
    private val silentChunk = ByteArray(SILENT_CHUNK_BYTES)

    private val httpClient: OkHttpClient = OkHttpClient.Builder()
        .readTimeout(0, TimeUnit.MILLISECONDS)
        .writeTimeout(10, TimeUnit.SECONDS)
        .connectTimeout(15, TimeUnit.SECONDS)
        .retryOnConnectionFailure(true)
        .build()

    private var webSocket: WebSocket? = null
    private var running = false
    private var reconnectScheduled = false
    private var sessionStartedAt = 0L
    private var isSetupComplete = false

    private val keepAliveRunnable = object : Runnable {
        override fun run() {
            if (!running) return
            if (isSetupComplete) sendSilentChunk()
            main.postDelayed(this, KEEPALIVE_INTERVAL_MS)
        }
    }

    private val renewCheckRunnable = object : Runnable {
        override fun run() {
            if (!running) return
            if (sessionStartedAt > 0 &&
                System.currentTimeMillis() - sessionStartedAt >= SESSION_RENEW_AFTER_MS
            ) {
                Log.i(TAG, "Session renewal threshold reached, rotating socket")
                sessionStartedAt = 0L
                val socket = webSocket
                webSocket = null
                isSetupComplete = false
                socket?.close(1000, "session renewal")
                scheduleReconnect(600L)
            }
            main.postDelayed(this, 30_000L)
        }
    }

    val isConnected: Boolean get() = webSocket != null

    val sessionAgeMs: Long
        get() = if (sessionStartedAt == 0L) 0L else System.currentTimeMillis() - sessionStartedAt

    fun connect() {
        if (running) return
        running = true
        main.removeCallbacks(keepAliveRunnable)
        main.removeCallbacks(renewCheckRunnable)
        main.postDelayed(keepAliveRunnable, KEEPALIVE_INTERVAL_MS)
        main.postDelayed(renewCheckRunnable, 30_000L)
        openSocket()
    }

    fun disconnect() {
        running = false
        reconnectScheduled = false
        isSetupComplete = false
        sessionStartedAt = 0L
        main.removeCallbacks(keepAliveRunnable)
        main.removeCallbacks(renewCheckRunnable)
        val socket = webSocket
        webSocket = null
        socket?.close(1000, "client disconnect")
    }

    fun sendAudioChunk(pcm: ByteArray) {
        if (pcm.isEmpty()) return
        val mediaChunk = JSONObject().apply {
            put("mimeType", INPUT_MIME)
            put("mime_type", INPUT_MIME)
            put("data", Base64.encodeToString(pcm, Base64.NO_WRAP))
        }
        val chunks = JSONArray().put(mediaChunk)
        val realtimeInput = JSONObject().apply {
            put("mediaChunks", chunks)
            put("media_chunks", chunks)
        }
        val root = JSONObject().apply {
            put("realtimeInput", realtimeInput)
            put("realtime_input", realtimeInput)
        }
        rawSend(root)
    }

    fun sendText(text: String) {
        if (text.isBlank()) return
        val part = JSONObject().put("text", text)
        val turns = JSONArray().put(JSONObject().apply {
            put("role", "user")
            put("parts", JSONArray().put(part))
        })
        val clientContent = JSONObject().apply {
            put("turns", turns)
            put("turnComplete", true)
            put("turn_complete", true)
        }
        val root = JSONObject().apply {
            put("clientContent", clientContent)
            put("client_content", clientContent)
        }
        rawSend(root)
    }

    fun sendToolResponse(id: String, name: String, response: JSONObject) {
        val functionResponse = JSONObject().apply {
            put("id", id)
            put("name", name)
            put("response", response)
        }
        val toolResponse = JSONObject().apply {
            put("functionResponses", JSONArray().put(functionResponse))
        }
        val realtimeInput = JSONObject().apply {
            put("toolResponse", toolResponse)
        }
        rawSend(JSONObject().apply {
            put("realtimeInput", realtimeInput)
            put("realtime_input", realtimeInput)
        })
    }

    fun interrupt() {
        val clientContent = JSONObject().apply {
            put("turns", JSONArray())
            put("turnComplete", true)
            put("turn_complete", true)
        }
        val root = JSONObject().apply {
            put("clientContent", clientContent)
            put("client_content", clientContent)
        }
        rawSend(root)
    }

    private fun sendSilentChunk() {
        rawSend(
            JSONObject().apply {
                val chunk = JSONObject().apply {
                    put("mimeType", INPUT_MIME)
                    put("mime_type", INPUT_MIME)
                    put("data", Base64.encodeToString(silentChunk, Base64.NO_WRAP))
                }
                val chunks = JSONArray().put(chunk)
                val realtimeInput = JSONObject().apply {
                    put("mediaChunks", chunks)
                    put("media_chunks", chunks)
                }
                put("realtimeInput", realtimeInput)
                put("realtime_input", realtimeInput)
            }
        )
    }

    private fun sendSetup() {
        val parts = JSONArray().put(JSONObject().put("text", config.systemInstruction))
        val systemInstruction = JSONObject().apply {
            put("parts", parts)
        }

        val voiceConfig = JSONObject().apply {
            put("prebuiltVoiceConfig", JSONObject().apply { put("voiceName", config.voice) })
            put("prebuilt_voice_config", JSONObject().apply { put("voice_name", config.voice) })
        }
        val speechConfig = JSONObject().apply {
            put("voiceConfig", voiceConfig)
            put("voice_config", voiceConfig)
        }

        val generationConfig = JSONObject().apply {
            put("responseModalities", JSONArray(config.responseModalities))
            put("response_modalities", JSONArray(config.responseModalities))
            put("speechConfig", speechConfig)
            put("speech_config", speechConfig)
            put("temperature", config.temperature)
        }

        val tools = JSONArray().put(JSONObject().apply {
            put("functionDeclarations", config.toolDeclarations)
            put("function_declarations", config.toolDeclarations)
        })

        val setup = JSONObject().apply {
            put("model", config.model)
            put("systemInstruction", systemInstruction)
            put("system_instruction", systemInstruction)
            put("generationConfig", generationConfig)
            put("generation_config", generationConfig)
            put("outputAudioTranscription", JSONObject())
            put("output_audio_transcription", JSONObject())
            put("inputAudioTranscription", JSONObject())
            put("input_audio_transcription", JSONObject())
            if (config.toolDeclarations.length() > 0) put("tools", tools)
        }

        rawSend(JSONObject().apply { put("setup", setup) })
        Log.i(TAG, "Setup sent for model=${config.model} voice=${config.voice}")
    }

    private fun rawSend(payload: JSONObject) {
        val socket = webSocket ?: return
        socket.send(payload.toString())
    }

    private fun openSocket() {
        if (!running) return
        if (webSocket != null) return
        val key = config.apiKey.trim()
        if (key.isEmpty()) {
            main.post { listener.onError("Gemini API key missing. Set it in Settings.") }
            return
        }
        main.post { listener.onConnecting() }
        val request = Request.Builder()
            .url("$BASE_URL?key=$key")
            .build()
        webSocket = httpClient.newWebSocket(request, socketListener)
    }

    private fun scheduleReconnect(delayMs: Long = RECONNECT_DELAY_MS) {
        if (!running || reconnectScheduled) return
        reconnectScheduled = true
        main.postDelayed({
            reconnectScheduled = false
            openSocket()
        }, delayMs)
    }

    private val socketListener = object : WebSocketListener() {

        override fun onOpen(webSocket: WebSocket, response: Response) {
            Log.i(TAG, "Socket open")
            sessionStartedAt = System.currentTimeMillis()
            isSetupComplete = false
            sendSetup()
        }

        override fun onMessage(webSocket: WebSocket, text: String) {
            handleMessage(text)
        }

        override fun onClosing(webSocket: WebSocket, code: Int, reason: String) {
            Log.i(TAG, "Socket closing: $code $reason")
            this@GeminiLiveClient.webSocket = null
            isSetupComplete = false
            main.post { listener.onDisconnected(reason.ifBlank { "closing" }) }
        }

        override fun onClosed(webSocket: WebSocket, code: Int, reason: String) {
            Log.i(TAG, "Socket closed: $code $reason")
            if (this@GeminiLiveClient.webSocket === webSocket) {
                this@GeminiLiveClient.webSocket = null
            }
            isSetupComplete = false
            main.post { listener.onDisconnected(reason.ifBlank { "closed" }) }
            scheduleReconnect()
        }

        override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
            Log.e(TAG, "Socket failure: ${t.message}")
            if (this@GeminiLiveClient.webSocket === webSocket) {
                this@GeminiLiveClient.webSocket = null
            }
            isSetupComplete = false
            val code = response?.code
            if (code != null && code in 400..499 && code != 429) {
                main.post { listener.onError("Connection rejected ($code). Check API key and model.") }
            } else {
                main.post { listener.onError("Connection lost: ${t.message ?: "network error"}") }
            }
            scheduleReconnect()
        }
    }

    private fun handleMessage(text: String) {
        val json = try {
            JSONObject(text)
        } catch (e: Exception) {
            Log.w(TAG, "Unparsable message: ${text.take(120)}")
            return
        }

        json.optAny("error")?.let { err ->
            val msg = err.optString("message", err.toString())
            main.post { listener.onError(msg) }
            return
        }

        if (json.optAny("setupComplete") != null || json.optAny("setup_complete") != null) {
            isSetupComplete = true
            sessionStartedAt = System.currentTimeMillis()
            main.post { listener.onSetupComplete() }
            return
        }

        val serverContent = json.optAny("serverContent") ?: json.optAny("server_content")
        if (serverContent != null) {
            handleServerContent(serverContent)
        }

        val toolCall = json.optAny("toolCall") ?: json.optAny("tool_call")
        if (toolCall != null) {
            handleToolCall(toolCall)
        }
    }

    private fun handleToolCall(container: JSONObject) {
        val calls = container.optJSONArray("functionCalls")
            ?: container.optJSONArray("function_calls")
            ?: return
        for (i in 0 until calls.length()) {
            val call = calls.optJSONObject(i) ?: continue
            val id = call.optString("id", "call_$i")
            val name = call.optString("name", "")
            if (name.isBlank()) continue
            val args = call.optJSONObject("args") ?: call.optJSONObject("arguments") ?: JSONObject()
            main.post { listener.onToolCall(id, name, args) }
        }
    }

    private fun handleServerContent(serverContent: JSONObject) {
        val modelTurn = serverContent.optAny("modelTurn") ?: serverContent.optAny("model_turn")
        if (modelTurn != null) {
            val parts = modelTurn.optJSONArray("parts") ?: JSONArray()
            for (i in 0 until parts.length()) {
                val part = parts.optJSONObject(i) ?: continue
                val inline = part.optAny("inlineData") ?: part.optAny("inline_data") ?: continue
                val mime = inline.optString("mimeType", inline.optString("mime_type", ""))
                if (!mime.contains("audio/pcm")) continue
                val b64 = inline.optString("data", "")
                if (b64.isBlank()) continue
                val bytes = try {
                    Base64.decode(b64, Base64.NO_WRAP)
                } catch (e: Exception) {
                    Log.w(TAG, "Bad base64 audio payload: ${e.message}")
                    continue
                }
                if (bytes.isEmpty()) continue
                main.post { listener.onAudioReceived(bytes) }
            }
        }

        val outputTranscript =
            serverContent.optAny("outputTranscription") ?: serverContent.optAny("output_transcription")
        outputTranscript?.optString("text", "")?.let { t ->
            if (t.isNotBlank()) main.post { listener.onOutputTranscript(t) }
        }

        val inputTranscript =
            serverContent.optAny("inputTranscription") ?: serverContent.optAny("input_transcription")
        inputTranscript?.optString("text", "")?.let { t ->
            if (t.isNotBlank()) main.post { listener.onInputTranscript(t) }
        }

        if (serverContent.optBoolean("turnComplete", false) ||
            serverContent.optBoolean("turn_complete", false)
        ) {
            main.post { listener.onTurnComplete() }
        }

        if (serverContent.optBoolean("interrupted", false)) {
            main.post { listener.onInterrupted() }
        }
    }

    private fun JSONObject.optAny(key: String): JSONObject? =
        if (has(key) && !isNull(key)) optJSONObject(key) else null
}
