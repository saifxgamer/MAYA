package com.myra.assistant.service

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.util.Log
import com.myra.assistant.social.PendingMedia
import com.myra.assistant.social.SocialPlatform

class ShareTargetPicker(private val context: Context) {

    data class Candidate(
        val activityClass: String,
        val label: String
    )

    fun isInstalled(platform: SocialPlatform): Boolean = platform.packages.any { pkg ->
        try {
            context.packageManager.getPackageInfo(pkg, 0)
            true
        } catch (_: Exception) {
            false
        }
    }

    fun handlers(platform: SocialPlatform, mimeType: String): List<Candidate> {
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = mimeType
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        return try {
            val flags = android.content.pm.PackageManager.MATCH_DEFAULT_ONLY
            val resolved = context.packageManager.queryIntentActivities(intent, flags)
            resolved.mapNotNull { info ->
                val cls = info.activityInfo?.name ?: return@mapNotNull null
                val pkg = info.activityInfo.packageName
                if (!platform.packages.any { pkg == it || pkg.startsWith("$it.") }) return@mapNotNull null
                Candidate(cls, info.loadLabel(context.packageManager)?.toString().orEmpty())
            }
        } catch (e: Exception) {
            Log.e(TAG, "could not query share handlers: ${e.message}")
            emptyList()
        }
    }

    fun hasHandler(platform: SocialPlatform, mimeType: String = "image/*"): Boolean =
        handlers(platform, mimeType).isNotEmpty()

    fun pick(platform: SocialPlatform, mimeType: String = "image/*"): String? {
        val all = handlers(platform, mimeType)
        if (all.isEmpty()) return null

        val safe = all.filterNot { isDangerous(it) }
        if (safe.isEmpty()) return null

        knownClass(platform, safe)?.let { return it }
        knownClass(platform, all)?.let { return it }

        val byLabel = safe.firstOrNull { candidate ->
            platform.packages.any { pkg ->
                candidate.label.contains(pkg.substringAfterLast('.'), ignoreCase = true)
            }
        }
        if (byLabel != null && safe.size == 1) return byLabel.activityClass

        if (safe.size == 1) return safe.first().activityClass
        return null
    }

    private fun knownClass(platform: SocialPlatform, candidates: List<Candidate>): String? {
        val known = KNOWN[platform].orEmpty()
        return candidates.firstOrNull { candidate ->
            known.any { it.equals(candidate.activityClass, ignoreCase = true) }
        }?.activityClass
            ?: candidates.firstOrNull { candidate ->
                known.any { candidate.activityClass.endsWith(it, ignoreCase = true) }
            }?.activityClass
    }

    private fun isDangerous(candidate: Candidate): Boolean {
        val haystack = "${candidate.activityClass} ${candidate.label}".lowercase()
        return BLOCKED_TOKENS.any { haystack.contains(it) }
    }

    fun buildSendIntent(platform: SocialPlatform, activityClass: String, media: PendingMedia): Intent? {
        // The activity belongs to another app, so its Class object is not loadable here.
        // Build the component from strings instead of Class.forName.
        val packageName = activityClass.substringBefore('.').takeIf { it.isNotEmpty() }
            ?: return null
        val shortName = activityClass.substringAfterLast('.').takeIf { it.isNotEmpty() }
            ?: return null
        val target = ComponentName(packageName, "$packageName.$shortName")
        if (!platform.packages.any { packageName == it || packageName.startsWith("$it.") }) return null
        val uri = try {
            Uri.parse(media.uri)
        } catch (e: Exception) {
            return null
        }
        if (uri.scheme != "content" || !uri.authority.equals(FILE_PROVIDER_AUTHORITY, ignoreCase = true)) {
            Log.e(TAG, "refusing to share a uri outside the MYRA inbox")
            return null
        }

        val intent = Intent(Intent.ACTION_SEND).apply {
            component = target
            type = media.mimeType
            putExtra(Intent.EXTRA_STREAM, uri)
            clipData = android.content.ClipData.newRawUri("media", uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP)
        }
        intent.setPackage(packageName)
        return intent
    }

    fun send(platform: SocialPlatform, activityClass: String, media: PendingMedia): Boolean {
        val intent = buildSendIntent(platform, activityClass, media) ?: return false
        return try {
            context.startActivity(intent)
            true
        } catch (e: Exception) {
            Log.e(TAG, "share intent failed: ${e.message}")
            false
        }
    }

    fun launchApp(platform: SocialPlatform): Boolean {
        val intent = context.packageManager.getLaunchIntentForPackage(platform.packages.first())
            ?: return false
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return try {
            context.startActivity(intent)
            true
        } catch (e: Exception) {
            Log.e(TAG, "launch failed: ${e.message}")
            false
        }
    }

    companion object {
        private const val TAG = "ShareTargetPicker"
        private const val FILE_PROVIDER_AUTHORITY = "com.myra.assistant.fileprovider"

        private val KNOWN = mapOf(
            SocialPlatform.INSTAGRAM to listOf(
                "ShareHandlerActivity",
                "StoryShareHandlerActivity",
                "ReelShareHandlerActivity"
            ),
            SocialPlatform.FACEBOOK to listOf(
                "ImplicitShareIntentHandler",
                "InspirationCameraShare"
            )
        )

        private val BLOCKED_TOKENS = listOf(
            "direct", "group", "profile", "message", "chat", "inbox", "messenger", "chooser"
        )
    }
}
