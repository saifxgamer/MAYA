package com.myra.assistant.model

import android.content.Context
import android.content.SharedPreferences
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

object MyraPrefs {

    const val FILE = "myra_prefs"

    const val KEY_API_KEY = "api_key"
    const val KEY_USER_NAME = "user_name"
    const val KEY_PERSONALITY = "personality_mode"
    const val KEY_MODEL = "gemini_model"
    const val KEY_VOICE = "gemini_voice"
    const val KEY_PRIME_CONTACTS = "prime_contacts_json"

    const val LEGACY_PRIME_NAME = "prime_name"
    const val LEGACY_PRIME_NUMBER = "prime_number"

    const val DEFAULT_MODEL = "models/gemini-2.5-flash-native-audio-preview-12-2025"
    const val DEFAULT_VOICE = "Aoede"
    const val DEFAULT_USER_NAME = "Boss"

    fun prefs(context: Context): SharedPreferences =
        context.applicationContext.getSharedPreferences(FILE, Context.MODE_PRIVATE)

    var apiKey: String = ""
        private set
    var userName: String = DEFAULT_USER_NAME
        private set
    var personality: PersonalityMode = PersonalityMode.GF
        private set
    var model: String = DEFAULT_MODEL
        private set
    var voice: String = DEFAULT_VOICE
        private set

    fun load(context: Context) {
        val p = prefs(context)
        apiKey = p.getString(KEY_API_KEY, "").orEmpty()
        userName = p.getString(KEY_USER_NAME, DEFAULT_USER_NAME)?.takeIf { it.isNotBlank() }
            ?: DEFAULT_USER_NAME
        personality = PersonalityMode.fromKey(p.getString(KEY_PERSONALITY, PersonalityMode.GF.key))
        model = p.getString(KEY_MODEL, DEFAULT_MODEL) ?: DEFAULT_MODEL
        voice = p.getString(KEY_VOICE, DEFAULT_VOICE) ?: DEFAULT_VOICE
    }

    fun save(
        context: Context,
        apiKey: String,
        userName: String,
        personality: PersonalityMode,
        model: String,
        voice: String
    ) {
        val p = prefs(context)
        p.edit()
            .putString(KEY_API_KEY, apiKey.trim())
            .putString(KEY_USER_NAME, userName.trim().ifEmpty { DEFAULT_USER_NAME })
            .putString(KEY_PERSONALITY, personality.key)
            .putString(KEY_MODEL, model)
            .putString(KEY_VOICE, voice)
            .apply()
        load(context)
    }

    fun primeContacts(context: Context): List<PrimeContact> {
        val p = prefs(context)
        val stored = PrimeContact.listFromJson(p.getString(KEY_PRIME_CONTACTS, null))
        if (stored.isNotEmpty()) return stored
        val legacyName = p.getString(LEGACY_PRIME_NAME, null)?.trim().orEmpty()
        val legacyNumber = p.getString(LEGACY_PRIME_NUMBER, null)?.trim().orEmpty()
        if (legacyName.isEmpty() || legacyNumber.isEmpty()) return emptyList()
        val migrated = listOf(PrimeContact(legacyName, legacyNumber))
        p.edit()
            .putString(KEY_PRIME_CONTACTS, PrimeContact.listToJson(migrated))
            .remove(LEGACY_PRIME_NAME)
            .remove(LEGACY_PRIME_NUMBER)
            .apply()
        return migrated
    }

    fun savePrimeContacts(context: Context, contacts: List<PrimeContact>) {
        prefs(context).edit()
            .putString(KEY_PRIME_CONTACTS, PrimeContact.listToJson(contacts))
            .apply()
    }

    fun currentDateTime(): String = try {
        val fmt = SimpleDateFormat("EEEE, d MMMM yyyy, h:mm a", Locale.getDefault())
        fmt.format(Date())
    } catch (_: Exception) {
        Calendar.getInstance().time.toString()
    }
}
