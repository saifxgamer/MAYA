package com.myra.assistant.ui.settings

import android.app.AlertDialog
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.myra.assistant.R
import com.myra.assistant.databinding.ActivitySettingsBinding
import com.myra.assistant.databinding.DialogAddPrimeContactBinding
import com.myra.assistant.databinding.ItemPrimeContactBinding
import com.myra.assistant.model.MyraPrefs
import com.myra.assistant.model.PersonalityMode
import com.myra.assistant.model.PrimeContact
import com.myra.assistant.service.AccessibilityHelperService
import com.myra.assistant.ui.social.SocialDebugActivity
import android.view.View

class SettingsActivity : AppCompatActivity() {

    private lateinit var binding: ActivitySettingsBinding
    private lateinit var primeAdapter: PrimeContactAdapter
    private var contacts: MutableList<PrimeContact> = mutableListOf()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySettingsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        MyraPrefs.load(this)
        binding.apiKeyInput.setText(MyraPrefs.apiKey)
        binding.userNameInput.setText(MyraPrefs.userName)
        setupSpinners()
        setupPersonality()
        setupPrimeContacts()
        setupStatusViews()

        binding.saveBtn.setOnClickListener { saveAll() }
    }

    override fun onResume() {
        super.onResume()
        refreshAccessibilityStatus()
        refreshApiKeyStatus()
    }

    private fun setupSpinners() {
        val modelLabels = resources.getStringArray(R.array.model_labels)
        val modelValues = resources.getStringArray(R.array.model_values)
        binding.modelSpinner.adapter = ArrayAdapter(
            this,
            android.R.layout.simple_spinner_item,
            modelLabels
        ).apply {
            setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        }
        val modelIndex = modelValues.indexOf(MyraPrefs.model).takeIf { it >= 0 } ?: 0
        binding.modelSpinner.setSelection(modelIndex)

        val voiceLabels = resources.getStringArray(R.array.voice_labels)
        val voiceValues = resources.getStringArray(R.array.voice_values)
        binding.voiceSpinner.adapter = ArrayAdapter(
            this,
            android.R.layout.simple_spinner_item,
            voiceLabels
        ).apply {
            setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        }
        val voiceIndex = voiceValues.indexOf(MyraPrefs.voice).takeIf { it >= 0 } ?: 0
        binding.voiceSpinner.setSelection(voiceIndex)
    }

    private fun setupPersonality() {
        when (MyraPrefs.personality) {
            PersonalityMode.GF -> binding.personalityGf.isChecked = true
            PersonalityMode.PROFESSIONAL -> binding.personalityProfessional.isChecked = true
            PersonalityMode.ASSISTANT -> binding.personalityAssistant.isChecked = true
        }
    }

    private fun currentPersonality(): PersonalityMode = when (binding.personalityGroup.checkedRadioButtonId) {
        R.id.personalityProfessional -> PersonalityMode.PROFESSIONAL
        R.id.personalityAssistant -> PersonalityMode.ASSISTANT
        else -> PersonalityMode.GF
    }

    private fun setupPrimeContacts() {
        contacts = MyraPrefs.primeContacts(this).toMutableList()
        primeAdapter = PrimeContactAdapter(contacts) { position ->
            if (position in contacts.indices) {
                contacts.removeAt(position)
                primeAdapter.notifyItemRemoved(position)
                primeAdapter.notifyItemRangeChanged(position, contacts.size)
                updateEmptyState()
                MyraPrefs.savePrimeContacts(this, contacts)
                toast(getString(R.string.contact_deleted))
            }
        }
        binding.primeContactRecycler.layoutManager = LinearLayoutManager(this)
        binding.primeContactRecycler.adapter = primeAdapter
        primeAdapter.notifyDataSetChanged()
        updateEmptyState()

        binding.addContactBtn.setOnClickListener { showAddDialog() }
    }

    private fun updateEmptyState() {
        binding.primeEmptyText.visibility = if (contacts.isEmpty()) View.VISIBLE else View.GONE
    }

    private fun showAddDialog() {
        val dialogBinding = DialogAddPrimeContactBinding.inflate(LayoutInflater.from(this))
        val dialog = AlertDialog.Builder(this)
            .setTitle(getString(R.string.dialog_add_title))
            .setView(dialogBinding.root)
            .setPositiveButton(getString(R.string.dialog_add)) { _, _ ->
                val name = dialogBinding.dialogNameInput.text.toString().trim()
                val number = dialogBinding.dialogNumberInput.text.toString().trim()
                if (name.isEmpty() || number.isEmpty()) {
                    toast(getString(R.string.dialog_invalid))
                    return@setPositiveButton
                }
                contacts.add(PrimeContact(name, number))
                primeAdapter.notifyItemInserted(contacts.size - 1)
                updateEmptyState()
                MyraPrefs.savePrimeContacts(this, contacts)
            }
            .setNegativeButton(getString(R.string.dialog_cancel), null)
            .create()
        dialog.show()
    }

    private fun setupStatusViews() {
        binding.accessibilityStatus.setOnClickListener {
            runCatching { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        }
        binding.socialDebugBtn.setOnClickListener {
            runCatching { startActivity(Intent(this, SocialDebugActivity::class.java)) }
        }
    }

    private fun refreshAccessibilityStatus() {
        val enabled = AccessibilityHelperService.isEnabled(this)
        binding.accessibilityStatus.text = getString(
            if (enabled) R.string.accessibility_on else R.string.accessibility_off
        )
        binding.accessibilityStatus.setTextColor(
            getColor(if (enabled) R.color.myra_green else R.color.myra_red)
        )
    }

    private fun refreshApiKeyStatus() {
        val key = binding.apiKeyInput.text.toString().trim()
        if (key.isEmpty()) {
            binding.apiKeyStatus.text = getString(R.string.settings_api_key_missing)
            binding.apiKeyStatus.setTextColor(getColor(R.color.myra_red))
        } else {
            val masked = if (key.length > 8) {
                "${key.take(4)}…${key.takeLast(4)}"
            } else {
                "••••"
            }
            binding.apiKeyStatus.text = "API KEY SET ✅ $masked"
            binding.apiKeyStatus.setTextColor(getColor(R.color.myra_green))
        }
    }

    private fun saveAll() {
        val modelValues = resources.getStringArray(R.array.model_values)
        val voiceValues = resources.getStringArray(R.array.voice_values)
        val model = modelValues.getOrNull(binding.modelSpinner.selectedItemPosition) ?: MyraPrefs.DEFAULT_MODEL
        val voice = voiceValues.getOrNull(binding.voiceSpinner.selectedItemPosition) ?: MyraPrefs.DEFAULT_VOICE

        MyraPrefs.save(
            context = this,
            apiKey = binding.apiKeyInput.text.toString(),
            userName = binding.userNameInput.text.toString(),
            personality = currentPersonality(),
            model = model,
            voice = voice
        )
        MyraPrefs.savePrimeContacts(this, contacts)
        refreshApiKeyStatus()
        toast(getString(R.string.settings_saved))
    }

    private fun toast(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }
}

class PrimeContactAdapter(
    private val items: List<PrimeContact>,
    private val onDelete: (Int) -> Unit
) : androidx.recyclerview.widget.RecyclerView.Adapter<PrimeContactAdapter.Holder>() {

    class Holder(val binding: ItemPrimeContactBinding) :
        androidx.recyclerview.widget.RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): Holder =
        Holder(ItemPrimeContactBinding.inflate(LayoutInflater.from(parent.context), parent, false))

    override fun onBindViewHolder(holder: Holder, position: Int) {
        val contact = items[position]
        holder.binding.primeItemName.text = contact.name
        holder.binding.primeItemNumber.text = contact.number
        holder.binding.primeItemDelete.setOnClickListener {
            onDelete(holder.bindingAdapterPosition)
        }
    }

    override fun getItemCount(): Int = items.size
}
