package com.myra.assistant.service

import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Build
import android.os.SystemClock
import android.util.Log
import android.view.Gravity
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.ImageButton
import com.myra.assistant.R
import com.myra.assistant.ui.main.MainActivity
import com.myra.assistant.ui.main.OrbAnimationView
import kotlin.math.abs

class MyraOverlayService : Service() {

    companion object {
        private const val TAG = "MyraOverlay"
        const val CHANNEL_ID = "myra_overlay_channel"
        const val NOTIFICATION_ID = 4202
        private const val TOUCH_SLOP = 8f
        private const val TAP_TIMEOUT_MS = 260L

        @Volatile
        var isRunning: Boolean = false
            private set

        fun start(context: Context) {
            val intent = Intent(context, MyraOverlayService::class.java)
            runCatching {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    context.startForegroundService(intent)
                } else {
                    context.startService(intent)
                }
            }.onFailure { Log.e(TAG, "could not start overlay: ${it.message}") }
        }

        fun stop(context: Context) {
            runCatching {
                context.stopService(Intent(context, MyraOverlayService::class.java))
            }
        }
    }

    private var windowManager: WindowManager? = null
    private var overlayView: View? = null
    private var params: WindowManager.LayoutParams? = null
    private var initialX = 0
    private var initialY = 0
    private var initialTouchX = 0f
    private var initialTouchY = 0f
    private var touchDownAt = 0L
    private var dragged = false

    override fun onBind(intent: Intent?) = null

    override fun onCreate() {
        super.onCreate()
        isRunning = true
        Fgs.ensureChannel(this, CHANNEL_ID, getString(R.string.overlay_notif_channel))
        Fgs.startSafe(
            this,
            NOTIFICATION_ID,
            Fgs.buildNotification(this, CHANNEL_ID, "MYRA is floating", "Tap the orb to open MYRA"),
            Fgs.typeNone()
        )
        showOverlay()
    }

    private fun showOverlay() {
        if (overlayView != null) return
        val wm = getSystemService(Context.WINDOW_SERVICE) as? WindowManager ?: return
        windowManager = wm

        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        val layoutParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 40
            y = 260
        }
        params = layoutParams

        val view = LayoutInflater.from(this).inflate(R.layout.overlay_orb, null)
        overlayView = view

        val orb = view.findViewById<OrbAnimationView>(R.id.overlayOrbView)
        orb.setState(OrbAnimationView.State.ACTIVE)

        val close = view.findViewById<ImageButton>(R.id.overlayCloseBtn)
        close.setOnClickListener {
            runCatching { wm.removeView(view) }
            overlayView = null
            stopSelf()
        }

        view.setOnTouchListener { _, event ->
            onTouch(event, layoutParams)
            true
        }

        runCatching { wm.addView(view, layoutParams) }
            .onFailure { Log.e(TAG, "addView failed: ${it.message}") }
    }

    private fun onTouch(event: MotionEvent, layoutParams: WindowManager.LayoutParams): Boolean {
        when (event.action) {
            MotionEvent.ACTION_DOWN -> {
                initialX = layoutParams.x
                initialY = layoutParams.y
                initialTouchX = event.rawX
                initialTouchY = event.rawY
                touchDownAt = SystemClock.elapsedRealtime()
                dragged = false
                return true
            }

            MotionEvent.ACTION_MOVE -> {
                val dx = event.rawX - initialTouchX
                val dy = event.rawY - initialTouchY
                if (!dragged && (abs(dx) > TOUCH_SLOP || abs(dy) > TOUCH_SLOP)) {
                    dragged = true
                }
                if (dragged) {
                    layoutParams.x = initialX + dx.toInt()
                    layoutParams.y = initialY + dy.toInt()
                    overlayView?.let { runCatching { windowManager?.updateViewLayout(it, layoutParams) } }
                }
                return true
            }

            MotionEvent.ACTION_UP -> {
                val quick = (SystemClock.elapsedRealtime() - touchDownAt) < TAP_TIMEOUT_MS
                if (!dragged && quick) openMain()
                return true
            }

            MotionEvent.ACTION_CANCEL -> return true
        }
        return false
    }

    private fun openMain() {
        val intent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_NEW_TASK or
                Intent.FLAG_ACTIVITY_REORDER_TO_FRONT
        }
        runCatching { startActivity(intent) }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_STICKY

    override fun onDestroy() {
        isRunning = false
        overlayView?.let { view ->
            runCatching { windowManager?.removeView(view) }
        }
        overlayView = null
        windowManager = null
        super.onDestroy()
    }
}
