package com.myra.assistant.service

import android.accessibilityservice.AccessibilityService
import android.content.ComponentName
import android.content.Context
import android.graphics.Path
import android.graphics.Rect
import android.os.Bundle
import android.provider.Settings
import android.util.Log
import android.view.GestureDescription
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.view.accessibility.AccessibilityWindowInfo
import androidx.core.view.accessibility.AccessibilityNodeInfoCompat
import com.myra.assistant.social.ActionFailure
import com.myra.assistant.social.ActionResult
import com.myra.assistant.social.ScrollDirection
import com.myra.assistant.social.SocialAgentHost
import com.myra.assistant.social.SocialMediaAgent
import com.myra.assistant.social.SocialMediaTask
import com.myra.assistant.social.SocialOutcome
import com.myra.assistant.social.SocialRequest
import java.util.ArrayDeque
import java.util.concurrent.CountDownLatch
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.atomic.AtomicReference
import java.util.concurrent.atomic.AtomicLong

class AccessibilityHelperService : AccessibilityService() {

    companion object {
        private const val TAG = "MyraA11y"
        private const val MAX_NODES = 4000

        @Volatile
        var instance: AccessibilityHelperService? = null
            private set

        fun isEnabled(context: Context): Boolean {
            if (instance != null) return true
            return try {
                val expected = ComponentName(context, AccessibilityHelperService::class.java)
                val enabled = Settings.Secure.getString(
                    context.contentResolver,
                    Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
                ) ?: return false
                enabled.split(',').any { entry ->
                    ComponentName.unflattenFromString(entry.trim()) == expected
                }
            } catch (e: Exception) {
                Log.e(TAG, "isEnabled check failed: ${e.message}")
                false
            }
        }
    }

    val isReady: Boolean get() = instance === this

    private val eventCounter = AtomicLong(0L)
    private val windowCounter = AtomicInteger(0)

    private val changeLatch = AtomicReference(CountDownLatch(0))

    @Volatile
    private var socialAgent: SocialMediaAgent? = null

    @Volatile
    private var socialHost: SocialAgentHost? = null

    @Volatile
    var lastSocialOutcome: SocialOutcome? = null
        private set

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        eventCounter.set(0L)
        windowCounter.set(0)
        changeLatch.set(CountDownLatch(0))
        serviceInfo?.let { info ->
            info.eventTypes = info.eventTypes or AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED
        }
        Log.i(TAG, "Accessibility service connected")
    }

    override fun onDestroy() {
        instance = null
        socialAgent = null
        socialHost = null
        super.onDestroy()
    }

    override fun onInterrupt() = Unit

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        eventCounter.incrementAndGet()
        when (event?.eventType) {
            AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED, AccessibilityEvent.TYPE_WINDOWS_CHANGED ->
                windowCounter.incrementAndGet()

            else -> Unit
        }
        releaseWaiters()
    }

    private fun releaseWaiters() {
        changeLatch.getAndSet(CountDownLatch(0)).countDown()
    }

    fun uiEventCounter(): Long = eventCounter.get()

    fun windowStamp(): Int = windowCounter.get()

    fun awaitUiChange(timeoutMs: Long): Boolean {
        val latch = CountDownLatch(1)
        changeLatch.getAndSet(latch)
        return try {
            latch.await(timeoutMs, java.util.concurrent.TimeUnit.MILLISECONDS)
        } catch (e: Exception) {
            false
        }
    }

    fun activeRoot(): AccessibilityNodeInfoCompat? = try {
        rootInActiveWindow
    } catch (e: Exception) {
        null
    }

    fun activePackageName(): String = try {
        rootInActiveWindow?.packageName?.toString().orEmpty()
    } catch (e: Exception) {
        ""
    }

    fun activeWindowClass(): String = try {
        val root = rootInActiveWindow ?: return ""
        val type = root.window?.let { w ->
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.R) w.type else -1
        }
        if (type == AccessibilityWindowInfo.TYPE_APPLICATION_OVERLAY) "OVERLAY" else "WINDOW"
    } catch (e: Exception) {
        ""
    }

    fun tapAt(x: Int, y: Int): ActionResult {
        val path = Path().apply { moveTo(x.toFloat(), y.toFloat()) }
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0L, 60L))
            .build()
        return try {
            val ok = dispatchGesture(gesture, object : GestureResultCallback() {
                override fun onCompleted(description: GestureDescription?) {
                    releaseWaiters()
                }

                override fun onCancelled(description: GestureDescription?) {
                    releaseWaiters()
                }
            }, null)
            if (ok) ActionResult.ok(awaitUiChange(700L)) else ActionResult.fail(ActionFailure.NOT_PERMITTED, "gesture rejected")
        } catch (e: Exception) {
            ActionResult.fail(ActionFailure.NOT_PERMITTED, e.message ?: "gesture failed")
        }
    }

    fun swipe(direction: ScrollDirection): ActionResult {
        val metrics = resources.displayMetrics
        val cx = metrics.widthPixels / 2f
        val startY = metrics.heightPixels * 0.72f
        val endY = metrics.heightPixels * 0.28f
        val startX = metrics.widthPixels * 0.8f
        val endX = metrics.widthPixels * 0.2f
        val path = Path().apply {
            when (direction) {
                ScrollDirection.DOWN -> {
                    moveTo(cx, startY); lineTo(cx, endY)
                }

                ScrollDirection.UP -> {
                    moveTo(cx, endY); lineTo(cx, startY)
                }

                ScrollDirection.RIGHT -> {
                    moveTo(endX, cx); lineTo(startX, cx)
                }

                ScrollDirection.LEFT -> {
                    moveTo(startX, cx); lineTo(endX, cx)
                }
            }
        }
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0L, 320L))
            .build()
        return try {
            val ok = dispatchGesture(gesture, object : GestureResultCallback() {
                override fun onCompleted(description: GestureDescription?) {
                    releaseWaiters()
                }

                override fun onCancelled(description: GestureDescription?) {
                    releaseWaiters()
                }
            }, null)
            if (ok) ActionResult.ok(true) else ActionResult.fail(ActionFailure.NOT_PERMITTED, "swipe rejected")
        } catch (e: Exception) {
            ActionResult.fail(ActionFailure.NOT_PERMITTED, e.message ?: "swipe failed")
        }
    }

    fun closeCurrentApp(): Boolean = performGlobalAction(GLOBAL_ACTION_HOME)

    fun goBack(): Boolean = performGlobalAction(GLOBAL_ACTION_BACK)

    fun openRecents(): Boolean = performGlobalAction(GLOBAL_ACTION_RECENTS)

    fun openNotifications(): Boolean = performGlobalAction(GLOBAL_ACTION_NOTIFICATIONS)

    fun clickOnText(text: String, exact: Boolean = false): Boolean {
        val node = findNode { node ->
            val content = node.text?.toString().orEmpty()
            val desc = node.contentDescription?.toString().orEmpty()
            if (exact) {
                content.equals(text, true) || desc.equals(text, true)
            } else {
                content.contains(text, true) || desc.contains(text, true)
            }
        } ?: return false
        return performClick(node)
    }

    fun typeText(text: String): Boolean {
        val target = findNode { node ->
            node.isEditable || node.className?.contains("EditText", true) == true
        } ?: return false
        val args = Bundle().apply {
            putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
        }
        return target.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
    }

    fun scrollDown(): Boolean = performScroll(true)

    fun scrollUp(): Boolean = performScroll(false)

    fun ensureSocialAgent(host: SocialAgentHost): SocialMediaAgent {
        socialHost = host
        val existing = socialAgent
        if (existing != null) return existing
        val created = SocialMediaAgent(AccessibilityScreenDriver(this), host)
        socialAgent = created
        return created
    }

    fun socialAgentOrNull(): SocialMediaAgent? = socialAgent

    fun recordOutcome(outcome: SocialOutcome) {
        lastSocialOutcome = outcome
    }

    fun activeTask(): SocialMediaTask? = socialAgent?.currentTask

    /**
     * Debug only. Walks the live accessibility tree and returns one line per node so selectors
     * can be written against real bounds and resource ids. Never called by the agent itself.
     */
    fun dumpActiveTree(maxLines: Int = 120): List<String> {
        val root = activeRoot() ?: return listOf("<no active window>")
        val out = ArrayList<String>()
        val queue = ArrayDeque<AccessibilityNodeInfoCompat>()
        queue.add(root)
        var visited = 0
        while (queue.isNotEmpty() && visited < MAX_NODES && out.size < maxLines) {
            val node = queue.poll() ?: break
            visited++
            try {
                val bounds = Rect().also { node.getBoundsInScreen(it) }
                out.add(
                    buildString {
                        append(node.className?.toString().orEmpty().substringAfterLast('.'))
                        append(" id=").append(node.viewIdResourceName.orEmpty())
                        append(" text=").append(node.text?.toString().orEmpty().take(40))
                        append(" desc=").append(node.contentDescription?.toString().orEmpty().take(40))
                        append(" bounds=").append(bounds.left).append(',').append(bounds.top)
                        append('x').append(bounds.width()).append('x').append(bounds.height())
                        append(" clickable=").append(node.isClickable)
                        append(" enabled=").append(node.isEnabled)
                        append(" scrollable=").append(node.isScrollable)
                        append(" editable=").append(node.isEditable)
                    }
                )
                for (i in 0 until node.childCount) node.getChild(i)?.let { queue.add(it) }
            } catch (e: Exception) {
                out.add("<node walk failed: ${e.message}>")
            }
        }
        if (out.size >= maxLines) out.add("<truncated at $maxLines lines>")
        return out
    }

    fun runSocialTask(host: SocialAgentHost, request: SocialRequest): SocialOutcome {
        val agent = ensureSocialAgent(host)
        return try {
            agent.submit(request).also { recordOutcome(it) }
        } catch (t: Throwable) {
            Log.e(TAG, "social task crashed: ${t.message}")
            SocialOutcome.Finished(
                com.myra.assistant.social.SocialResultCode.FAILED,
                t.message ?: "unexpected error"
            ).also { recordOutcome(it) }
        }
    }

    fun controlSocialTask(host: SocialAgentHost, command: com.myra.assistant.social.SocialCommand, taskId: String?): SocialOutcome {
        val agent = ensureSocialAgent(host)
        return try {
            agent.control(command, taskId).also { recordOutcome(it) }
        } catch (t: Throwable) {
            Log.e(TAG, "social control failed: ${t.message}")
            SocialOutcome.Finished(
                com.myra.assistant.social.SocialResultCode.FAILED,
                t.message ?: "unexpected error"
            ).also { recordOutcome(it) }
        }
    }

    private fun performScroll(forward: Boolean): Boolean {
        val node = findNode { it.isScrollable }
        if (node != null) {
            val action = if (forward) {
                AccessibilityNodeInfo.ACTION_SCROLL_FORWARD
            } else {
                AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD
            }
            if (node.performAction(action)) return true
        }
        return dispatchScrollGesture(forward)
    }
    private fun dispatchScrollGesture(forward: Boolean): Boolean = try {
        val metrics = resources.displayMetrics
        val cx = metrics.widthPixels / 2f
        val startY = metrics.heightPixels * 0.72f
        val endY = metrics.heightPixels * 0.28f
        val path = Path().apply {
            if (forward) {
                moveTo(cx, startY); lineTo(cx, endY)
            } else {
                moveTo(cx, endY); lineTo(cx, startY)
            }
        }
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0L, 320L))
            .build()
        dispatchGesture(gesture, null, null)
        true
    } catch (e: Exception) {
        Log.w(TAG, "gesture dispatch failed: ${e.message}")
        false
    }

    private fun performClick(node: AccessibilityNodeInfoCompat): Boolean {
        if (node.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true
        var parent = node.parent
        var hops = 0
        while (parent != null && hops < 5) {
            if (parent.isClickable && parent.performAction(AccessibilityNodeInfo.ACTION_CLICK)) {
                return true
            }
            parent = parent.parent
            hops++
        }
        return false
    }

    private fun findNode(predicate: (AccessibilityNodeInfoCompat) -> Boolean): AccessibilityNodeInfoCompat? {
        val root = try {
            rootInActiveWindow
        } catch (e: Exception) {
            null
        } ?: return null

        val queue = ArrayDeque<AccessibilityNodeInfoCompat>()
        queue.add(root)
        var visited = 0
        while (queue.isNotEmpty() && visited < MAX_NODES) {
            val node = queue.poll() ?: break
            visited++
            try {
                if (predicate(node)) return node
                for (i in 0 until node.childCount) {
                    node.getChild(i)?.let { queue.add(it) }
                }
            } catch (e: Exception) {
                Log.w(TAG, "node walk failed: ${e.message}")
            }
        }
        return null
    }
}
