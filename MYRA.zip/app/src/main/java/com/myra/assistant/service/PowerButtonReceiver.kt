package com.myra.assistant.service

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.SystemClock
import android.util.Log

class PowerButtonReceiver : BroadcastReceiver() {

    companion object {
        private const val TAG = "PowerButton"
        private const val DOUBLE_PRESS_WINDOW_MS = 600L
        private var lastAction = ""
        private var lastTimestamp = 0L
    }

    override fun onReceive(context: Context, intent: Intent) {
        val action = intent.action ?: return
        if (action != Intent.ACTION_SCREEN_OFF && action != Intent.ACTION_SCREEN_ON) return

        val now = SystemClock.elapsedRealtime()
        val isDouble = action != lastAction && (now - lastTimestamp) in 0..DOUBLE_PRESS_WINDOW_MS

        lastAction = action
        lastTimestamp = now

        if (!isDouble) return
        Log.i(TAG, "Double power press detected -> toggling MYRA overlay")
        if (MyraOverlayService.isRunning) {
            MyraOverlayService.stop(context)
        } else {
            MyraOverlayService.start(context)
        }
    }
}
