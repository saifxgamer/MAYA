package com.myra.assistant.social

enum class ScrollDirection { UP, DOWN, LEFT, RIGHT }

enum class ActionFailure {
    DRIVER_UNAVAILABLE,
    STALE_OBSERVATION,
    ELEMENT_GONE,
    ELEMENT_MOVED,
    NOT_CLICKABLE,
    NOT_ENABLED,
    NOT_EDITABLE,
    PASSWORD_FIELD,
    OUTSIDE_SCREEN,
    EMPTY_BOUNDS,
    SCREEN_UNCHANGED,
    TIMEOUT,
    NOT_PERMITTED,
    PACKAGE_NOT_ALLOWED,
    TARGET_NOT_FOUND
}

sealed class ActionResult {
    data class Applied(val screenChanged: Boolean) : ActionResult()
    data class Failed(val failure: ActionFailure, val detail: String = "") : ActionResult()

    val isSuccess: Boolean get() = this is Applied
    val changed: Boolean get() = this is Applied && screenChanged
    val failureOrNull: ActionFailure? get() = (this as? Failed)?.failure

    companion object {
        fun ok(changed: Boolean = true) = Applied(changed)
        fun fail(failure: ActionFailure, detail: String = "") = Failed(failure, detail)
    }
}

interface ScreenDriver {
    fun isAvailable(): Boolean

    fun observe(): ScreenObservation

    fun currentPackageName(): String

    fun currentWindowClass(): String

    fun uiEventStamp(): Long

    fun windowStamp(): Int

    fun latestObservationId(): Long

    fun screenSize(): Pair<Int, Int>

    fun click(elementId: String): ActionResult

    fun gestureTap(elementId: String): ActionResult

    fun focus(elementId: String): ActionResult

    fun setText(elementId: String, text: String): ActionResult

    fun scroll(elementId: String, direction: ScrollDirection, amountPx: Int): ActionResult

    fun invalidateObservations()

    fun awaitUiChange(timeoutMs: Long): Boolean
}

object Freshness {
    fun isCurrent(observation: ScreenObservation, driver: ScreenDriver): Boolean =
        observation.observationId == driver.latestObservationId() &&
            driver.uiEventStamp() == observation.eventStamp

    fun isNewerWindow(observation: ScreenObservation, previousWindowStamp: Int): Boolean =
        observation.windowStamp > previousWindowStamp
}
