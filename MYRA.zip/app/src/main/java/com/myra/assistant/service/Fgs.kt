package com.myra.assistant.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.util.Log
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import com.myra.assistant.R
import com.myra.assistant.ui.main.MainActivity

object Fgs {

    fun ensureChannel(context: Context, channelId: String, name: String) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        val manager = context.getSystemService(NotificationManager::class.java) ?: return
        if (manager.getNotificationChannel(channelId) != null) return
        val channel = NotificationChannel(
            channelId,
            name,
            NotificationManager.IMPORTANCE_LOW
        ).apply {
            setShowBadge(false)
            enableVibration(false)
            setSound(null, null)
        }
        manager.createNotificationChannel(channel)
    }

    fun buildNotification(
        context: Context,
        channelId: String,
        title: String,
        text: String,
        smallIcon: Int = R.drawable.ic_myra_notif
    ): Notification {
        val contentIntent = PendingIntent.getActivity(
            context,
            0,
            Intent(context, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
            },
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        return NotificationCompat.Builder(context, channelId)
            .setSmallIcon(smallIcon)
            .setContentTitle(title)
            .setContentText(text)
            .setOngoing(true)
            .setSilent(true)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .setContentIntent(contentIntent)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()
    }

    fun startSafe(
        service: Service,
        id: Int,
        notification: Notification,
        type: Int
    ): Boolean {
        return try {
            ServiceCompat.startForeground(service, id, notification, type)
            true
        } catch (e: Exception) {
            Log.w("Fgs", "typed startForeground rejected: ${e.message}")
            try {
                service.startForeground(id, notification)
                true
            } catch (inner: Exception) {
                Log.e("Fgs", "startForeground failed: ${inner.message}")
                runCatching {
                    service.stopForeground(Service.STOP_FOREGROUND_REMOVE)
                }
                false
            }
        }
    }

    fun typePhoneCall(): Int =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            ServiceInfo.FOREGROUND_SERVICE_TYPE_PHONE_CALL
        } else {
            0
        }

    fun typeNone(): Int = 0
}
