package com.myra.assistant.social

object AgentSecurity {

    enum class Op { OBSERVE, CLICK, GESTURE_TAP, FOCUS, SET_TEXT, SCROLL }

    val allowedOps: Set<Op> = setOf(
        Op.OBSERVE, Op.CLICK, Op.GESTURE_TAP, Op.FOCUS, Op.SET_TEXT, Op.SCROLL
    )

    private val BLOCKED_PACKAGES = setOf(
        "com.android.settings",
        "com.android.systemui",
        "com.android.launcher",
        "com.android.launcher3",
        "com.google.android.packageinstaller",
        "com.android.permissioncontroller",
        "com.google.android.permissioncontroller"
    )

    private val CREDENTIAL_CLASSES = setOf("EditText")

    fun isOpAllowed(op: Op): Boolean = op in allowedOps

    fun isPackageBlocked(packageName: String): Boolean = BLOCKED_PACKAGES.any {
        packageName == it || packageName.startsWith("$it.")
    }

    fun isPackageAllowedForTask(task: SocialMediaTask, packageName: String): Boolean {
        if (isPackageBlocked(packageName)) return false
        return task.packageAllowList.any { packageName == it || packageName.startsWith("$it.") }
    }

    fun looksLikeCredentialScreen(observation: ScreenObservation): Boolean {
        val hasPassword = observation.elements.any { it.password }
        if (hasPassword) return true
        val labels = observation.labels().map { TargetResolver.normalize(it) }
        val asksPassword = labels.any { it.contains("password") || it.contains("enter your password") }
        val asksCode = labels.any {
            it.contains("verification code") || it.contains("2-step") || it.contains("two-step")
        }
        return asksPassword || asksCode
    }

    fun looksLikeCaptcha(observation: ScreenObservation): Boolean {
        val text = observation.labels().joinToString(" ") { TargetResolver.normalize(it) }
        val markers = listOf(
            "captcha", "i'm not a robot", "confirm you are human",
            "security check", "verify it's you", "verify its you"
        )
        return markers.any { text.contains(it) }
    }

    fun looksLikeRuntimePermission(observation: ScreenObservation): Boolean {
        if (isPackageBlocked(observation.packageName) &&
            observation.packageName.contains("permissioncontroller")
        ) return true
        val text = observation.labels().joinToString(" ") { TargetResolver.normalize(it) }
        val markers = listOf("allow ", "while using the app", "only this time", "deny")
        val hasAllowish = markers.any { text.contains(it) }
        val hasSystemButton = observation.elements.any {
            it.text.equals("Allow", true) || it.text.equals("Don't allow", true)
        }
        return hasAllowish && hasSystemButton
    }

    val HARMLESS_DISMISS_LABELS = setOf("ok", "got it", "not now", "maybe later", "no thanks")

    fun isHarmlessDismissLabel(label: String): Boolean =
        HARMLESS_DISMISS_LABELS.contains(TargetResolver.normalize(label))

    fun isCredentialClass(className: String): Boolean = className.substringAfterLast('.') in CREDENTIAL_CLASSES

    fun redact(value: String): String = if (value.isBlank()) "" else "«${value.length} chars»"
}
