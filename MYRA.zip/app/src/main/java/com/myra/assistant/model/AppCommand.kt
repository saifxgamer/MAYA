package com.myra.assistant.model

import org.json.JSONArray
import org.json.JSONObject

data class AppCommand(
    val type: String,
    val params: Map<String, String> = emptyMap()
) {
    fun param(key: String, fallback: String = ""): String = params[key] ?: fallback

    object Type {
        const val OPEN_APP = "OPEN_APP"
        const val CLOSE_APP = "CLOSE_APP"
        const val CALL = "CALL"
        const val SMS = "SMS"
        const val WHATSAPP_MSG = "WHATSAPP_MSG"
        const val WHATSAPP_CALL = "WHATSAPP_CALL"
        const val PRIME_CALL = "PRIME_CALL"
        const val PRIME_MSG = "PRIME_MSG"
        const val VOLUME_UP = "VOLUME_UP"
        const val VOLUME_DOWN = "VOLUME_DOWN"
        const val VOLUME_MAX = "VOLUME_MAX"
        const val VOLUME_MUTE = "VOLUME_MUTE"
        const val FLASHLIGHT_ON = "FLASHLIGHT_ON"
        const val FLASHLIGHT_OFF = "FLASHLIGHT_OFF"
        const val WIFI_ON = "WIFI_ON"
        const val WIFI_OFF = "WIFI_OFF"
        const val BLUETOOTH_ON = "BLUETOOTH_ON"
        const val BLUETOOTH_OFF = "BLUETOOTH_OFF"
        const val SCREEN_ON = "SCREEN_ON"
        const val SCROLL_DOWN = "SCROLL_DOWN"
        const val SCROLL_UP = "SCROLL_UP"
        const val GO_BACK = "GO_BACK"
        const val SEARCH = "SEARCH"
        const val SOCIAL_POST = "SOCIAL_POST"
        const val SOCIAL_CONFIRM = "SOCIAL_CONFIRM"
        const val SOCIAL_REJECT = "SOCIAL_REJECT"
        const val SOCIAL_RESUME = "SOCIAL_RESUME"
        const val SOCIAL_STATUS = "SOCIAL_STATUS"
    }
}

data class PrimeContact(
    val name: String,
    val number: String
) {
    fun toJson(): JSONObject = JSONObject().apply {
        put(KEY_NAME, name)
        put(KEY_NUMBER, number)
    }

    companion object {
        const val KEY_NAME = "name"
        const val KEY_NUMBER = "number"

        fun fromJson(obj: JSONObject): PrimeContact? {
            val name = obj.optString(KEY_NAME, "").trim()
            val number = obj.optString(KEY_NUMBER, "").trim()
            if (name.isEmpty() || number.isEmpty()) return null
            return PrimeContact(name, number)
        }

        fun listToJson(list: List<PrimeContact>): String {
            val arr = JSONArray()
            list.forEach { arr.put(it.toJson()) }
            return arr.toString()
        }

        fun listFromJson(raw: String?): List<PrimeContact> {
            if (raw.isNullOrBlank()) return emptyList()
            return try {
                val arr = JSONArray(raw)
                (0 until arr.length()).mapNotNull { i ->
                    arr.optJSONObject(i)?.let { fromJson(it) }
                }
            } catch (_: Exception) {
                emptyList()
            }
        }
    }
}

enum class PersonalityMode(val key: String, val label: String) {
    GF("gf", "GF Mode"),
    PROFESSIONAL("pro", "Professional Mode"),
    ASSISTANT("assistant", "Assistant Mode");

    companion object {
        fun fromKey(key: String?): PersonalityMode =
            entries.firstOrNull { it.key.equals(key, ignoreCase = true) } ?: GF
    }
}
