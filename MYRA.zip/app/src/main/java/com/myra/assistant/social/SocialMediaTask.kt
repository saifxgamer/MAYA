package com.myra.assistant.social

enum class SocialPlatform(val packages: List<String>) {
    INSTAGRAM(listOf("com.instagram.android")),
    FACEBOOK(listOf("com.facebook.katana", "com.facebook.system", "com.facebook.app"));

    companion object {
        fun parse(value: String?): SocialPlatform? = entries.firstOrNull {
            it.name.equals(value, ignoreCase = true) || it.name.startsWith(value.orEmpty(), ignoreCase = true)
        }
    }
}

enum class SocialAction { POST_MEDIA, POST_REEL, POST_STORY, POST_TEXT }

enum class SocialMode { PUBLISH, DRAFT }

enum class TaskStatus {
    IDLE, RUNNING, AWAITING_CONFIRMATION, WAITING_FOR_USER, COMPLETED, FAILED, CANCELLED, REJECTED
}

enum class SocialResultCode(val published: Boolean, val speakable: String) {
    PUBLISHED(true, "Posted"),
    SUBMITTED_UNVERIFIED(false, "Submitted, but I could not confirm it on screen"),
    POSTED_UNKNOWN(false, "I tapped Share, so it may or may not have posted"),
    POSTED_NO(false, "Not posted"),
    DRAFT_READY(false, "Draft is ready, I did not publish"),
    AWAITING_CONFIRMATION(false, "Ready to post. Say yes to publish"),
    USER_ACTION_REQUIRED(false, "I need you to do something on the screen first"),
    MEDIA_REQUIRED(false, "Share the photo or video to me from your gallery first"),
    SHARE_TARGET_NOT_FOUND(false, "I could not find a safe share target in that app"),
    APP_NOT_INSTALLED(false, "That app is not installed"),
    ACCESSIBILITY_NOT_ENABLED(false, "Turn on the MYRA accessibility service first"),
    UNSUPPORTED_ACTION(false, "That app does not support that kind of post"),
    REJECTED(false, "Okay, I cancelled it"),
    CANCELLED(false, "Cancelled"),
    BUSY(false, "I am already doing something"),
    FAILED(false, "That did not work"),
    SECURITY_BLOCKED(false, "I am not allowed to do that")
}

data class SocialMediaTask(
    val taskId: String,
    val platform: SocialPlatform,
    val action: SocialAction,
    val mediaRef: String? = null,
    val mediaMimeType: String? = null,
    val caption: String? = null,
    val mode: SocialMode = SocialMode.PUBLISH,
    val targetAccount: String? = null,
    val currentStep: String = "",
    /** Step to run when the task is resumed after a confirmation gate or a user action. */
    val resumeStep: String = "",
    val status: TaskStatus = TaskStatus.IDLE,
    val retryCount: Int = 0,
    val maxRetries: Int = 2,
    val confirmed: Boolean = false
) {
    val packageAllowList: Set<String> get() = platform.packages.toSet()

    val isPublish: Boolean get() = action != SocialAction.POST_TEXT || mode == SocialMode.PUBLISH

    fun question(): String = when (action) {
        SocialAction.POST_STORY -> "Add this to your Instagram story?"
        SocialAction.POST_REEL -> "Post this reel to Instagram?"
        SocialAction.POST_MEDIA -> "Post this to ${platform.name.lowercase().replaceFirstChar { it.uppercase() }}?"
        SocialAction.POST_TEXT -> "Post this text to ${platform.name.lowercase().replaceFirstChar { it.uppercase() }}?"
    }
}

enum class SocialStep {
    OPEN_APP,
    SHARE_MEDIA,
    OPEN_COMPOSER,
    TAP_CREATE,
    TAP_OPTION,
    WAIT_FOR_USER_SELECT_MEDIA,
    TAP_NEXT,
    TYPE_CAPTION,
    TYPE_POST_TEXT,
    CONFIRM_PUBLISH,
    TAP_SHARE,
    TAP_STORY_TARGET,
    VERIFY_POST
}

sealed class SocialOutcome {
    data class Finished(
        val code: SocialResultCode,
        val detail: String = ""
    ) : SocialOutcome() {
        val message: String get() = if (detail.isBlank()) code.speakable else "${code.speakable}. $detail"
    }

    data class AwaitingConfirmation(
        val taskId: String,
        val question: String,
        val detail: String = ""
    ) : SocialOutcome()

    data class NeedsUser(
        val taskId: String,
        val code: SocialResultCode,
        val instruction: String
    ) : SocialOutcome()

    data class Busy(val taskId: String? = null) : SocialOutcome()

    data class Rejected(val reason: String) : SocialOutcome()
}

object SocialMediaPlan {

    fun stepsFor(task: SocialMediaTask, hasShareHandler: Boolean): List<SocialStep> {
        val mediaRequired = task.action != SocialAction.POST_TEXT
        val publishTail = if (task.action == SocialAction.POST_STORY) {
            listOf(SocialStep.TAP_STORY_TARGET, SocialStep.VERIFY_POST)
        } else {
            listOf(SocialStep.TAP_SHARE, SocialStep.VERIFY_POST)
        }

        // shareMedia already waits for the new window, so no extra wait step is needed.
        val head = if (mediaRequired && hasShareHandler) {
            listOf(
                SocialStep.SHARE_MEDIA,
                SocialStep.TAP_NEXT
            )
        } else if (mediaRequired) {
            listOf(
                SocialStep.OPEN_APP,
                SocialStep.TAP_CREATE,
                SocialStep.TAP_OPTION,
                SocialStep.WAIT_FOR_USER_SELECT_MEDIA
            )
        } else {
            listOf(SocialStep.OPEN_APP, SocialStep.OPEN_COMPOSER, SocialStep.TYPE_POST_TEXT, SocialStep.TAP_NEXT)
        }

        val captionStep = if (task.action == SocialAction.POST_TEXT) emptyList() else listOf(SocialStep.TYPE_CAPTION)
        val middle = captionStep + listOf(SocialStep.CONFIRM_PUBLISH)

        return head + middle + publishTail
    }
}
