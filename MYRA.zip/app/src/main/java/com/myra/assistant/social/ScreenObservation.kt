package com.myra.assistant.social

data class ScreenObservation(
    val observationId: Long,
    val packageName: String,
    val windowClass: String,
    val screenWidth: Int,
    val screenHeight: Int,
    val eventStamp: Long,
    val windowStamp: Int,
    val capturedAtMs: Long,
    val elements: List<UiElement>
) {
    private val index: Map<String, UiElement> = elements.associateBy { it.elementId }

    fun byId(elementId: String): UiElement? = index[elementId]

    fun interactiveElements(): List<UiElement> =
        elements.filter { it.clickable || it.longClickable || it.editable }

    fun labels(): List<String> = elements.map { it.label }.filter { it.isNotBlank() }

    val structuralSignature: String = computeSignature()

    private fun computeSignature(): String {
        val sb = StringBuilder()
        sb.append(packageName).append('|').append(windowClass).append('|')
        elements.forEach { e ->
            sb.append(e.index).append(':')
                .append(e.text).append(':')
                .append(e.contentDescription).append(':')
                .append(e.resourceId).append(':')
                .append(e.bounds).append(':')
                .append(e.enabled).append(':')
                .append(e.selected).append(':')
                .append(e.editable).append(';')
        }
        return Fnv.hash(sb.toString())
    }

    fun describeInteractive(): String = interactiveElements()
        .mapIndexed { n, e -> "ELEMENT $n ${e.describe()}" }
        .joinToString("\n")

    companion object {
        fun empty(observationId: Long, eventStamp: Long = 0L, windowStamp: Int = 0) = ScreenObservation(
            observationId = observationId,
            packageName = "",
            windowClass = "",
            screenWidth = 0,
            screenHeight = 0,
            eventStamp = eventStamp,
            windowStamp = windowStamp,
            capturedAtMs = 0L,
            elements = emptyList()
        )
    }
}

internal object Fnv {
    fun hash(value: String): String {
        var h = -0x340d631b7bdddcdbL
        value.forEach { ch ->
            h = h xor ch.code.toLong()
            h *= 0x100000001b3L
        }
        return java.lang.Long.toHexString(h)
    }
}
