package com.myra.assistant.viewmodel

import android.Manifest
import android.app.Application
import android.bluetooth.BluetoothManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.os.Build
import android.os.PowerManager
import android.provider.ContactsContract
import android.provider.Settings
import android.telecom.TelecomManager
import android.util.Log
import androidx.core.content.ContextCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.viewModelScope
import com.myra.assistant.ai.CommandParser
import com.myra.assistant.model.AppCommand
import com.myra.assistant.model.MyraPrefs
import com.myra.assistant.service.AccessibilityHelperService
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainViewModel(application: Application) : AndroidViewModel(application) {

    companion object {
        private const val TAG = "MainViewModel"
    }

    private val appContext: Context get() = getApplication()

    private val _commandResult = MutableLiveData<String?>()
    val commandResult: LiveData<String?> = _commandResult

    private val _needsAccessibility = MutableLiveData(false)
    val needsAccessibility: LiveData<Boolean> = _needsAccessibility

    private val _toastMessage = MutableLiveData<String?>()
    val toastMessage: LiveData<String?> = _toastMessage

    fun consumeResult() {
        _commandResult.value = null
    }

    fun consumeToast() {
        _toastMessage.value = null
    }

    fun execute(command: AppCommand) {
        viewModelScope.launch(Dispatchers.IO) {
            val result = runCatching { dispatch(command) }
                .getOrElse { "failed: ${it.message}" }
            _commandResult.postValue(result)
        }
    }

    fun executeText(text: String) {
        val command = CommandParser.parse(text, MyraPrefs.primeContacts(appContext)) ?: return
        execute(command)
    }

    private fun dispatch(command: AppCommand): String = when (command.type) {
        AppCommand.Type.OPEN_APP -> openApp(command.param("app_name"))
        AppCommand.Type.CLOSE_APP -> closeApp()
        AppCommand.Type.CALL -> placeCall(command.param("name"))
        AppCommand.Type.SMS -> sendSms(command.param("name"), command.param("message"))
        AppCommand.Type.WHATSAPP_MSG -> whatsappMessage(command.param("name"), command.param("message"))
        AppCommand.Type.WHATSAPP_CALL -> whatsappCall(command.param("name"))
        AppCommand.Type.PRIME_CALL -> primeCall(command.param("index").toIntOrNull() ?: 0)
        AppCommand.Type.PRIME_MSG -> primeMessage(
            command.param("index").toIntOrNull() ?: 0,
            command.param("message")
        )
        AppCommand.Type.VOLUME_UP -> changeVolume(AudioManager.ADJUST_RAISE)
        AppCommand.Type.VOLUME_DOWN -> changeVolume(AudioManager.ADJUST_LOWER)
        AppCommand.Type.VOLUME_MAX -> changeVolume(AudioManager.ADJUST_TO_MAX)
        AppCommand.Type.VOLUME_MUTE -> changeVolume(AudioManager.ADJUST_MUTE)
        AppCommand.Type.FLASHLIGHT_ON -> setTorch(true)
        AppCommand.Type.FLASHLIGHT_OFF -> setTorch(false)
        AppCommand.Type.WIFI_ON -> setWifi(true)
        AppCommand.Type.WIFI_OFF -> setWifi(false)
        AppCommand.Type.BLUETOOTH_ON -> setBluetooth(true)
        AppCommand.Type.BLUETOOTH_OFF -> setBluetooth(false)
        AppCommand.Type.SCREEN_ON -> wakeScreen()
        AppCommand.Type.SCROLL_DOWN -> scroll(true)
        AppCommand.Type.SCROLL_UP -> scroll(false)
        AppCommand.Type.GO_BACK -> goBack()
        AppCommand.Type.SEARCH -> webSearch(command.param("query"))
        else -> "unsupported command"
    }

    // region apps

    private fun openApp(appName: String): String {
        if (appName.isBlank()) return "no app name given"
        val pm = appContext.packageManager
        CommandParser.APP_MAP[appName.lowercase()]?.let { pkg ->
            val intent = pm.getLaunchIntentForPackage(pkg)
            if (intent != null) return launch(intent, appName)
        }
        val resolved = findInstalledApp(appName)
            ?: return "${appName.replaceFirstChar { it.uppercase() }} is not installed"
        val intent = pm.getLaunchIntentForPackage(resolved)
            ?: return "could not launch ${appName.replaceFirstChar { it.uppercase() }}"
        return launch(intent, appName)
    }

    private fun launch(intent: Intent, appName: String): String {
        return try {
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            appContext.startActivity(intent)
            "${appName.replaceFirstChar { it.uppercase() }} opened"
        } catch (e: Exception) {
            Log.e(TAG, "launch failed: ${e.message}")
            "could not open ${appName.replaceFirstChar { it.uppercase() }}"
        }
    }

    private fun findInstalledApp(appName: String): String? {
        val pm = appContext.packageManager
        val target = appName.trim().lowercase()
        val packages = runCatching {
            pm.getInstalledApplications(PackageManager.GET_META_DATA)
        }.getOrNull() ?: return null
        for (info in packages) {
            val label = runCatching { info.loadLabel(pm).toString() }.getOrNull() ?: continue
            if (label.lowercase().replace(" ", "") == target.replace(" ", "")) {
                return info.packageName
            }
        }
        for (info in packages) {
            val label = runCatching { info.loadLabel(pm).toString() }.getOrNull() ?: continue
            if (label.lowercase().contains(target)) return info.packageName
        }
        return null
    }

    private fun closeApp(): String {
        val service = AccessibilityHelperService.instance
        if (service == null || !AccessibilityHelperService.isEnabled(appContext)) {
            _needsAccessibility.postValue(true)
            return "accessibility service is off, cannot close the app"
        }
        return if (service.closeCurrentApp()) {
            "app closed"
        } else {
            "could not close the app"
        }
    }

    private fun scroll(forward: Boolean): String {
        val service = AccessibilityHelperService.instance
        if (service == null || !AccessibilityHelperService.isEnabled(appContext)) {
            _needsAccessibility.postValue(true)
            return "accessibility service is off, cannot scroll"
        }
        val ok = if (forward) service.scrollDown() else service.scrollUp()
        return if (ok) "scrolled" else "nothing to scroll"
    }

    private fun goBack(): String {
        val service = AccessibilityHelperService.instance
        if (service == null || !AccessibilityHelperService.isEnabled(appContext)) {
            _needsAccessibility.postValue(true)
            return "accessibility service is off, cannot go back"
        }
        return if (service.goBack()) "went back" else "could not go back"
    }

    // endregion

    // region contacts

    private fun resolveNumber(name: String): String? {
        if (name.isBlank()) return null
        val digits = name.filter { it.isDigit() }
        if (digits.length >= 7) return name.trim()
        if (ContextCompat.checkSelfPermission(appContext, Manifest.permission.READ_CONTACTS)
            != PackageManager.PERMISSION_GRANTED
        ) {
            return null
        }
        return try {
            appContext.contentResolver.query(
                ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                arrayOf(
                    ContactsContract.CommonDataKinds.Phone.NUMBER,
                    ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME
                ),
                null,
                null,
                null
            )?.use { cursor ->
                val numberIndex = cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER)
                val nameIndex = cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME)
                var found: String? = null
                while (cursor.moveToNext()) {
                    val contactName = if (nameIndex >= 0) cursor.getString(nameIndex).orEmpty() else ""
                    if (contactName.equals(name.trim(), ignoreCase = true) ||
                        contactName.contains(name.trim(), ignoreCase = true)
                    ) {
                        found = if (numberIndex >= 0) cursor.getString(numberIndex) else null
                        if (!found.isNullOrBlank()) break
                    }
                }
                found
            }
        } catch (e: Exception) {
            Log.e(TAG, "contact lookup failed: ${e.message}")
            null
        }
    }

    private fun placeCall(nameOrNumber: String): String {
        if (nameOrNumber.isBlank()) return "no name given"
        val number = resolveNumber(nameOrNumber)
        if (number.isNullOrBlank()) {
            return "contact not found in phonebook"
        }
        if (ContextCompat.checkSelfPermission(appContext, Manifest.permission.CALL_PHONE)
            != PackageManager.PERMISSION_GRANTED
        ) {
            _toastMessage.postValue("CALL_PHONE permission is needed")
            return "call permission is missing"
        }
        return try {
            val intent = Intent(Intent.ACTION_CALL).apply {
                data = Uri.parse("tel:$number")
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            appContext.startActivity(intent)
            "calling $nameOrNumber"
        } catch (e: Exception) {
            Log.e(TAG, "call failed: ${e.message}")
            "call could not be placed"
        }
    }

    private fun sendSms(name: String, message: String): String {
        if (name.isBlank()) return "no name given"
        val number = resolveNumber(name)
        if (number.isNullOrBlank()) return "contact not found in phonebook"
        return try {
            val intent = Intent(Intent.ACTION_VIEW).apply {
                data = Uri.parse("smsto:$number")
                putExtra("sms_body", message)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            appContext.startActivity(intent)
            if (message.isBlank()) "sms app opened for $name" else "sms to $name is ready to send"
        } catch (e: Exception) {
            Log.e(TAG, "sms failed: ${e.message}")
            "sms app could not be opened"
        }
    }

    private fun whatsappTarget(name: String): String? {
        if (name.isBlank()) return null
        val digits = name.filter { it.isDigit() }
        if (digits.length >= 7) {
            val countryCode = if (name.trim().startsWith("+")) digits else "91$digits"
            return countryCode
        }
        val number = resolveNumber(name) ?: return null
        val local = number.filter { it.isDigit() }
        if (local.length < 7) return null
        return if (local.length > 10) local else "91$local"
    }

    private fun whatsappMessage(name: String, message: String): String {
        val target = whatsappTarget(name)
            ?: return "whatsapp contact not found in phonebook"
        return try {
            val text = if (message.isBlank()) "" else "?text=${Uri.encode(message)}"
            val intent = Intent(Intent.ACTION_VIEW).apply {
                data = Uri.parse("https://wa.me/$target$text")
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            appContext.startActivity(intent)
            "whatsapp chat opened for $name"
        } catch (e: Exception) {
            Log.e(TAG, "whatsapp failed: ${e.message}")
            "whatsapp could not be opened"
        }
    }

    private fun whatsappCall(name: String): String {
        val target = whatsappTarget(name)
            ?: return "whatsapp contact not found in phonebook"
        return try {
            val intent = Intent(Intent.ACTION_VIEW).apply {
                data = Uri.parse("https://wa.me/$target?call")
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            appContext.startActivity(intent)
            "whatsapp call opened for $name"
        } catch (e: Exception) {
            Log.e(TAG, "whatsapp call failed: ${e.message}")
            "whatsapp call could not be opened"
        }
    }

    private fun primeCall(index: Int): String {
        val contact = MyraPrefs.primeContacts(appContext).getOrNull(index)
            ?: return "prime contact not set"
        return placeCall(contact.number)
    }

    private fun primeMessage(index: Int, message: String): String {
        val contact = MyraPrefs.primeContacts(appContext).getOrNull(index)
            ?: return "prime contact not set"
        return sendSms(contact.number, message)
    }

    // endregion

    // region device

    private fun changeVolume(adjust: Int): String {
        val am = appContext.getSystemService(Context.AUDIO_SERVICE) as? AudioManager
            ?: return "audio service unavailable"
        val label = when (adjust) {
            AudioManager.ADJUST_RAISE -> "volume up"
            AudioManager.ADJUST_LOWER -> "volume down"
            AudioManager.ADJUST_TO_MAX -> "volume at max"
            AudioManager.ADJUST_MUTE -> "volume muted"
            else -> "volume unchanged"
        }
        am.adjustStreamVolume(AudioManager.STREAM_MUSIC, adjust, 0)
        return label
    }

    private fun setTorch(on: Boolean): String {
        val manager = appContext.getSystemService(Context.CAMERA_SERVICE) as? CameraManager
            ?: return "camera service unavailable"
        return try {
            val cameraId = manager.cameraIdList.firstOrNull { id ->
                manager.getCameraCharacteristics(id)
                    .get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
            } ?: return "no flash on this device"
            manager.setTorchMode(cameraId, on)
            if (on) "torch on" else "torch off"
        } catch (e: Exception) {
            Log.e(TAG, "torch failed: ${e.message}")
            "torch could not be toggled"
        }
    }

    @Suppress("DEPRECATION")
    private fun setWifi(on: Boolean): String {
        val wifi = appContext.applicationContext
            .getSystemService(Context.WIFI_SERVICE) as? android.net.wifi.WifiManager
            ?: return "wifi service unavailable"
        return try {
            if (wifi.isWifiEnabled == on) {
                return if (on) "wifi already on" else "wifi already off"
            }
            val changed = wifi.setWifiEnabled(on)
            if (changed) {
                if (on) "wifi on" else "wifi off"
            } else {
                openWifiPanel()
                "opening wifi settings"
            }
        } catch (e: Exception) {
            Log.e(TAG, "wifi toggle failed: ${e.message}")
            openWifiPanel()
            "opening wifi settings"
        }
    }

    private fun openWifiPanel() {
        runCatching {
            appContext.startActivity(
                Intent(Settings.Panel.ACTION_WIFI).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
        }
    }

    private fun setBluetooth(on: Boolean): String {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S &&
            ContextCompat.checkSelfPermission(appContext, Manifest.permission.BLUETOOTH_CONNECT)
            != PackageManager.PERMISSION_GRANTED
        ) {
            _toastMessage.postValue("BLUETOOTH_CONNECT permission is needed")
            return "bluetooth permission is missing"
        }
        val adapter = (appContext.getSystemService(Context.BLUETOOTH_SERVICE) as? BluetoothManager)?.adapter
            ?: return "bluetooth unavailable on this device"
        return try {
            if (adapter.isEnabled == on) return if (on) "bluetooth already on" else "bluetooth already off"
            @Suppress("DEPRECATION")
            val changed = if (on) adapter.enable() else adapter.disable()
            if (changed) {
                if (on) "bluetooth on" else "bluetooth off"
            } else {
                runCatching {
                    appContext.startActivity(
                        Intent(Settings.ACTION_BLUETOOTH_SETTINGS)
                            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    )
                }
                "opening bluetooth settings"
            }
        } catch (e: Exception) {
            Log.e(TAG, "bluetooth toggle failed: ${e.message}")
            "bluetooth could not be toggled"
        }
    }

    @Suppress("DEPRECATION")
    private fun wakeScreen(): String {
        val power = appContext.getSystemService(Context.POWER_SERVICE) as? PowerManager
            ?: return "power service unavailable"
        val keyguard = appContext.getSystemService(Context.KEYGUARD_SERVICE) as? android.app.KeyguardManager
        if (keyguard?.isKeyguardLocked == true) {
            keyguard.requestDismissKeyguard(null, null)
        }
        val lockAndWake = power.newWakeLock(
            PowerManager.SCREEN_BRIGHT_WAKE_LOCK or PowerManager.ACQUIRE_CAUSES_WAKEUP,
            "Myra:WakeUp"
        )
        lockAndWake.acquire(3000L)
        return "screen on"
    }

    private fun webSearch(query: String): String {
        if (query.isBlank()) return "nothing to search"
        return try {
            val intent = Intent(Intent.ACTION_VIEW).apply {
                data = Uri.parse("https://www.google.com/search?q=${Uri.encode(query)}")
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            appContext.startActivity(intent)
            "searching for $query"
        } catch (e: Exception) {
            "search could not be started"
        }
    }

    // endregion

    // region calls

    fun acceptCall() {
        viewModelScope.launch(Dispatchers.IO) {
            val telecom = appContext.getSystemService(Context.TELECOM_SERVICE) as? TelecomManager
            if (telecom == null) {
                _commandResult.postValue("telecom service unavailable")
                return@launch
            }
            if (ContextCompat.checkSelfPermission(appContext, Manifest.permission.ANSWER_PHONE_CALLS)
                != PackageManager.PERMISSION_GRANTED
            ) {
                _toastMessage.postValue("ANSWER_PHONE_CALLS permission is needed")
                _commandResult.postValue("answer call permission is missing")
                return@launch
            }
            val ok = withContext(Dispatchers.Main) {
                runCatching { telecom.acceptRingingCall() }.getOrDefault(false)
            }
            _commandResult.postValue(if (ok) "call accepted" else "could not accept the call")
        }
    }

    fun rejectCall() {
        viewModelScope.launch(Dispatchers.IO) {
            val telecom = appContext.getSystemService(Context.TELECOM_SERVICE) as? TelecomManager
            if (telecom == null) {
                _commandResult.postValue("telecom service unavailable")
                return@launch
            }
            if (ContextCompat.checkSelfPermission(appContext, Manifest.permission.ANSWER_PHONE_CALLS)
                != PackageManager.PERMISSION_GRANTED
            ) {
                _toastMessage.postValue("ANSWER_PHONE_CALLS permission is needed")
                _commandResult.postValue("reject call permission is missing")
                return@launch
            }
            val ok = runCatching { telecom.endCall() }.getOrDefault(false)
            _commandResult.postValue(if (ok) "call rejected" else "could not reject the call")
        }
    }

    // endregion
}
