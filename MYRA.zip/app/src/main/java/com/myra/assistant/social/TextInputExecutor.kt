package com.myra.assistant.social

sealed class TextOutcome {
    data class Success(val observation: ScreenObservation, val length: Int) : TextOutcome()
    data class Failed(val reason: String) : TextOutcome()
}

class TextInputExecutor(
    private val driver: ScreenDriver,
    private val executor: UiActionExecutor,
    private val log: AgentLog = NoopAgentLog
) {

    fun setText(
        spec: TargetSpec,
        allowedPackages: Set<String>,
        value: String
    ): TextOutcome {
        val first = executor.waitForTarget(spec, allowedPackages)
        if (first !is TargetWait.Found) {
            return TextOutcome.Failed("field not found: ${spec.name}")
        }
        if (first.element.password) {
            return TextOutcome.Failed("refusing to type into a password field")
        }

        val focus = driver.focus(first.element.elementId)
        if (focus is ActionResult.Failed && focus.failure == ActionFailure.STALE_OBSERVATION) {
            return TextOutcome.Failed("observation went stale while focusing")
        }

        clockProbe()

        val second = executor.waitForTarget(spec, allowedPackages)
        if (second !is TargetWait.Found) {
            return TextOutcome.Failed("field disappeared after focus: ${spec.name}")
        }

        val result = driver.setText(second.element.elementId, value)
        if (result is ActionResult.Failed) {
            return TextOutcome.Failed("setText failed: ${result.failure} ${result.detail}")
        }

        driver.invalidateObservations()
        val verify = executor.waitForTarget(spec, allowedPackages, timeoutMs = VERIFY_TIMEOUT_MS)
        if (verify !is TargetWait.Found) {
            return TextOutcome.Failed("could not re-read the field to verify")
        }
        val written = verify.element.text
        val ok = written.contains(value.takeLast(24)) || value.isEmpty()
        log.action("setText ${spec.name} length=${AgentSecurity.redact(value).length}")
        return if (ok) {
            TextOutcome.Success(verify.observation, value.length)
        } else {
            TextOutcome.Failed("text did not appear in the field")
        }
    }

    private fun clockProbe() {
        try {
            Thread.sleep(RELAYOUT_SETTLE_MS)
        } catch (_: InterruptedException) {
            Thread.currentThread().interrupt()
        }
    }

    companion object {
        private const val RELAYOUT_SETTLE_MS = 350L
        private const val VERIFY_TIMEOUT_MS = 2_500L
    }
}
