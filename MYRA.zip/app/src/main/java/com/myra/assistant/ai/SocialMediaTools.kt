package com.myra.assistant.ai

import com.myra.assistant.service.AccessibilityHelperService
import com.myra.assistant.service.MyraSocialHost
import com.myra.assistant.social.SocialAction
import com.myra.assistant.social.SocialCommand
import com.myra.assistant.social.SocialMode
import com.myra.assistant.social.SocialOutcome
import com.myra.assistant.social.SocialPlatform
import com.myra.assistant.social.SocialRequest
import com.myra.assistant.social.SocialResultCode
import org.json.JSONObject

class SocialMediaTools(private val context: android.content.Context) {

    private val host = MyraSocialHost(context)

    private val tts: android.speech.tts.TextToSpeech? by lazy {
        android.speech.tts.TextToSpeech(context) { status ->
            android.util.Log.i(TAG, "tts init status=$status")
        }
    }

    init {
        host.setSpeaker { message ->
            android.util.Log.i(TAG, "MYRA says: $message")
            tts?.speak(message, android.speech.tts.TextToSpeech.QUEUE_ADD, null, "myra-social")
        }
    }

    fun release() {
        tts?.stop()
        tts?.shutdown()
    }

    fun declarations(): org.json.JSONArray {
        val execute = JSONObject().apply {
            put("name", TOOL_EXECUTE)
            put("description", EXECUTE_DESCRIPTION)
            put("parameters", executeParameters())
        }
        val control = JSONObject().apply {
            put("name", TOOL_CONTROL)
            put("description", CONTROL_DESCRIPTION)
            put("parameters", controlParameters())
        }
        return org.json.JSONArray().put(execute).put(control)
    }

    fun systemInstructionBlock(): String = INSTRUCTIONS

    /**
     * A bare "haan" or "done" after MYRA asked a question still belongs to the pending task.
     * CommandParser uses this so an explicit yes is never dropped, and never guessed.
     */
    fun socialGatePending(): Boolean {
        val agent = AccessibilityHelperService.instance?.socialAgentOrNull() ?: return false
        return agent.awaitingConfirmation || agent.waitingForUser
    }

    fun handleCall(name: String, args: JSONObject): String = when (name) {
        TOOL_EXECUTE -> execute(args)
        TOOL_CONTROL -> control(args)
        else -> error("unknown tool $name")
    }

    private fun execute(args: JSONObject): String {
        val platform = SocialPlatform.parse(args.optString("platform"))
            ?: return error("platform must be instagram or facebook")
        val action = parseAction(args.optString("action"))
            ?: return error("action must be post_media, post_reel, post_story or post_text")

        val service = AccessibilityHelperService.instance
            ?: return code(SocialResultCode.ACCESSIBILITY_NOT_ENABLED)

        val request = SocialRequest(
            platform = platform,
            action = action,
            mediaRef = args.optString("media_uri").ifBlank { null },
            caption = args.optString("caption").ifBlank { null },
            mode = if (args.optString("mode").equals("draft", true)) SocialMode.DRAFT else SocialMode.PUBLISH,
            targetAccount = args.optString("target_account").ifBlank { null }
        )

        return runCatching { service.runSocialTask(host, request) }
            .fold(
                { render(it) },
                { error(it.message ?: "task failed") }
            )
    }

    private fun control(args: JSONObject): String {
        val raw = args.optString("command").lowercase()
        val taskId = args.optString("task_id").ifBlank { null }
        val command = when (raw) {
            "confirm", "yes", "approve" -> SocialCommand.CONFIRM
            "reject", "no", "deny" -> SocialCommand.REJECT
            "resume", "done" -> SocialCommand.RESUME
            "cancel" -> SocialCommand.CANCEL
            "status" -> SocialCommand.STATUS
            else -> return error("command must be confirm, reject, resume, cancel or status")
        }
        val service = AccessibilityHelperService.instance
            ?: return code(SocialResultCode.ACCESSIBILITY_NOT_ENABLED)
        return runCatching { service.controlSocialTask(host, command, taskId) }
            .fold({ render(it) }, { error(it.message ?: "control failed") })
    }

    private fun parseAction(value: String): SocialAction? = when (value.lowercase().replace('-', '_')) {
        "post_media", "post_photo", "photo", "image", "media", "post" -> SocialAction.POST_MEDIA
        "post_reel", "reel" -> SocialAction.POST_REEL
        "post_story", "story" -> SocialAction.POST_STORY
        "post_text", "text", "status" -> SocialAction.POST_TEXT
        else -> null
    }

    private fun render(outcome: SocialOutcome): String = when (outcome) {
        is SocialOutcome.Finished -> JSONObject().apply {
            put("status", "finished")
            put("code", outcome.code.name)
            put("message", outcome.message)
            put("published", outcome.code.published)
        }.toString()

        is SocialOutcome.AwaitingConfirmation -> JSONObject().apply {
            put("status", "awaiting_confirmation")
            put("task_id", outcome.taskId)
            put("question", outcome.question)
            put("message", "Ask the user this question out loud and wait. Call ${TOOL_CONTROL}(confirm) only after they say yes explicitly.")
        }.toString()

        is SocialOutcome.NeedsUser -> JSONObject().apply {
            put("status", "user_action_required")
            put("task_id", outcome.taskId)
            put("code", outcome.code.name)
            put("instruction", outcome.instruction)
            put("message", "Read this to the user, wait for them to say done, then call ${TOOL_CONTROL}(resume).")
        }.toString()

        is SocialOutcome.Busy -> JSONObject().apply {
            put("status", "busy")
            put("message", "A task is already running. Do not start another one.")
        }.toString()

        is SocialOutcome.Rejected -> JSONObject().apply {
            put("status", "rejected")
            put("message", outcome.reason)
        }.toString()
    }

    private fun code(value: SocialResultCode): String = JSONObject().apply {
        put("status", "finished")
        put("code", value.name)
        put("message", value.speakable)
        put("published", value.published)
    }.toString()

    private fun error(message: String): String = JSONObject().apply {
        put("status", "error")
        put("message", message)
    }.toString()

    private fun executeParameters(): JSONObject = JSONObject().apply {
        put("type", "object")
        put(
            "properties",
            JSONObject().apply {
                put(
                    "platform",
                    JSONObject().put("type", "string").put("enum", org.json.JSONArray(listOf("instagram", "facebook")))
                )
                put(
                    "action",
                    JSONObject().put("type", "string").put(
                        "enum",
                        org.json.JSONArray(listOf("post_media", "post_reel", "post_story", "post_text"))
                    )
                )
                put(
                    "media_uri",
                    JSONObject()
                        .put("type", "string")
                        .put("description", "Leave empty for the most recent media the user shared to MYRA.")
                )
                put("caption", JSONObject().put("type", "string"))
                put(
                    "mode",
                    JSONObject().put("type", "string").put("enum", org.json.JSONArray(listOf("publish", "draft")))
                )
                put("target_account", JSONObject().put("type", "string"))
            }
        )
        put("required", org.json.JSONArray(listOf("platform", "action")))
    }

    private fun controlParameters(): JSONObject = JSONObject().apply {
        put("type", "object")
        put(
            "properties",
            JSONObject().apply {
                put(
                    "command",
                    JSONObject().put("type", "string").put(
                        "enum",
                        org.json.JSONArray(listOf("confirm", "reject", "resume", "cancel", "status"))
                    )
                )
                put("task_id", JSONObject().put("type", "string"))
            }
        )
        put("required", org.json.JSONArray(listOf("command")))
    }

    companion object {
        private const val TAG = "SocialTools"
        const val TOOL_EXECUTE = "execute_social_media_task"
        const val TOOL_CONTROL = "social_media_task_control"

        private val EXECUTE_DESCRIPTION =
            "Post a photo, video, reel, story or text on Instagram or Facebook by driving the real app. " +
                "The Android agent handles opening the app, picking buttons and verifying the result. " +
                "Leave media_uri empty when the user says 'this photo'. Only say a post is done when the " +
                "result says published."

        private val CONTROL_DESCRIPTION =
            "Continue, stop or query a social media task that is waiting for the user. " +
                "Use confirm only after the user explicitly said yes."

        private val INSTRUCTIONS = """
            Social media posting:
            - Use execute_social_media_task and social_media_task_control instead of any generic tap or read tools.
            - Call execute_social_media_task again for every new request. Never answer from an earlier result.
            - Leave media_uri empty when the user means the photo or video they just shared to you.
            - If the result is media_required, ask them to share the media to you from the gallery, then wait.
            - If the result is awaiting_confirmation, ask the question out loud, and call social_media_task_control
              with confirm only after an explicit yes. Never assume a yes.
            - If the result is user_action_required, read the instruction, wait for the user to say done,
              then call social_media_task_control with resume.
            - Say posted only when the code is PUBLISHED. For SUBMITTED_UNVERIFIED or POSTED_UNKNOWN say you are not sure.
            - Instagram has no text-only post. If asked for that, say it is not supported.
        """.trimIndent()
    }
}
