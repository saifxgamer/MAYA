package com.myra.assistant.social

import java.util.HashSet

enum class AgentState {
    IDLE,
    OPENING_APP,
    OBSERVING,
    RESOLVING_TARGET,
    VALIDATING_TARGET,
    EXECUTING_ACTION,
    WAITING_FOR_UI,
    VERIFYING,
    NEXT_STEP,
    RETRY,
    REOBSERVE,
    WAITING_FOR_CONFIRMATION,
    WAITING_FOR_USER,
    COMPLETED,
    FAILED,
    CANCELLED
}

class IllegalStateTransitionException(from: AgentState, to: AgentState) :
    IllegalStateException("Illegal transition $from -> $to")

class TaskStateMachine(initial: AgentState = AgentState.IDLE) {

    var state: AgentState = initial
        private set

    private val history = ArrayList<AgentState>()

    val isTerminal: Boolean get() = state in TERMINAL

    fun moveTo(next: AgentState) {
        if (isLegal(state, next)) {
            history += next
            state = next
        } else {
            throw IllegalStateTransitionException(state, next)
        }
    }

    fun history(): List<AgentState> = history.toList()

    fun isLegalTarget(target: AgentState): Boolean = isLegal(state, target)

    /**
     * Shortest legal sequence of states leading from the current state to [target], or null
     * when the target is unreachable. Every step in the returned path is itself a legal
     * transition, so walking it keeps the whole state machine auditable instead of jumping
     * straight to a state that only makes sense in the middle of an action.
     */
    fun pathTo(target: AgentState): List<AgentState>? {
        if (state == target) return emptyList()
        if (isLegal(state, target)) return listOf(target)
        if (state in TERMINAL) return null

        val queue = ArrayDeque<Pair<AgentState, List<AgentState>>>()
        val seen = HashSet<AgentState>()
        queue.add(state to emptyList())
        seen.add(state)
        while (queue.isNotEmpty()) {
            val (node, path) = queue.removeFirst()
            for (next in TABLE[node].orEmpty()) {
                if (!seen.add(next)) continue
                val extended = path + next
                if (next == target) return extended
                queue.add(next to extended)
            }
        }
        return null
    }

    /** Walks a legal path to [target]. Returns false when the target is unreachable. */
    fun advanceTo(target: AgentState): Boolean {
        val path = pathTo(target) ?: return false
        path.forEach { moveTo(it) }
        return true
    }

    /**
     * Re-synchronise the machine between two steps. This is only ever called from the step
     * loop, never while an action is in flight, so it cannot mask a bad intra-action
     * transition. Terminal states are never left.
     */
    fun resynchronise(): Boolean {
        if (state in TERMINAL) return false
        if (state == AgentState.IDLE) return false
        state = AgentState.IDLE
        history += state
        return true
    }

    fun reset() {
        state = AgentState.IDLE
        history.clear()
    }

    companion object {
        val TERMINAL = setOf(AgentState.COMPLETED, AgentState.FAILED, AgentState.CANCELLED)

        private val TABLE: Map<AgentState, Set<AgentState>> = mapOf(
            AgentState.IDLE to setOf(AgentState.OPENING_APP, AgentState.OBSERVING),
            AgentState.OPENING_APP to setOf(AgentState.OBSERVING, AgentState.WAITING_FOR_UI),
            AgentState.OBSERVING to setOf(
                AgentState.RESOLVING_TARGET,
                AgentState.WAITING_FOR_USER,
                AgentState.VERIFYING,
                AgentState.REOBSERVE
            ),
            AgentState.RESOLVING_TARGET to setOf(
                AgentState.VALIDATING_TARGET,
                AgentState.REOBSERVE,
                AgentState.NEXT_STEP
            ),
            AgentState.VALIDATING_TARGET to setOf(AgentState.EXECUTING_ACTION, AgentState.REOBSERVE),
            AgentState.EXECUTING_ACTION to setOf(AgentState.WAITING_FOR_UI, AgentState.RETRY),
            AgentState.WAITING_FOR_UI to setOf(AgentState.OBSERVING, AgentState.VERIFYING, AgentState.NEXT_STEP),
            AgentState.VERIFYING to setOf(AgentState.NEXT_STEP, AgentState.RETRY, AgentState.WAITING_FOR_CONFIRMATION),
            AgentState.NEXT_STEP to setOf(AgentState.OBSERVING, AgentState.OPENING_APP, AgentState.RESOLVING_TARGET),
            AgentState.RETRY to setOf(AgentState.REOBSERVE),
            AgentState.REOBSERVE to setOf(AgentState.OBSERVING, AgentState.RESOLVING_TARGET),
            AgentState.WAITING_FOR_CONFIRMATION to setOf(AgentState.NEXT_STEP, AgentState.RESOLVING_TARGET),
            AgentState.WAITING_FOR_USER to setOf(AgentState.OBSERVING, AgentState.FAILED),
            AgentState.COMPLETED to emptySet(),
            AgentState.FAILED to emptySet(),
            AgentState.CANCELLED to emptySet()
        )

        fun isLegal(from: AgentState, to: AgentState): Boolean {
            if (from in TERMINAL) return false
            // A task can end in any of these from wherever it currently is.
            if (to in setOf(AgentState.COMPLETED, AgentState.FAILED, AgentState.CANCELLED)) return true
            return TABLE[from]?.contains(to) == true
        }
    }
}
