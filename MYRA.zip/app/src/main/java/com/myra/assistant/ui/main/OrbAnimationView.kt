package com.myra.assistant.ui.main

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.util.AttributeSet
import android.view.View
import android.view.animation.LinearInterpolator
import androidx.core.content.ContextCompat
import com.myra.assistant.R
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

class OrbAnimationView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : View(context, attrs, defStyleAttr) {

    enum class State { IDLE, LISTENING, SPEAKING, THINKING, ACTIVE }

    private val density = resources.displayMetrics.density
    private val corePaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val glowPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val ringPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
    }
    private val wavePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
    }
    private val particlePaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val arcPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
    }
    private val highlightPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val wavePath = Path()
    private val arcRect = RectF()

    private var state: State = State.IDLE
    private var pulseScale = 1f
    private var glowAlpha = 120f
    private var rotationAngle = 0f
    private var waveOffset = 0f
    private var amplitude = 0f
    private var smoothedAmplitude = 0f

    private var coreColorStart = color(R.color.myra_orb_idle_start)
    private var coreColorEnd = color(R.color.myra_orb_idle_end)

    private val pulseAnimator = ValueAnimator.ofFloat(1f, 1.15f, 1f).apply {
        duration = 1500
        repeatCount = ValueAnimator.INFINITE
        interpolator = LinearInterpolator()
        addUpdateListener {
            pulseScale = it.animatedValue as Float
            glowAlpha = 120f + (it.animatedFraction * 100f)
            invalidate()
        }
    }

    private val rotationAnimator = ValueAnimator.ofFloat(0f, 360f).apply {
        duration = 4200
        repeatCount = ValueAnimator.INFINITE
        interpolator = LinearInterpolator()
        addUpdateListener {
            rotationAngle = it.animatedValue as Float
            invalidate()
        }
    }

    private val waveAnimator = ValueAnimator.ofFloat(0f, 360f).apply {
        duration = 1800
        repeatCount = ValueAnimator.INFINITE
        interpolator = LinearInterpolator()
        addUpdateListener {
            waveOffset = it.animatedValue as Float
            invalidate()
        }
    }

    private val thinkingAnimator = ValueAnimator.ofFloat(0f, 360f).apply {
        duration = 1100
        repeatCount = ValueAnimator.INFINITE
        interpolator = LinearInterpolator()
        addUpdateListener {
            rotationAngle = it.animatedValue as Float
            invalidate()
        }
    }

    init {
        setLayerType(LAYER_TYPE_SOFTWARE, null)
        applyStateColors()
    }

    private fun color(resId: Int): Int = ContextCompat.getColor(context, resId)

    fun setState(newState: State) {
        if (state == newState) return
        state = newState
        applyStateColors()
        restartAnimators()
    }

    fun getState(): State = state

    fun setAmplitude(value: Float) {
        amplitude = value.coerceIn(0f, 1f)
        invalidate()
    }

    private fun applyStateColors() {
        coreColorStart = when (state) {
            State.IDLE -> color(R.color.myra_orb_idle_start)
            State.LISTENING -> color(R.color.myra_orb_active_start)
            State.SPEAKING -> color(R.color.myra_orb_speaking_start)
            State.THINKING -> color(R.color.myra_orb_thinking_start)
            State.ACTIVE -> color(R.color.myra_orb_active_start)
        }
        coreColorEnd = when (state) {
            State.IDLE -> color(R.color.myra_orb_idle_end)
            State.LISTENING -> color(R.color.myra_orb_active_end)
            State.SPEAKING -> color(R.color.myra_orb_speaking_end)
            State.THINKING -> color(R.color.myra_orb_thinking_end)
            State.ACTIVE -> color(R.color.myra_orb_active_end)
        }
    }

    private fun restartAnimators() {
        pulseAnimator.cancel()
        rotationAnimator.cancel()
        waveAnimator.cancel()
        thinkingAnimator.cancel()

        when (state) {
            State.IDLE -> {
                pulseAnimator.start()
                glowAlpha = 120f
            }

            State.LISTENING, State.ACTIVE -> {
                rotationAnimator.start()
                waveAnimator.start()
            }

            State.SPEAKING -> {
                waveAnimator.duration = 1100
                rotationAnimator.duration = 2400
                rotationAnimator.start()
                waveAnimator.start()
            }

            State.THINKING -> {
                thinkingAnimator.start()
            }
        }
    }

    override fun onDetachedFromWindow() {
        super.onDetachedFromWindow()
        pulseAnimator.cancel()
        rotationAnimator.cancel()
        waveAnimator.cancel()
        thinkingAnimator.cancel()
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        val cx = w / 2f
        val cy = h / 2f
        val radius = min(w, h) / 2f

        glowPaint.shader = RadialGradient(
            cx, cy, radius * 1.6f,
            intArrayOf(
                withAlpha(coreColorStart, (150 * glowAlpha / 255f).toInt()),
                withAlpha(coreColorEnd, 90),
                Color.TRANSPARENT
            ),
            floatArrayOf(0f, 0.55f, 1f),
            Shader.TileMode.CLAMP
        )
        highlightPaint.shader = RadialGradient(
            cx - radius * 0.3f, cy - radius * 0.35f, radius * 0.42f,
            intArrayOf(Color.argb(140, 255, 255, 255), Color.TRANSPARENT),
            floatArrayOf(0f, 1f),
            Shader.TileMode.CLAMP
        )
        arcRect.set(cx - radius * 0.92f, cy - radius * 0.92f, cx + radius * 0.92f, cy + radius * 0.92f)
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0f || h <= 0f) return
        val cx = w / 2f
        val cy = h / 2f
        val baseRadius = min(w, h) / 2f
        smoothedAmplitude += (amplitude - smoothedAmplitude) * 0.25f

        val radius = baseRadius * 0.52f * pulseScale * (1f + smoothedAmplitude * 0.10f)

        drawGlow(canvas, cx, cy, baseRadius)
        drawCore(canvas, cx, cy, radius)
        drawRings(canvas, cx, cy, radius)
        if (state == State.SPEAKING || state == State.LISTENING || state == State.ACTIVE) {
            drawWaveRings(canvas, cx, cy, radius)
        }
        if (state == State.THINKING) {
            drawThinkingArc(canvas, cx, cy, radius)
        }
        if (state == State.SPEAKING || state == State.ACTIVE) {
            drawParticles(canvas, cx, cy, radius)
        }
        drawHighlight(canvas, cx, cy, radius)
    }

    private fun drawGlow(canvas: Canvas, cx: Float, cy: Float, baseRadius: Float) {
        glowPaint.alpha = (120f + glowAlpha).toInt().coerceIn(0, 255)
        canvas.drawCircle(cx, cy, baseRadius, glowPaint)
    }

    private fun drawCore(canvas: Canvas, cx: Float, cy: Float, radius: Float) {
        corePaint.shader = RadialGradient(
            cx - radius * 0.25f, cy - radius * 0.3f, radius * 1.5f,
            intArrayOf(coreColorStart, coreColorEnd, Color.argb(60, 0, 0, 0)),
            floatArrayOf(0f, 0.65f, 1f),
            Shader.TileMode.CLAMP
        )
        canvas.drawCircle(cx, cy, radius, corePaint)
    }

    private fun drawRings(canvas: Canvas, cx: Float, cy: Float, radius: Float) {
        val ringColor = coreColorStart
        for (i in 0 until 3) {
            val rr = radius * (1.25f + i * 0.22f)
            ringPaint.strokeWidth = max(1.4f * density, radius * 0.035f)
            ringPaint.color = withAlpha(ringColor, (200 - i * 55).coerceIn(30, 255))
            canvas.save()
            canvas.rotate(rotationAngle * (if (i % 2 == 0) 1f else -1f) + i * 60f, cx, cy)
            val segments = 4 + i
            val sweep = 360f / (segments * 2)
            canvas.drawArc(
                cx - rr, cy - rr, cx + rr, cy + rr,
                0f, sweep * 2, false, ringPaint
            )
            canvas.drawArc(
                cx - rr, cy - rr, cx + rr, cy + rr,
                180f, sweep * 2, false, ringPaint
            )
            canvas.restore()
        }
    }

    private fun drawWaveRings(canvas: Canvas, cx: Float, cy: Float, radius: Float) {
        val amplitudePx = radius * (0.10f + smoothedAmplitude * 0.42f)
        val waveCount = 3
        for (ring in 0 until waveCount) {
            val rr = radius * (1.45f + ring * 0.28f)
            val phase = Math.toRadians((waveOffset + ring * 40f).toDouble())
            wavePaint.strokeWidth = max(1.2f * density, radius * 0.03f)
            wavePaint.color = withAlpha(
                if (state == State.SPEAKING) coreColorStart else coreColorEnd,
                (150 - ring * 35).coerceIn(40, 255)
            )
            wavePath.reset()
            val steps = 72
            for (i in 0..steps) {
                val angle = i * 2.0 * Math.PI / steps
                val wobble = sin(angle * 3.0 + phase) * amplitudePx
                val px = cx + cos(angle) * (rr + wobble)
                val py = cy + sin(angle) * (rr + wobble)
                if (i == 0) wavePath.moveTo(px.toFloat(), py.toFloat()) else wavePath.lineTo(px.toFloat(), py.toFloat())
            }
            wavePath.close()
            canvas.drawPath(wavePath, wavePaint)
        }
    }

    private fun drawThinkingArc(canvas: Canvas, cx: Float, cy: Float, radius: Float) {
        val rr = radius * 1.35f
        arcPaint.strokeWidth = max(2f * density, radius * 0.06f)
        arcPaint.color = withAlpha(coreColorStart, 230)
        canvas.drawArc(arcRect.left, arcRect.top, arcRect.right, arcRect.bottom, rotationAngle, 100f, false, arcPaint)
        arcPaint.color = withAlpha(Color.WHITE, 180)
        canvas.drawArc(
            arcRect.left - rr * 0.18f, arcRect.top - rr * 0.18f,
            arcRect.right + rr * 0.18f, arcRect.bottom + rr * 0.18f,
            -rotationAngle * 1.6f, 70f, false, arcPaint
        )
    }

    private fun drawParticles(canvas: Canvas, cx: Float, cy: Float, radius: Float) {
        particlePaint.color = withAlpha(Color.WHITE, 210)
        for (i in 0 until 12) {
            val angle = Math.toRadians(((waveOffset * 1.4 + i * 30).toDouble()))
            val orbit = radius * (1.7f + 0.25f * sin((waveOffset + i * 17).toDouble()).toFloat())
            val px = cx + cos(angle).toFloat() * orbit
            val py = cy + sin(angle).toFloat() * orbit
            particlePaint.radius = max(1.2f * density, radius * (0.03f + smoothedAmplitude * 0.03f))
            canvas.drawCircle(px, py, particlePaint.radius, particlePaint)
        }
    }

    private fun drawHighlight(canvas: Canvas, cx: Float, cy: Float, radius: Float) {
        canvas.drawCircle(cx - radius * 0.28f, cy - radius * 0.32f, radius * 0.5f, highlightPaint)
    }

    private fun withAlpha(color: Int, alpha: Int): Int =
        Color.argb(alpha.coerceIn(0, 255), Color.red(color), Color.green(color), Color.blue(color))
}
