package com.myra.assistant.social

sealed class TargetWait {
    data class Found(
        val observation: ScreenObservation,
        val spec: TargetSpec,
        val element: UiElement,
        val strategy: MatchStrategy
    ) : TargetWait()

    data class TimedOut(val waitedMs: Long, val lastReason: String) : TargetWait() {
        val detail: String get() = "timed out after ${waitedMs}ms ($lastReason)"
    }
}

sealed class TapOutcome {
    data class Success(
        val observation: ScreenObservation,
        val spec: TargetSpec,
        val strategy: MatchStrategy,
        val usedGesture: Boolean,
        val attempts: Int
    ) : TapOutcome()

    data class Failed(
        val failure: ActionFailure,
        val detail: String,
        val attempts: Int
    ) : TapOutcome()
}

sealed class ExpectationResult {
    data class Satisfied(val observation: ScreenObservation, val reacted: Boolean) : ExpectationResult()
    data class NotSatisfied(val reason: String, val reacted: Boolean) : ExpectationResult()

    val isSatisfied: Boolean get() = this is Satisfied
}

class UiActionExecutor(
    private val driver: ScreenDriver,
    private val config: AgentConfig = AgentConfig(),
    private val clock: AgentClock = WallClock,
    private val log: AgentLog = NoopAgentLog
) {

    fun waitForTarget(
        spec: TargetSpec,
        allowedPackages: Set<String>,
        timeoutMs: Long = config.targetResolutionTimeoutMs
    ): TargetWait {
        val start = clock.nowMs()
        var lastReason = "never observed"
        while (clock.elapsed(start) < timeoutMs) {
            val observation = driver.observe()
            log.observation(observation)
            when (val result = TargetResolver.resolve(observation, spec, allowedPackages)) {
                is ResolveResult.Resolved ->
                    if (Freshness.isCurrent(observation, driver)) {
                        return TargetWait.Found(observation, spec, result.element, result.strategy)
                    } else {
                        lastReason = "observation ${observation.observationId} already stale"
                    }

                is ResolveResult.Ambiguous ->
                    lastReason = "ambiguous: ${result.candidates.size} candidates"

                is ResolveResult.NotFound -> lastReason = result.reason
            }
            clock.sleep(POLL_MS)
        }
        return TargetWait.TimedOut(clock.elapsed(start), lastReason)
    }

    /**
     * Taps a target and waits for the result.
     *
     * [maxRetries] is the total number of attempts, not the number of extra tries, so a
     * publish tap passes 1 to guarantee the control is pressed at most once.
     */
    fun tap(
        spec: TargetSpec,
        allowedPackages: Set<String>,
        expectation: Expectation = Expectation.ScreenChanges,
        goneSpec: TargetSpec = spec,
        requireStableBounds: Boolean = true,
        maxRetries: Int = config.maxRetries
    ): TapOutcome {
        var attempts = 0
        var lastFailure = ActionFailure.TARGET_NOT_FOUND
        var lastDetail = "not attempted"

        while (attempts < maxRetries) {
            attempts++
            val wait = waitForTarget(spec, allowedPackages)
            if (wait !is TargetWait.Found) {
                return if (wait is TargetWait.TimedOut) {
                    TapOutcome.Failed(ActionFailure.TARGET_NOT_FOUND, wait.detail, attempts)
                } else {
                    lastDetail = "target unavailable"
                    continue
                }
            }

            if (requireStableBounds && !boundsStable(wait, spec, allowedPackages)) {
                lastFailure = ActionFailure.ELEMENT_MOVED
                lastDetail = "${spec.name} bounds changed between two fresh observations"
                log.warn(lastDetail)
                driver.invalidateObservations()
                continue
            }

            // The baseline is taken before the action so a screen change that lands during the
            // tap is still seen as a change.
            val baselineId = driver.latestObservationId()
            val attempt = actOn(wait, spec)
            log.action("tap ${spec.name} via ${wait.strategy} -> ${attempt.result.javaClass.simpleName}")
            driver.invalidateObservations()

            val action = attempt.result
            if (action is ActionResult.Failed) {
                lastFailure = action.failure
                lastDetail = action.detail
                when (action.failure) {
                    ActionFailure.STALE_OBSERVATION, ActionFailure.ELEMENT_MOVED, ActionFailure.ELEMENT_GONE -> {
                        driver.invalidateObservations()
                        continue
                    }

                    ActionFailure.SCREEN_UNCHANGED -> continue
                    else -> return TapOutcome.Failed(lastFailure, lastDetail, attempts)
                }
            }

            val applied = action as ActionResult.Applied
            val check = awaitExpectation(expectation, allowedPackages, goneSpec, applied.screenChanged, baselineId)
            if (check is ExpectationResult.Satisfied) {
                return TapOutcome.Success(
                    observation = check.observation,
                    spec = spec,
                    strategy = wait.strategy,
                    usedGesture = attempt.usedGesture,
                    attempts = attempts
                )
            }

            lastFailure = ActionFailure.SCREEN_UNCHANGED
            lastDetail = check.reason
            if (check.reacted) {
                return TapOutcome.Failed(
                    ActionFailure.SCREEN_UNCHANGED,
                    "screen reacted but ${spec.name} did not produce the expected result",
                    attempts
                )
            }
            log.warn("retrying ${spec.name}: ${check.reason}")
        }
        return TapOutcome.Failed(lastFailure, lastDetail, attempts)
    }

    /**
     * Waits until [expectation] holds. [baselineId] is the observation id observed before the
     * action; pass -1 to use whatever is current, which is only correct for callers that are
     * not reacting to their own action.
     */
    fun awaitExpectation(
        expectation: Expectation,
        allowedPackages: Set<String>,
        goneSpec: TargetSpec,
        alreadyReacted: Boolean,
        baselineId: Long = -1L,
        timeoutMs: Long = config.maxUiSettleMs
    ): ExpectationResult {
        if (expectation is Expectation.Nothing) {
            return ExpectationResult.Satisfied(driver.observe(), alreadyReacted)
        }
        val baseline = if (baselineId >= 0) baselineId else driver.latestObservationId()
        val start = clock.nowMs()
        var lastReason = "never evaluated"

        while (clock.elapsed(start) < timeoutMs) {
            val observation = driver.observe()
            when (val result = evaluate(observation, expectation, allowedPackages, goneSpec, baseline)) {
                is ExpectationResult.Satisfied -> return result
                is ExpectationResult.NotSatisfied -> lastReason = result.reason
            }
            clock.sleep(POLL_MS)
        }
        return ExpectationResult.NotSatisfied(lastReason, reacted = alreadyReacted)
    }

    fun scrollUntilVisible(
        spec: TargetSpec,
        allowedPackages: Set<String>,
        direction: ScrollDirection = ScrollDirection.DOWN
    ): TargetWait {
        repeat(config.maxSwipesPerScroll) {
            val wait = waitForTarget(spec, allowedPackages, timeoutMs = SCROLL_PROBE_MS)
            if (wait is TargetWait.Found) return wait
            val observation = driver.observe()
            val scrollable = observation.elements.firstOrNull { it.scrollable }
            if (scrollable != null) {
                driver.scroll(scrollable.elementId, direction, SWIPE_PX)
            }
            clock.sleep(SWIPE_SETTLE_MS)
        }
        return waitForTarget(spec, allowedPackages, timeoutMs = SCROLL_PROBE_MS)
    }

    private fun evaluate(
        observation: ScreenObservation,
        expectation: Expectation,
        allowed: Set<String>,
        goneSpec: TargetSpec,
        baselineId: Long
    ): ExpectationResult = when (expectation) {
        is Expectation.Nothing -> ExpectationResult.Satisfied(observation, false)
        // A change only counts when a genuinely newer observation exists. The first
        // observation after an action always has a new id, so this cannot pass on a stale tree.
        is Expectation.ScreenChanges ->
            if (observation.observationId != baselineId) {
                ExpectationResult.Satisfied(observation, true)
            } else {
                ExpectationResult.NotSatisfied("screen has not changed yet", reacted = false)
            }

        is Expectation.TargetGone ->
            if (TargetResolver.resolve(observation, goneSpec, allowed).elementOrNull == null) {
                ExpectationResult.Satisfied(observation, true)
            } else {
                ExpectationResult.NotSatisfied("${goneSpec.name} is still present", reacted = false)
            }

        is Expectation.Appears -> {
            val hit = TargetResolver.resolveAny(observation, expectation.specs, allowed)
            val element = (hit?.second as? ResolveResult.Resolved)?.element
            when {
                element == null -> ExpectationResult.NotSatisfied(
                    "${expectation.specs.joinToString("|") { it.name }} not visible",
                    reacted = false
                )

                expectation.requireEnabled && !element.enabled -> ExpectationResult.NotSatisfied(
                    "${expectation.specs.joinToString("|") { it.name }} is disabled",
                    reacted = false
                )

                else -> ExpectationResult.Satisfied(observation, true)
            }
        }

        is Expectation.AnyOf -> {
            var firstReason = "no options evaluated"
            expectation.options.forEach { option ->
                when (val r = evaluate(observation, option, allowed, goneSpec, baselineId)) {
                    is ExpectationResult.Satisfied -> return r
                    is ExpectationResult.NotSatisfied -> firstReason = r.reason
                }
            }
            ExpectationResult.NotSatisfied(firstReason, reacted = false)
        }
    }

    private fun boundsStable(
        wait: TargetWait.Found,
        spec: TargetSpec,
        allowedPackages: Set<String>
    ): Boolean {
        val first = wait.element.bounds
        clock.sleep(STABILITY_PROBE_MS)
        driver.invalidateObservations()
        val second = waitForTarget(spec, allowedPackages, timeoutMs = STABILITY_TIMEOUT_MS)
        if (second !is TargetWait.Found) return false
        return second.element.bounds == first
    }

    private fun actOn(wait: TargetWait.Found, spec: TargetSpec): ActionAttempt {
        if (!Freshness.isCurrent(wait.observation, driver)) {
            return ActionAttempt(
                ActionResult.fail(
                    ActionFailure.STALE_OBSERVATION,
                    "observation ${wait.observation.observationId} is no longer current"
                ),
                usedGesture = false
            )
        }
        val direct = driver.click(wait.element.elementId)
        if (direct is ActionResult.Applied) return ActionAttempt(direct, usedGesture = false)
        val failure = direct as ActionResult.Failed
        if (failure.failure == ActionFailure.NOT_CLICKABLE) {
            val gesture = driver.gestureTap(wait.element.elementId)
            if (gesture is ActionResult.Applied) return ActionAttempt(gesture, usedGesture = true)
            return ActionAttempt(gesture, usedGesture = true)
        }
        return ActionAttempt(failure, usedGesture = false)
    }

    private data class ActionAttempt(val result: ActionResult, val usedGesture: Boolean) {
        constructor(result: ActionResult) : this(result, false)
    }

    companion object {
        private const val POLL_MS = 220L
        private const val STABILITY_PROBE_MS = 260L
        private const val STABILITY_TIMEOUT_MS = 900L
        private const val SCROLL_PROBE_MS = 1_400L
        private const val SWIPE_PX = 900
        private const val SWIPE_SETTLE_MS = 500L
    }
}
