package com.myra.assistant.ui.social

import android.app.Activity
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Window
import android.widget.TextView
import com.myra.assistant.R
import com.myra.assistant.service.AccessibilityHelperService

/**
 * Debug only. Shows the live accessibility tree so selectors can be written against real
 * resource ids and bounds. It reads nothing else and never performs an action, which keeps it
 * safe to leave in the app while the social agent is under test.
 */
class SocialDebugActivity : Activity() {

    private val main = Handler(Looper.getMainLooper())
    private val output: TextView by lazy { findViewById(R.id.social_debug_output) }
    private var pending = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestWindowFeature(Window.FEATURE_NO_TITLE)
        setContentView(R.layout.activity_social_debug)

        findViewById<TextView>(R.id.social_debug_capture).setOnClickListener { capture() }
        findViewById<TextView>(R.id.social_debug_close).setOnClickListener { finish() }
    }

    private fun capture() {
        if (pending) return
        pending = true
        output.text = getString(R.string.social_debug_capturing)
        // Give the user three seconds to get to the screen they want described.
        main.postDelayed({ run() }, 3_000L)
    }

    private fun run() {
        val service = AccessibilityHelperService.instance
        val text = if (service == null) {
            getString(R.string.social_debug_no_service)
        } else {
            buildString {
                append(getString(R.string.social_debug_screen))
                append(' ').append(service.activePackageName()).append('/')
                append(service.activeWindowClass()).append('\n')
                service.dumpActiveTree().forEach { append(it).append('\n') }
            }
        }
        output.text = text
        pending = false
    }

    override fun onDestroy() {
        main.removeCallbacksAndMessages(null)
        super.onDestroy()
    }
}
