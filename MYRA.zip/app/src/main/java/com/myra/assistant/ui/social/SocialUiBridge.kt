package com.myra.assistant.ui.social

import android.app.AlertDialog
import android.content.Context
import android.speech.tts.TextToSpeech
import com.myra.assistant.R
import com.myra.assistant.model.AppCommand
import com.myra.assistant.service.AccessibilityHelperService
import com.myra.assistant.service.MyraSocialHost
import com.myra.assistant.social.AgentState
import com.myra.assistant.social.SocialAction
import com.myra.assistant.social.SocialAgentListener
import com.myra.assistant.social.SocialCommand
import com.myra.assistant.social.SocialMediaTask
import com.myra.assistant.social.SocialMode
import com.myra.assistant.social.SocialOutcome
import com.myra.assistant.social.SocialPlatform
import com.myra.assistant.social.SocialRequest
import com.myra.assistant.ui.main.OrbAnimationView

class SocialUiBridge(
    private val context: Context,
    private val onChat: (text: String, isUser: Boolean) -> Unit,
    private val onStatus: (text: String) -> Unit,
    private val onOrb: (OrbAnimationView.State) -> Unit
) : SocialAgentListener {

    private val host = MyraSocialHost(context)
    private var gate: AlertDialog? = null
    private var tts: TextToSpeech? = null

    init {
        // The agent speaks the publish question itself, so the question is heard even when
        // the confirmation dialog is dismissed.
        host.setSpeaker { message ->
            val engine = tts ?: TextToSpeech(context) { }.also { tts = it }
            engine.speak(message, TextToSpeech.QUEUE_ADD, null, "myra-social")
        }
    }

    override fun onState(state: AgentState, task: SocialMediaTask) {
        context.runOnUiThread {
            onStatus(task.currentStep.ifBlank { state.name })
            when (state) {
                AgentState.EXECUTING_ACTION -> onOrb(OrbAnimationView.State.THINKING)
                AgentState.WAITING_FOR_CONFIRMATION -> onOrb(OrbAnimationView.State.LISTENING)
                AgentState.WAITING_FOR_USER -> onOrb(OrbAnimationView.State.LISTENING)
                else -> Unit
            }
        }
    }

    override fun onOutcome(outcome: SocialOutcome) {
        context.runOnUiThread { present(outcome) }
    }

    fun handleCommand(command: AppCommand): Boolean = when (command.type) {
        AppCommand.Type.SOCIAL_POST -> {
            runSocial(command)
            true
        }

        AppCommand.Type.SOCIAL_CONFIRM -> {
            dispatchControl(SocialCommand.CONFIRM)
            true
        }

        AppCommand.Type.SOCIAL_REJECT -> {
            dispatchControl(SocialCommand.REJECT)
            true
        }

        AppCommand.Type.SOCIAL_RESUME -> {
            dispatchControl(SocialCommand.RESUME)
            true
        }

        AppCommand.Type.SOCIAL_STATUS -> {
            dispatchControl(SocialCommand.STATUS)
            true
        }

        else -> false
    }

    private fun runSocial(command: AppCommand) {
        val platform = SocialPlatform.parse(command.param("platform"))
        if (platform == null) {
            say("I do not know that app.")
            return
        }
        val action = runCatching { SocialAction.valueOf(command.param("action")) }.getOrNull()
        if (action == null) {
            say("I did not understand what kind of post that is.")
            return
        }
        val service = AccessibilityHelperService.instance
        if (service == null) {
            say("Turn on the MYRA accessibility service first, then I can post for you.")
            return
        }

        val request = SocialRequest(
            platform = platform,
            action = action,
            mediaRef = command.param("media_uri").ifBlank { null },
            caption = command.param("caption").ifBlank { null },
            mode = if (command.param("mode") == "draft") SocialMode.DRAFT else SocialMode.PUBLISH
        )

        Thread {
            service.ensureSocialAgent(host).setListener(this)
            deliver(service.runSocialTask(host, request))
        }.start()
    }

    private fun dispatchControl(command: SocialCommand) {
        val service = AccessibilityHelperService.instance ?: return
        Thread {
            service.ensureSocialAgent(host).setListener(this)
            deliver(service.controlSocialTask(host, command, null))
        }.start()
    }

    /**
     * Outcomes are shown from a single place. The agent is also a listener and calls
     * [onOutcome], so a result is presented once whichever path delivers it first.
     */
    private fun deliver(outcome: SocialOutcome) {
        context.runOnUiThread { present(outcome) }
    }

    private fun present(outcome: SocialOutcome) {
        when (outcome) {
            is SocialOutcome.Finished -> {
                gate?.dismiss()
                gate = null
                onOrb(OrbAnimationView.State.IDLE)
                onStatus(outcome.code.name)
                // fromMyra, so isUser = false
                onChat(outcome.message, false)
            }

            is SocialOutcome.AwaitingConfirmation -> {
                onOrb(OrbAnimationView.State.LISTENING)
                onStatus("Waiting for your yes")
                onChat(outcome.question, false)
                showGate(outcome)
            }

            is SocialOutcome.NeedsUser -> {
                gate?.dismiss()
                gate = null
                onOrb(OrbAnimationView.State.LISTENING)
                onStatus("Waiting for you")
                onChat(outcome.instruction, false)
            }

            is SocialOutcome.Busy -> {
                onStatus("Busy")
                onChat("I am already doing something. One moment.", false)
            }

            is SocialOutcome.Rejected -> {
                gate?.dismiss()
                gate = null
                onOrb(OrbAnimationView.State.IDLE)
                onChat(outcome.reason, false)
            }
        }
    }

    private fun showGate(outcome: SocialOutcome.AwaitingConfirmation) {
        if (gate != null) return
        gate = AlertDialog.Builder(context)
            .setTitle(R.string.social_confirm_title)
            .setMessage(outcome.question)
            .setPositiveButton(R.string.social_confirm_yes) { _, _ -> dispatchControl(SocialCommand.CONFIRM) }
            .setNegativeButton(R.string.social_confirm_no) { _, _ -> dispatchControl(SocialCommand.REJECT) }
            .setOnCancelListener { dispatchControl(SocialCommand.REJECT) }
            .setCancelable(true)
            .create()
        gate?.show()
    }

    private fun say(message: String) = context.runOnUiThread {
        onChat(message, false)
    }

    fun release() {
        gate?.dismiss()
        gate = null
        AccessibilityHelperService.instance?.socialAgentOrNull()?.setListener(null)
        tts?.stop()
        tts?.shutdown()
        tts = null
    }
}
