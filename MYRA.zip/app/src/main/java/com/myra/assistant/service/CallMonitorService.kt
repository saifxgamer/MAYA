package com.myra.assistant.service

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.database.Cursor
import android.os.Build
import android.provider.ContactsContract
import android.telephony.PhoneStateListener
import android.telephony.TelephonyManager
import android.util.Log
import androidx.core.content.ContextCompat
import com.myra.assistant.R
import com.myra.assistant.ui.main.MainActivity

class CallMonitorService : android.app.Service() {

    companion object {
        private const val TAG = "CallMonitor"
        const val CHANNEL_ID = "myra_call_channel"
        const val NOTIFICATION_ID = 4201
        const val ACTION_CALL_ENDED = "com.myra.CALL_ENDED"

        fun start(context: Context) {
            val intent = Intent(context, CallMonitorService::class.java)
            runCatching {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    context.startForegroundService(intent)
                } else {
                    context.startService(intent)
                }
            }.onFailure { Log.e(TAG, "could not start call monitor: ${it.message}") }
        }
    }

    private var telephonyManager: TelephonyManager? = null
    private var listener: PhoneStateListener? = null
    private var inCall = false

    override fun onBind(intent: Intent?) = null

    override fun onCreate() {
        super.onCreate()
        Fgs.ensureChannel(this, CHANNEL_ID, getString(R.string.call_notif_channel))
        val notification = Fgs.buildNotification(
            this,
            CHANNEL_ID,
            "MYRA is on call duty",
            "Incoming calls will be announced"
        )
        Fgs.startSafe(this, NOTIFICATION_ID, notification, Fgs.typePhoneCall())

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_PHONE_STATE)
            != PackageManager.PERMISSION_GRANTED
        ) {
            Log.w(TAG, "READ_PHONE_STATE not granted, call monitoring idle")
            return
        }

        telephonyManager = getSystemService(Context.TELEPHONY_SERVICE) as? TelephonyManager
        val stateListener = object : PhoneStateListener() {
            override fun onCallStateChanged(state: Int, phoneNumber: String?) {
                handleCallState(state, phoneNumber)
            }
        }
        listener = stateListener
        runCatching {
            telephonyManager?.listen(stateListener, PhoneStateListener.LISTEN_CALL_STATE)
        }.onFailure { Log.e(TAG, "listen failed: ${it.message}") }
    }

    private fun handleCallState(state: Int, phoneNumber: String?) {
        when (state) {
            TelephonyManager.CALL_STATE_RINGING -> {
                val number = phoneNumber.orEmpty().ifBlank { lastIncomingNumber() }
                val name = resolveCallerName(number)
                Log.i(TAG, "Ringing from $number ($name)")
                inCall = true
                notifyIncomingCall(name, number)
            }

            TelephonyManager.CALL_STATE_OFFHOOK -> {
                inCall = true
            }

            TelephonyManager.CALL_STATE_IDLE -> {
                if (inCall) {
                    inCall = false
                    sendBroadcast(Intent(ACTION_CALL_ENDED).setPackage(packageName))
                }
            }
        }
    }

    @Suppress("MissingPermission")
    private fun lastIncomingNumber(): String = runCatching {
        telephonyManager?.line1Number.orEmpty()
    }.getOrDefault("")

    private fun notifyIncomingCall(name: String, number: String) {
        val intent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or
                Intent.FLAG_ACTIVITY_NEW_TASK or
                Intent.FLAG_ACTIVITY_REORDER_TO_FRONT
            putExtra(MainActivity.EXTRA_INCOMING_CALL, true)
            putExtra(MainActivity.EXTRA_CALLER_NAME, name)
            putExtra(MainActivity.EXTRA_CALLER_NUMBER, number)
        }
        runCatching {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
                startForeground(intent)
            } else {
                @Suppress("DEPRECATION")
                startActivity(intent)
            }
        }.onFailure {
            Log.e(TAG, "could not deliver call intent: ${it.message}")
        }
    }

    private fun resolveCallerName(number: String): String {
        if (number.isBlank()) return "Unknown"
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_CONTACTS)
            != PackageManager.PERMISSION_GRANTED
        ) {
            return number
        }
        val digits = number.filter { it.isDigit() }
        if (digits.length < 3) return number
        val tail = digits.takeLast(7)
        var cursor: Cursor? = null
        return try {
            cursor = contentResolver.query(
                ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                arrayOf(
                    ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                    ContactsContract.CommonDataKinds.Phone.NUMBER
                ),
                null,
                null,
                null
            )
            if (cursor != null && cursor.moveToFirst()) {
                val nameIndex = cursor.getColumnIndex(
                    ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME
                )
                val numberIndex = cursor.getColumnIndex(
                    ContactsContract.CommonDataKinds.Phone.NUMBER
                )
                while (cursor.moveToNext()) {
                    val candidateName = if (nameIndex >= 0) cursor.getString(nameIndex).orEmpty() else ""
                    val candidateNumber = if (numberIndex >= 0) cursor.getString(numberIndex).orEmpty() else ""
                    val candidateDigits = candidateNumber.filter { it.isDigit() }
                    if (candidateDigits.endsWith(tail) && candidateName.isNotBlank()) {
                        return candidateName
                    }
                }
            }
            number
        } catch (e: Exception) {
            Log.e(TAG, "contact lookup failed: ${e.message}")
            number
        } finally {
            cursor?.close()
        }
    }

    override fun onDestroy() {
        runCatching { telephonyManager?.listen(listener, PhoneStateListener.LISTEN_NONE) }
        listener = null
        telephonyManager = null
        super.onDestroy()
    }
}
