package com.myra.assistant.social

data class PendingMedia(
    val id: String,
    val uri: String,
    val mimeType: String,
    val sizeBytes: Long,
    val receivedAtMs: Long
) {
    fun isFresh(nowMs: Long, maxAgeMs: Long): Boolean = nowMs - receivedAtMs <= maxAgeMs
}

sealed class MediaResolution {
    data class Resolved(val media: PendingMedia) : MediaResolution()
    data class Rejected(val code: SocialResultCode, val reason: String) : MediaResolution()
    data object Required : MediaResolution()
}

object MediaResolver {

    const val MAX_AGE_MS = 30 * 60 * 1000L
    const val LATEST = "latest"

    private val BLOCKED_SCHEMES = setOf("file", "http", "https", "ftp", "javascript")
    private val ALLOWED_SCHEME = "content"
    private val ALLOWED_AUTHORITY = "com.myra.assistant.fileprovider"

    fun resolve(
        ref: String?,
        pending: List<PendingMedia>,
        nowMs: Long,
        maxAgeMs: Long = MAX_AGE_MS
    ): MediaResolution {
        if (ref.isNullOrBlank()) return newest(pending, nowMs, maxAgeMs)
        if (ref.trim().equals(LATEST, ignoreCase = true)) return newest(pending, nowMs, maxAgeMs)

        val scheme = ref.substringBefore(':', missingDelimiterValue = "").lowercase()
        if (scheme.isEmpty()) return MediaResolution.Rejected(
            SocialResultCode.SECURITY_BLOCKED,
            "raw path or unknown scheme"
        )
        if (scheme in BLOCKED_SCHEMES) {
            return MediaResolution.Rejected(SocialResultCode.SECURITY_BLOCKED, "scheme $scheme is not allowed")
        }
        if (scheme != ALLOWED_SCHEME) {
            return MediaResolution.Rejected(SocialResultCode.SECURITY_BLOCKED, "scheme $scheme is not allowed")
        }
        if (!ref.contains(ALLOWED_AUTHORITY)) {
            return MediaResolution.Rejected(
                SocialResultCode.SECURITY_BLOCKED,
                "content uri is not from MYRA"
            )
        }

        val match = pending.firstOrNull { it.uri == ref }
            ?: return MediaResolution.Rejected(SocialResultCode.MEDIA_REQUIRED, "not in the MYRA inbox")

        if (!match.isFresh(nowMs, maxAgeMs)) {
            return MediaResolution.Rejected(SocialResultCode.MEDIA_REQUIRED, "shared media is too old")
        }
        return MediaResolution.Resolved(match)
    }

    private fun newest(
        pending: List<PendingMedia>,
        nowMs: Long,
        maxAgeMs: Long
    ): MediaResolution {
        val fresh = pending.filter { it.isFresh(nowMs, maxAgeMs) }
        if (fresh.isEmpty()) return MediaResolution.Required
        val latest = fresh.maxByOrNull { it.receivedAtMs } ?: return MediaResolution.Required
        return MediaResolution.Resolved(latest)
    }

    fun isSupportedMime(mime: String): Boolean =
        mime.startsWith("image/") || mime.startsWith("video/")

    fun isPlausibleSize(bytes: Long): Boolean = bytes > 0
}
