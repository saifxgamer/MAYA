package com.myra.assistant.ui.main

import android.Manifest
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import com.myra.assistant.R
import com.myra.assistant.ai.AudioEngine
import com.myra.assistant.ai.CommandParser
import com.myra.assistant.ai.GeminiLiveClient
import com.myra.assistant.ai.LiveConfig
import com.myra.assistant.ai.LiveListener
import com.myra.assistant.databinding.ActivityMainBinding
import com.myra.assistant.model.MyraPrefs
import com.myra.assistant.model.PromptFactory
import com.myra.assistant.service.CallMonitorService
import com.myra.assistant.ui.settings.SettingsActivity
import com.myra.assistant.ai.SocialMediaTools
import com.myra.assistant.ui.social.SocialUiBridge
import com.myra.assistant.viewmodel.MainViewModel
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_INCOMING_CALL = "INCOMING_CALL"
        const val EXTRA_CALLER_NAME = "CALLER_NAME"
        const val EXTRA_CALLER_NUMBER = "CALLER_NUMBER"

        private const val GEMINI_START_DELAY_MS = 300L
        private const val GREETING_DELAY_MS = 600L
        private const val CALL_STT_DELAY_MS = 4_500L
        private const val STATUS_TICK_MS = 1_000L
        private const val SLOW_TICK_EVERY = 30

        private val ACCEPT_WORDS = listOf("uthao", "uthau", "utha do", "haan", "han", "accept", "hello", "pick up", "lelo", "jodo")
        private val REJECT_WORDS = listOf("reject", "nahi", "nahin", "mat", "katam", "kata do", "cut", "rehne do", "bhar do")
    }

    private lateinit var binding: ActivityMainBinding
    private lateinit var viewModel: MainViewModel
    private lateinit var chatAdapter: ChatAdapter
    private var socialBridge: SocialUiBridge? = null
    private val socialTools by lazy { SocialMediaTools(applicationContext) }

    @Volatile
    private var geminiLive: GeminiLiveClient? = null

    @Volatile
    private var audioEngine: AudioEngine? = null

    private val inputBuffer = StringBuilder()
    private val outputBuffer = StringBuilder()

    private var greetingSent = false
    private var isMuted = false
    private var isInCallMode = false
    private var isActiveMode = false

    private var speechRecognizer: SpeechRecognizer? = null

    private val handler = Handler(Looper.getMainLooper())
    private val timeFormat = SimpleDateFormat("HH:mm", Locale.getDefault())
    private var tickCount = 0

    private val statusRunnable = object : Runnable {
        override fun run() {
            tickCount++
            binding.timeText.text = timeFormat.format(Date())
            if (tickCount % SLOW_TICK_EVERY == 0) {
                updateBattery()
                updateRam()
            }
            handler.postDelayed(this, STATUS_TICK_MS)
        }
    }

    private val greetingRunnable = Runnable { sendGreeting() }

    private val callSttRunnable = Runnable { startCallSpeechRecognition() }

    private val callEndedReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            onCallEnded()
        }
    }

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { result ->
        if (result[Manifest.permission.RECORD_AUDIO] == false) {
            toast("Microphone permission is required for voice input")
        }
        maybeRequestOverlayPermission()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        viewModel = ViewModelProvider(this)[MainViewModel::class.java]
        MyraPrefs.load(this)

        initViews()
        observeViewModel()
        checkPermissions()
        startSystemServices()
        registerCallEndedReceiver()
        startStatusUpdates()

        handler.postDelayed({ initGeminiLive() }, GEMINI_START_DELAY_MS)
        handleIncomingCallIntent(intent)
    }

    // region setup

    private fun initViews() {
        chatAdapter = ChatAdapter()
        binding.chatRecycler.layoutManager = LinearLayoutManager(this).apply {
            stackFromEnd = true
        }
        binding.chatRecycler.adapter = chatAdapter

        binding.orbView.setState(OrbAnimationView.State.IDLE)
        binding.waveformView.reset()
        binding.micButton.setImageResource(R.drawable.ic_mic_on)

        binding.settingsBtn.setOnClickListener {
            startActivity(Intent(this, SettingsActivity::class.java))
        }

        binding.micButton.setOnClickListener {
            toggleMute()
        }

        binding.micButton.setOnLongClickListener {
            interruptMyra()
            true
        }
    }

    private fun observeViewModel() {
        viewModel.commandResult.observe(this) { result ->
            if (result.isNullOrBlank()) return@observe
            if (!isInCallMode) {
                geminiLive?.sendText("[SYSTEM RESULT: $result]")
            }
            viewModel.consumeResult()
        }

        viewModel.needsAccessibility.observe(this) { needed ->
            if (needed) {
                toast(getString(R.string.accessibility_required))
                openAccessibilitySettings()
            }
        }

        viewModel.toastMessage.observe(this) { message ->
            if (!message.isNullOrBlank()) toast(message)
            viewModel.consumeToast()
        }
    }

    private fun checkPermissions() {
        val wanted = mutableListOf(
            Manifest.permission.RECORD_AUDIO,
            Manifest.permission.READ_CONTACTS,
            Manifest.permission.READ_PHONE_STATE,
            Manifest.permission.CALL_PHONE,
            Manifest.permission.ANSWER_PHONE_CALLS
        )
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            wanted.add(Manifest.permission.POST_NOTIFICATIONS)
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            wanted.add(Manifest.permission.BLUETOOTH_CONNECT)
        }
        val missing = wanted.filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }
        if (missing.isNotEmpty()) {
            permissionLauncher.launch(missing.toTypedArray())
        } else {
            maybeRequestOverlayPermission()
        }
    }

    private fun maybeRequestOverlayPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
            runCatching {
                startActivity(
                    Intent(
                        Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:$packageName")
                    )
                )
            }
        }
    }

    private fun startSystemServices() {
        CallMonitorService.start(this)
    }

    private fun registerCallEndedReceiver() {
        val filter = IntentFilter(CallMonitorService.ACTION_CALL_ENDED)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            registerReceiver(callEndedReceiver, filter, Context.RECEIVER_NOT_EXPORTED)
        } else {
            @Suppress("UnspecifiedRegisterReceiverFlag")
            registerReceiver(callEndedReceiver, filter)
        }
    }

    private fun startStatusUpdates() {
        binding.timeText.text = timeFormat.format(Date())
        updateBattery()
        updateRam()
        handler.postDelayed(statusRunnable, STATUS_TICK_MS)
    }

    private fun updateBattery() {
        val intent = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val level = intent?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = intent?.getIntExtra(BatteryManager.EXTRA_SCALE, -1) ?: -1
        if (level >= 0 && scale > 0) {
            val percent = level * 100 / scale
            binding.batteryText.text = "$percent%"
        }
    }

    private fun updateRam() {
        val am = getSystemService(Context.ACTIVITY_SERVICE) as? android.app.ActivityManager ?: return
        val info = android.app.ActivityManager.MemoryInfo()
        am.getMemoryInfo(info)
        val usedMb = ((info.totalMem - info.availMem) / (1024L * 1024L)).toInt()
        val totalMb = (info.totalMem / (1024L * 1024L)).toInt()
        binding.ramText.text = String.format(Locale.US, "RAM %d/%dM", usedMb, totalMb)
    }

    // endregion

    // region gemini

    private fun initGeminiLive() {
        if (MyraPrefs.apiKey.isBlank()) {
            setStatus(getString(R.string.settings_api_key_missing))
            binding.orbView.setState(OrbAnimationView.State.THINKING)
            toast(getString(R.string.settings_api_key_missing))
            return
        }

        releaseGemini()

        val config = LiveConfig(
            apiKey = MyraPrefs.apiKey,
            model = MyraPrefs.model,
            voice = MyraPrefs.voice,
            systemInstruction = PromptFactory.systemInstruction(
                MyraPrefs.personality,
                MyraPrefs.userName,
                MyraPrefs.primeContacts(this)
            ) + "\n\n" + socialTools.systemInstructionBlock(),
            toolDeclarations = socialTools.declarations()
        )

        val engine = AudioEngine(this)
        audioEngine = engine
        engine.onAudioCaptured = { chunk ->
            geminiLive?.sendAudioChunk(chunk)
        }
        engine.onAmplitudeChanged = { rms ->
            binding.waveformView.setAmplitude(rms)
        }
        engine.onSpeakingStarted = {
            binding.orbView.setState(OrbAnimationView.State.SPEAKING)
            setStatus(getString(R.string.status_speaking))
            setActiveMode(true)
        }
        engine.onSpeakingStopped = {
            if (!isInCallMode) {
                binding.orbView.setState(OrbAnimationView.State.LISTENING)
                setStatus(
                    if (isMuted) getString(R.string.status_muted) else getString(R.string.status_listening)
                )
            }
        }
        engine.onError = { message ->
            setStatus(message)
        }

        val client = GeminiLiveClient(config, object : LiveListener {
            override fun onConnecting() {
                setStatus(getString(R.string.status_connecting))
                binding.orbView.setState(OrbAnimationView.State.THINKING)
            }

            override fun onSetupComplete() {
                setStatus(getString(R.string.status_listening))
                binding.orbView.setState(OrbAnimationView.State.LISTENING)
                if (!isInCallMode && !engine.isCapturing) {
                    engine.startRecording()
                }
                if (!engine.isSpeakingNow) {
                    engine.startPlayback()
                }
                binding.waveformView.startAnimation()
                if (!greetingSent) {
                    handler.postDelayed(greetingRunnable, GREETING_DELAY_MS)
                }
            }

            override fun onAudioReceived(data: ByteArray) {
                engine.queueAudio(data)
            }

            override fun onOutputTranscript(text: String) {
                appendTranscript(outputBuffer, text)
                binding.orbView.setState(OrbAnimationView.State.SPEAKING)
            }

            override fun onInputTranscript(text: String) {
                appendTranscript(inputBuffer, text)
                binding.orbView.setState(OrbAnimationView.State.THINKING)
            }

            override fun onTurnComplete() {
                flushTranscripts()
            }

            override fun onInterrupted() {
                inputBuffer.setLength(0)
                outputBuffer.setLength(0)
                if (!isInCallMode) {
                    binding.orbView.setState(OrbAnimationView.State.LISTENING)
                }
            }

            override fun onDisconnected(reason: String) {
                setStatus("Reconnecting… ($reason)")
                if (!isInCallMode) {
                    binding.orbView.setState(OrbAnimationView.State.THINKING)
                }
            }

            override fun onToolCall(id: String, name: String, args: org.json.JSONObject) {
                Thread {
                    val result = socialTools.handleCall(name, args)
                    val parsed = try {
                        org.json.JSONObject(result)
                    } catch (e: Exception) {
                        org.json.JSONObject().put("status", "error").put("message", "bad tool result")
                    }
                    val code = when (parsed.optString("code")) {
                        "PUBLISHED" -> "Post published."
                        "AWAITING_CONFIRMATION" -> parsed.optString("question", "Ready to post. Say yes?")
                        "MEDIA_REQUIRED" -> "Share the photo to me from your gallery first."
                        "USER_ACTION_REQUIRED" -> parsed.optString("instruction", "I need you to do something first.")
                        "SUBMITTED_UNVERIFIED" -> "Submitted, but I could not confirm it on screen."
                        "POSTED_UNKNOWN" -> "I am not sure if it posted."
                        "UNSUPPORTED_ACTION" -> "Instagram does not support text-only posts."
                        "ACCESSIBILITY_NOT_ENABLED" -> "Turn on the MYRA accessibility service first."
                        "APP_NOT_INSTALLED" -> "That app is not installed."
                        "SHARE_TARGET_NOT_FOUND" -> "I could not find a safe share target."
                        "REJECTED" -> "Okay, cancelled."
                        "BUSY" -> "I am already busy."
                        else -> parsed.optString("message", "Done.")
                    }
                    geminiLive?.sendText("[SYSTEM RESULT: $code]")
                    runOnUiThread { geminiLive?.sendToolResponse(id, name, parsed) }
                }.start()
            }

            override fun onError(message: String) {
                setStatus(message)
                toast(message)
            }
        })
        geminiLive = client
        client.connect()
    }

    private fun sendGreeting() {
        greetingSent = true
        val greeting = PromptFactory.greeting(MyraPrefs.personality, MyraPrefs.userName)
        geminiLive?.sendText(greeting)
    }

    private fun appendTranscript(buffer: StringBuilder, chunk: String) {
        val trimmed = chunk.trim()
        if (trimmed.isEmpty()) return
        if (buffer.isNotEmpty() && !buffer.toString().endsWith(" ")) buffer.append(' ')
        buffer.append(trimmed)
    }

    private fun flushTranscripts() {
        val userText = inputBuffer.toString().trim()
        val myraText = outputBuffer.toString().trim()
        inputBuffer.setLength(0)
        outputBuffer.setLength(0)

        if (userText.isNotEmpty()) {
            addMessage(ChatMessage(userText, isUser = true))
            if (!isInCallMode) {
                handleSpokenCommand(userText)
            }
        }
        if (myraText.isNotEmpty()) {
            addMessage(ChatMessage(myraText, isUser = false))
        }
    }

    private fun handleSpokenCommand(userText: String) {
        val gatePending = socialTools.socialGatePending()
        val command = CommandParser.parse(
            userText,
            MyraPrefs.primeContacts(this),
            socialGatePending = gatePending
        ) ?: return
        if (command.type.startsWith("SOCIAL_")) {
            ensureSocialBridge()
            if (socialBridge?.handleCommand(command) == true) return
        }
        viewModel.execute(command)
    }

    private fun ensureSocialBridge() {
        if (socialBridge != null) return
        socialBridge = SocialUiBridge(
            context = this,
            onChat = { text, isUser -> runOnUiThread { addMessage(ChatMessage(text, isUser)) } },
            onStatus = { text -> runOnUiThread { setStatus(text) } },
            onOrb = { state -> runOnUiThread { binding.orbView.setState(state) } }
        )
    }

    private fun addMessage(message: ChatMessage) {
        if (!chatAdapter.addMessage(message)) return
        binding.chatRecycler.post {
            binding.chatRecycler.scrollToPosition(chatAdapter.itemCount - 1)
        }
    }

    private fun setStatus(text: String) {
        binding.statusText.text = text
    }

    // endregion

    // region interaction

    private fun toggleMute() {
        isMuted = !isMuted
        audioEngine?.setMuted(isMuted)
        binding.micButton.setImageResource(if (isMuted) R.drawable.ic_mic_off else R.drawable.ic_mic_on)
        setStatus(
            if (isMuted) getString(R.string.status_muted) else getString(R.string.status_listening)
        )
        if (isMuted) {
            binding.waveformView.reset()
        } else {
            binding.waveformView.startAnimation()
        }
    }

    private fun interruptMyra() {
        audioEngine?.interruptPlayback()
        geminiLive?.interrupt()
        inputBuffer.setLength(0)
        outputBuffer.setLength(0)
        if (!isInCallMode) {
            binding.orbView.setState(OrbAnimationView.State.LISTENING)
            setStatus(getString(R.string.status_listening))
        }
        toast("MYRA stopped")
    }

    private fun setActiveMode(active: Boolean) {
        if (isActiveMode == active) return
        isActiveMode = active
        val target = if (active) 0.08f else 0f
        val duration = if (active) 300L else 500L
        binding.redOverlay.animate()
            .alpha(target)
            .setDuration(duration)
            .start()
        if (!active) {
            binding.orbView.setState(OrbAnimationView.State.IDLE)
        }
    }

    // endregion

    // region calls

    private fun handleIncomingCallIntent(intent: Intent?) {
        if (intent == null) return
        if (!intent.getBooleanExtra(EXTRA_INCOMING_CALL, false)) return
        val caller = intent.getStringExtra(EXTRA_CALLER_NAME)?.takeIf { it.isNotBlank() } ?: "Unknown"
        announceCall(caller)
    }

    private fun announceCall(callerName: String) {
        if (isInCallMode) return
        isInCallMode = true
        handler.removeCallbacks(callSttRunnable)
        handler.postDelayed(callSttRunnable, CALL_STT_DELAY_MS)

        audioEngine?.setCaptureSuppressed(true)
        audioEngine?.stopRecording()
        setActiveMode(true)
        binding.orbView.setState(OrbAnimationView.State.THINKING)
        setStatus("Incoming call: $callerName")

        val client = geminiLive
        if (client == null) {
            toast("Call from $callerName")
            return
        }
        client.sendText(PromptFactory.incomingCallLine(MyraPrefs.userName, callerName))
    }

    private fun startCallSpeechRecognition() {
        if (!isInCallMode) return
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            endCallMode()
            return
        }
        val recognizer = speechRecognizer ?: SpeechRecognizer.createSpeechRecognizer(this).also {
            it.setRecognitionListener(callRecognitionListener)
            speechRecognizer = it
        }
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(
                RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                RecognizerIntent.LANGUAGE_MODEL_FREE_FORM
            )
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN,en-IN")
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
        }
        runCatching { recognizer.startListening(intent) }
            .onFailure { endCallMode() }
    }

    private val callRecognitionListener = object : RecognitionListener {
        override fun onReadyForSpeech(params: Bundle?) = Unit
        override fun onBeginningOfSpeech() = Unit
        override fun onRmsChanged(rmsdB: Float) = Unit
        override fun onBufferReceived(buffer: ByteArray?) = Unit
        override fun onEndOfSpeech() = Unit
        override fun onEvent(eventType: Int, params: Bundle?) = Unit
        override fun onPartialResults(partialResults: Bundle?) = Unit
        override fun onError(error: Int) {
            endCallMode()
        }

        override fun onResults(results: Bundle?) {
            val spoken = results
                ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                ?.firstOrNull()
                .orEmpty()
                .lowercase(Locale.US)
            if (spoken.isBlank()) {
                endCallMode()
                return
            }
            val normalized = spoken.replace(Regex("[^a-z\\u0900-\\u097F ]"), " ").trim()
            val accept = ACCEPT_WORDS.any { normalized.contains(it) }
            val reject = REJECT_WORDS.any { normalized.contains(it) }
            when {
                accept -> {
                    viewModel.acceptCall()
                    confirmCallDecision("call accepted")
                }

                reject -> {
                    viewModel.rejectCall()
                    confirmCallDecision("call rejected")
                }

                else -> confirmCallDecision("no decision heard")
            }
        }
    }

    private fun confirmCallDecision(message: String) {
        geminiLive?.sendText("[SYSTEM RESULT: $message]")
        endCallMode()
    }

    private fun onCallEnded() {
        if (!isInCallMode) return
        geminiLive?.sendText("[SYSTEM RESULT: the call has ended]")
        endCallMode()
    }

    private fun endCallMode() {
        isInCallMode = false
        handler.removeCallbacks(callSttRunnable)
        runCatching { speechRecognizer?.cancel() }
        audioEngine?.setCaptureSuppressed(false)
        audioEngine?.startRecording()
        setActiveMode(false)
        setStatus(getString(R.string.status_idle))
        binding.orbView.setState(OrbAnimationView.State.LISTENING)
    }

    private fun openAccessibilitySettings() {
        runCatching {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
    }

    // endregion

    // region lifecycle

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIncomingCallIntent(intent)
    }

    override fun onResume() {
        super.onResume()
        audioEngine?.setMuted(isMuted)
    }

    override fun onPause() {
        super.onPause()
        audioEngine?.setMuted(true)
        handler.removeCallbacks(greetingRunnable)
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        handler.removeCallbacks(statusRunnable)
        handler.removeCallbacks(callSttRunnable)
        runCatching { speechRecognizer?.destroy() }
        speechRecognizer = null
        runCatching { unregisterReceiver(callEndedReceiver) }
        socialBridge?.release()
        socialBridge = null
        socialTools.release()
        releaseGemini()
        super.onDestroy()
    }

    private fun releaseGemini() {
        geminiLive?.disconnect()
        geminiLive = null
        audioEngine?.release()
        audioEngine = null
    }

    // endregion

    private fun toast(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }
}
