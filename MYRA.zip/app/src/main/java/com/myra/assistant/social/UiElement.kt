package com.myra.assistant.social

data class ElementBounds(
    val left: Int,
    val top: Int,
    val right: Int,
    val bottom: Int
) {
    val width: Int get() = right - left
    val height: Int get() = bottom - top
    val isEmpty: Boolean get() = width <= 0 || height <= 0
    val centerX: Int get() = left + width / 2
    val centerY: Int get() = top + height / 2
    val area: Long get() = width.toLong() * height.toLong()

    fun contains(x: Int, y: Int): Boolean = x in left..right && y in top..bottom

    fun verticallyOverlaps(other: ElementBounds): Boolean = top < other.bottom && other.top < bottom

    fun horizontallyOverlaps(other: ElementBounds): Boolean = left < other.right && other.left < right

    fun sameRow(other: ElementBounds, tolerancePx: Int = 24): Boolean {
        if (verticallyOverlaps(other)) return true
        val gap = top - other.bottom
        if (gap in 0..tolerancePx) return true
        val otherGap = other.top - bottom
        return otherGap in 0..tolerancePx
    }

    fun sameColumn(other: ElementBounds, tolerancePx: Int = 24): Boolean {
        if (horizontallyOverlaps(other)) return true
        val gap = left - other.right
        if (gap in 0..tolerancePx) return true
        val otherGap = other.left - right
        return otherGap in 0..tolerancePx
    }

    fun gapToLeftOf(other: ElementBounds): Int = other.left - right
    fun gapToRightOf(other: ElementBounds): Int = left - other.right
    fun gapAbove(other: ElementBounds): Int = other.top - bottom
    fun gapBelow(other: ElementBounds): Int = top - other.bottom

    override fun toString(): String = "[$left,$top][$right,$bottom]"
}

data class UiElement(
    val elementId: String,
    val observationId: Long,
    val index: Int,
    val packageName: String,
    val className: String,
    val text: String,
    val contentDescription: String,
    val hintText: String,
    val resourceId: String,
    val bounds: ElementBounds,
    val clickable: Boolean,
    val longClickable: Boolean,
    val enabled: Boolean,
    val selected: Boolean,
    val focused: Boolean,
    val focusable: Boolean,
    val scrollable: Boolean,
    val editable: Boolean,
    val checkable: Boolean,
    val checked: Boolean,
    val password: Boolean,
    val visible: Boolean,
    val depth: Int,
    val parentIndex: Int,
    val parentPath: String
) {
    val centerX: Int get() = bounds.centerX
    val centerY: Int get() = bounds.centerY
    val hasBounds: Boolean get() = !bounds.isEmpty

    val label: String
        get() = text.ifBlank { contentDescription }.ifBlank { hintText }

    val simpleClassName: String
        get() = className.substringAfterLast('.')

    fun sharesParentWith(other: UiElement): Boolean =
        parentPath.isNotEmpty() && parentPath == other.parentPath

    fun describe(): String = buildString {
        append("#").append(index)
        append(" [").append(simpleClassName).append("] ")
        if (resourceId.isNotBlank()) append("id=").append(TargetResolver.bareResourceId(resourceId)).append(" ")
        if (text.isNotBlank()) append("text=\"").append(text.take(40)).append("\" ")
        if (contentDescription.isNotBlank()) append("desc=\"").append(contentDescription.take(40)).append("\" ")
        append(bounds)
        if (clickable) append(" clickable")
        if (enabled) append(" enabled") else append(" disabled")
        if (editable) append(" editable")
        if (selected) append(" selected")
    }
}
