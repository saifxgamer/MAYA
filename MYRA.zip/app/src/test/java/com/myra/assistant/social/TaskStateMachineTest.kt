package com.myra.assistant.social

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class TaskStateMachineTest {

    @Test
    fun `retry must pass through reobserve`() {
        assertTrue(TaskStateMachine.isLegal(AgentState.EXECUTING_ACTION, AgentState.RETRY))
        assertTrue(TaskStateMachine.isLegal(AgentState.RETRY, AgentState.REOBSERVE))
        assertFalse("retry must not jump straight back to executing", TaskStateMachine.isLegal(AgentState.RETRY, AgentState.EXECUTING_ACTION))
    }

    @Test
    fun `terminal states have no exits`() {
        listOf(AgentState.COMPLETED, AgentState.FAILED, AgentState.CANCELLED).forEach { terminal ->
            AgentState.entries.forEach { target ->
                assertFalse("$terminal -> $target must be illegal", TaskStateMachine.isLegal(terminal, target))
            }
        }
    }

    @Test
    fun `failed and cancelled are reachable from any non terminal state`() {
        AgentState.entries
            .filter { it !in TaskStateMachine.TERMINAL }
            .forEach { from ->
                assertTrue(from.name, TaskStateMachine.isLegal(from, AgentState.FAILED))
                assertTrue(from.name, TaskStateMachine.isLegal(from, AgentState.CANCELLED))
            }
    }

    @Test
    fun `illegal transition throws`() {
        val machine = TaskStateMachine()
        var threw = false
        try {
            machine.moveTo(AgentState.VERIFYING)
        } catch (e: IllegalStateTransitionException) {
            threw = true
        }
        assertTrue(threw)
        assertEquals(AgentState.IDLE, machine.state)
    }

    @Test
    fun `legal path works and is recorded`() {
        val machine = TaskStateMachine()
        machine.moveTo(AgentState.OBSERVING)
        machine.moveTo(AgentState.RESOLVING_TARGET)
        machine.moveTo(AgentState.VALIDATING_TARGET)
        machine.moveTo(AgentState.EXECUTING_ACTION)
        machine.moveTo(AgentState.RETRY)
        machine.moveTo(AgentState.REOBSERVE)
        machine.moveTo(AgentState.OBSERVING)
        machine.moveTo(AgentState.RESOLVING_TARGET)
        machine.moveTo(AgentState.NEXT_STEP)
        assertEquals(AgentState.NEXT_STEP, machine.state)
        assertEquals(9, machine.history().size)
    }

    @Test
    fun `confirmation can be reached only from verifying or waiting`() {
        assertTrue(TaskStateMachine.isLegal(AgentState.VERIFYING, AgentState.WAITING_FOR_CONFIRMATION))
        assertFalse(TaskStateMachine.isLegal(AgentState.IDLE, AgentState.WAITING_FOR_CONFIRMATION))
    }

    @Test
    fun `completed is reachable from every non terminal state`() {
        AgentState.entries
            .filter { it !in TaskStateMachine.TERMINAL }
            .forEach { from ->
                assertTrue(from.name, TaskStateMachine.isLegal(from, AgentState.COMPLETED))
            }
    }

    @Test
    fun `a legal path exists from idle into every state a step needs`() {
        // The agent enters a step at EXECUTING_ACTION, WAITING_FOR_USER or VERIFYING. None of
        // those is a direct transition from IDLE, so the machine has to be able to walk there.
        val machine = TaskStateMachine()
        listOf(AgentState.EXECUTING_ACTION, AgentState.WAITING_FOR_USER, AgentState.VERIFYING)
            .forEach { target ->
                val probe = TaskStateMachine()
                assertTrue("no path to $target", probe.advanceTo(target))
                assertEquals(target, probe.state)
            }
        // And the path must itself be made of legal transitions only.
        val path = machine.pathTo(AgentState.EXECUTING_ACTION)!!
        assertEquals(
            listOf(
                AgentState.OBSERVING,
                AgentState.RESOLVING_TARGET,
                AgentState.VALIDATING_TARGET,
                AgentState.EXECUTING_ACTION
            ),
            path
        )
    }

    @Test
    fun `advanceTo never leaves a terminal machine`() {
        val machine = TaskStateMachine()
        machine.moveTo(AgentState.OBSERVING)
        machine.moveTo(AgentState.COMPLETED)
        assertFalse(machine.advanceTo(AgentState.EXECUTING_ACTION))
        assertEquals(AgentState.COMPLETED, machine.state)
    }

    @Test
    fun `advanceTo on the current state does nothing`() {
        val machine = TaskStateMachine()
        machine.moveTo(AgentState.OBSERVING)
        assertTrue(machine.advanceTo(AgentState.OBSERVING))
        assertEquals(AgentState.OBSERVING, machine.state)
        assertEquals(1, machine.history().size)
    }

    @Test
    fun `resynchronise refuses to leave a terminal state`() {
        val machine = TaskStateMachine()
        machine.moveTo(AgentState.OBSERVING)
        machine.moveTo(AgentState.CANCELLED)
        assertFalse(machine.resynchronise())
        assertEquals(AgentState.CANCELLED, machine.state)
    }
}

class MediaResolverTest {

    private val now = 1_700_000_000_000L
    private val inbox = listOf(
        PendingMedia("a", "content://com.myra.assistant.fileprovider/myra_inbox/a.jpg", "image/jpeg", 2000, now - 60_000),
        PendingMedia("b", "content://com.myra.assistant.fileprovider/myra_inbox/b.mp4", "video/mp4", 9000, now - 120_000)
    )

    @Test
    fun `empty ref picks the newest fresh item`() {
        val result = MediaResolver.resolve(null, inbox, now)
        assertTrue(result is MediaResolution.Resolved)
        assertEquals("a", (result as MediaResolution.Resolved).media.id)
    }

    @Test
    fun `latest keyword behaves like empty`() {
        val result = MediaResolver.resolve("latest", inbox, now)
        assertEquals("a", (result as MediaResolution.Resolved).media.id)
    }

    @Test
    fun `inbox uri is accepted`() {
        val result = MediaResolver.resolve(inbox[1].uri, inbox, now)
        assertEquals("b", (result as MediaResolution.Resolved).media.id)
    }

    @Test
    fun `file scheme is rejected`() {
        val result = MediaResolver.resolve("file:///data/user/0/com.myra.assistant/files/secret.jpg", inbox, now)
        assertTrue(result is MediaResolution.Rejected)
        assertEquals(SocialResultCode.SECURITY_BLOCKED, (result as MediaResolution.Rejected).code)
    }

    @Test
    fun `raw path is rejected`() {
        val result = MediaResolver.resolve("/data/media/0/photo.jpg", inbox, now)
        assertTrue(result is MediaResolution.Rejected)
        assertEquals(SocialResultCode.SECURITY_BLOCKED, (result as MediaResolution.Rejected).code)
    }

    @Test
    fun `http is rejected`() {
        val result = MediaResolver.resolve("http://example.com/a.jpg", inbox, now)
        assertTrue(result is MediaResolution.Rejected)
    }

    @Test
    fun `foreign content uri is rejected`() {
        val result = MediaResolver.resolve("content://media/external/images/media/42", inbox, now)
        assertTrue(result is MediaResolution.Rejected)
        assertEquals(SocialResultCode.SECURITY_BLOCKED, (result as MediaResolution.Rejected).code)
    }

    @Test
    fun `stale media is not usable`() {
        val old = listOf(
            PendingMedia("z", "content://com.myra.assistant.fileprovider/myra_inbox/z.jpg", "image/jpeg", 10, now - 60 * 60 * 1000L)
        )
        val result = MediaResolver.resolve("latest", old, now)
        assertEquals(MediaResolution.Required, result)
    }

    @Test
    fun `empty inbox asks for media`() {
        assertEquals(MediaResolution.Required, MediaResolver.resolve("latest", emptyList(), now))
    }

    @Test
    fun `mime validation`() {
        assertTrue(MediaResolver.isSupportedMime("image/jpeg"))
        assertTrue(MediaResolver.isSupportedMime("video/mp4"))
        assertFalse(MediaResolver.isSupportedMime("application/pdf"))
        assertFalse(MediaResolver.isSupportedMime("text/plain"))
    }
}
