package com.myra.assistant.social

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class FakeSocialHost(
    override var accessibilityEnabled: Boolean = true,
    override var installed: Boolean = true,
    override var shareHandler: Boolean = true,
    override var activityClass: String? = "com.instagram.android.ShareHandlerActivity",
    override var launchWorks: Boolean = true,
    override var sendWorks: Boolean = true,
    media: List<PendingMedia> = emptyList()
) : SocialAgentHost {
    val spoken = mutableListOf<String>()
    var launched = false
    var shared = false
    var windowStampAtShare = 0
    private var media = media

    fun setMedia(items: List<PendingMedia>) {
        media = items
    }

    override fun isAccessibilityEnabled() = accessibilityEnabled
    override fun isAppInstalled(platform: SocialPlatform) = installed
    override fun hasShareHandler(platform: SocialPlatform) = shareHandler
    override fun shareActivityClass(platform: SocialPlatform) = activityClass
    override fun launchApp(platform: SocialPlatform): Boolean {
        launched = true
        return launchWorks
    }

    override fun sendShareIntent(platform: SocialPlatform, activityClass: String, media: PendingMedia): Boolean {
        shared = true
        return sendWorks
    }

    override fun pendingMedia() = media
    override fun currentTimeMs() = 1_700_000_000_000L
    override fun speak(message: String) {
        spoken += message
    }
}

class SocialMediaPlanTest {

    @Test
    fun `instagram photo plan`() {
        val task = SocialRequest(SocialPlatform.INSTAGRAM, SocialAction.POST_MEDIA, caption = "hi").toTask("t1")
        val steps = SocialMediaPlan.stepsFor(task, hasShareHandler = true)
        assertEquals(
            listOf(
                SocialStep.SHARE_MEDIA,
                SocialStep.TAP_NEXT,
                SocialStep.TYPE_CAPTION,
                SocialStep.CONFIRM_PUBLISH,
                SocialStep.TAP_SHARE,
                SocialStep.VERIFY_POST
            ),
            steps
        )
    }

    @Test
    fun `share handler plans do not re-wait for a window`() {
        val task = SocialRequest(SocialPlatform.INSTAGRAM, SocialAction.POST_MEDIA).toTask("t1b")
        val steps = SocialMediaPlan.stepsFor(task, hasShareHandler = true)
        // shareMedia blocks on the new window itself, so the plan must not add a second wait.
        assertEquals(1, steps.count { it == SocialStep.SHARE_MEDIA })
        assertEquals(SocialStep.SHARE_MEDIA, steps.first())
        assertEquals(SocialStep.TAP_NEXT, steps[1])
    }

    @Test
    fun `instagram story plan publishes via your stories`() {
        val task = SocialRequest(SocialPlatform.INSTAGRAM, SocialAction.POST_STORY).toTask("t2")
        val steps = SocialMediaPlan.stepsFor(task, hasShareHandler = true)
        assertTrue(steps.contains(SocialStep.TAP_STORY_TARGET))
        assertTrue(!steps.contains(SocialStep.TAP_SHARE))
    }

    @Test
    fun `facebook text plan opens the app`() {
        val task = SocialRequest(SocialPlatform.FACEBOOK, SocialAction.POST_TEXT, caption = "hello").toTask("t3")
        val steps = SocialMediaPlan.stepsFor(task, hasShareHandler = true)
        assertEquals(SocialStep.OPEN_APP, steps.first())
        assertTrue(steps.contains(SocialStep.OPEN_COMPOSER))
        assertTrue(steps.contains(SocialStep.TYPE_POST_TEXT))
    }

    @Test
    fun `fallback plan asks the user to pick media`() {
        val task = SocialRequest(SocialPlatform.INSTAGRAM, SocialAction.POST_MEDIA).toTask("t4")
        val steps = SocialMediaPlan.stepsFor(task, hasShareHandler = false)
        assertTrue(steps.contains(SocialStep.TAP_CREATE))
        assertTrue(steps.contains(SocialStep.WAIT_FOR_USER_SELECT_MEDIA))
        assertTrue(!steps.contains(SocialStep.SHARE_MEDIA))
    }
}

class SocialMediaAgentTest {

    private fun instagramCaptionScreen(id: Long) = FakeScreenBuilder(id)
        .node(
            className = "android.widget.AutoCompleteTextView",
            id = "caption_input_text_view",
            editable = true,
            text = "Add a caption\u2026",
            y = 1400
        )
        .node(
            className = "android.widget.Button",
            id = "share_footer_button",
            desc = "Share",
            clickable = true,
            y = 1600
        )
        .build(windowStamp = id.toInt())

    private fun driver(vararg screens: ScreenObservation) = FakeScreenDriver(ArrayList(screens.toList()))

    @Test
    fun `missing accessibility service stops before anything`() {
        val host = FakeSocialHost(accessibilityEnabled = false)
        val agent = SocialMediaAgent(driver(), host, AgentConfig(), InstantClock())
        val outcome = agent.submit(SocialRequest(SocialPlatform.INSTAGRAM, SocialAction.POST_MEDIA))
        assertEquals(SocialResultCode.ACCESSIBILITY_NOT_ENABLED, (outcome as SocialOutcome.Finished).code)
    }

    @Test
    fun `instagram text post is unsupported`() {
        val host = FakeSocialHost()
        val agent = SocialMediaAgent(driver(), host, AgentConfig(), InstantClock())
        val outcome = agent.submit(
            SocialRequest(SocialPlatform.INSTAGRAM, SocialAction.POST_TEXT, caption = "hi")
        )
        assertEquals(SocialResultCode.UNSUPPORTED_ACTION, (outcome as SocialOutcome.Finished).code)
    }

    @Test
    fun `no media in the inbox asks the user to share it`() {
        val host = FakeSocialHost(media = emptyList())
        val agent = SocialMediaAgent(driver(), host, AgentConfig(), InstantClock())
        val outcome = agent.submit(SocialRequest(SocialPlatform.INSTAGRAM, SocialAction.POST_MEDIA))
        assertEquals(SocialResultCode.MEDIA_REQUIRED, (outcome as SocialOutcome.Finished).code)
    }

    @Test
    fun `no share handler is reported honestly`() {
        val media = listOf(
            PendingMedia("a", "content://com.myra.assistant.fileprovider/myra_inbox/a.jpg", "image/jpeg", 100, 1_700_000_000_000L)
        )
        val host = FakeSocialHost(media = media, activityClass = null)
        val agent = SocialMediaAgent(driver(), host, AgentConfig(), InstantClock())
        val outcome = agent.submit(SocialRequest(SocialPlatform.INSTAGRAM, SocialAction.POST_MEDIA))
        assertEquals(SocialResultCode.SHARE_TARGET_NOT_FOUND, (outcome as SocialOutcome.Finished).code)
    }

    @Test
    fun `publish requires an explicit confirm`() {
        val media = listOf(
            PendingMedia("a", "content://com.myra.assistant.fileprovider/myra_inbox/a.jpg", "image/jpeg", 100, 1_700_000_000_000L)
        )
        val screen = instagramCaptionScreen(1)
        val host = FakeSocialHost(media = media)
        val agent = SocialMediaAgent(driver(screen, screen, screen), host, AgentConfig(), InstantClock())

        val outcome = agent.submit(SocialRequest(SocialPlatform.INSTAGRAM, SocialAction.POST_MEDIA, caption = "hi"))
        assertTrue(outcome is SocialOutcome.AwaitingConfirmation)
        assertTrue(host.spoken.isNotEmpty())
    }

    @Test
    fun `draft mode never publishes`() {
        val media = listOf(
            PendingMedia("a", "content://com.myra.assistant.fileprovider/myra_inbox/a.jpg", "image/jpeg", 100, 1_700_000_000_000L)
        )
        val screen = instagramCaptionScreen(1)
        val host = FakeSocialHost(media = media)
        val agent = SocialMediaAgent(driver(screen, screen, screen), host, AgentConfig(), InstantClock())

        val outcome = agent.submit(
            SocialRequest(SocialPlatform.INSTAGRAM, SocialAction.POST_MEDIA, mode = SocialMode.DRAFT)
        )
        assertEquals(SocialResultCode.DRAFT_READY, (outcome as SocialOutcome.Finished).code)
    }

    @Test
    fun `reject reports rejected and never publishes`() {
        val media = listOf(
            PendingMedia("a", "content://com.myra.assistant.fileprovider/myra_inbox/a.jpg", "image/jpeg", 100, 1_700_000_000_000L)
        )
        val screen = instagramCaptionScreen(1)
        val host = FakeSocialHost(media = media)
        val agent = SocialMediaAgent(driver(screen, screen, screen), host, AgentConfig(), InstantClock())

        agent.submit(SocialRequest(SocialPlatform.INSTAGRAM, SocialAction.POST_MEDIA))
        val outcome = agent.control(SocialCommand.REJECT, null)
        assertEquals(SocialResultCode.REJECTED, (outcome as SocialOutcome.Finished).code)
    }

    @Test
    fun `resume after the user picks media continues without redoing the create step`() {
        val media = listOf(
            PendingMedia("a", "content://com.myra.assistant.fileprovider/myra_inbox/a.jpg", "image/jpeg", 100, 1_700_000_000_000L)
        )
        val picker = FakeScreenBuilder(1)
            .node(desc = "Recents", clickable = true, y = 200)
            .node(text = "Photo", clickable = true, y = 900)
            .build(windowStamp = 1)
        val host = FakeSocialHost(shareHandler = false, media = emptyList())
        val screenDriver = FakeScreenDriver(arrayListOf(picker))
        val agent = SocialMediaAgent(screenDriver, host, AgentConfig(), InstantClock())

        // The manual fallback lets the user pick inside the app, so an empty inbox is fine.
        val parked = agent.submit(SocialRequest(SocialPlatform.INSTAGRAM, SocialAction.POST_MEDIA))
        assertTrue(parked is SocialOutcome.NeedsUser)
        assertTrue(agent.waitingForUser)
        assertEquals(SocialStep.WAIT_FOR_USER_SELECT_MEDIA.name, agent.currentTask?.currentStep)
        assertTrue(agent.currentTask?.resumeStep?.isNotBlank() == true)

        // The user picked the photo, so the caption screen is live and the gate opens.
        screenDriver.addScreen(instagramCaptionScreen(2))
        val resumed = agent.submit(SocialRequest(SocialPlatform.INSTAGRAM, SocialAction.POST_MEDIA))
        assertTrue(resumed is SocialOutcome.AwaitingConfirmation)
        // OPEN_APP, TAP_CREATE and TAP_OPTION must not run a second time.
        assertEquals(TaskStatus.AWAITING_CONFIRMATION, agent.currentTask?.status)
        assertEquals(SocialStep.CONFIRM_PUBLISH.name, agent.currentTask?.currentStep)
    }

    @Test
    fun `confirming the gate publishes exactly once`() {
        val media = listOf(
            PendingMedia("a", "content://com.myra.assistant.fileprovider/myra_inbox/a.jpg", "image/jpeg", 100, 1_700_000_000_000L)
        )
        val screen = instagramCaptionScreen(1)
        val host = FakeSocialHost(media = media)
        val agent = SocialMediaAgent(driver(screen, screen, screen), host, AgentConfig(), InstantClock())

        val gate = agent.submit(SocialRequest(SocialPlatform.INSTAGRAM, SocialAction.POST_MEDIA, caption = "hi"))
        assertTrue(gate is SocialOutcome.AwaitingConfirmation)
        assertTrue(agent.awaitingConfirmation)
        assertTrue(host.spoken.isNotEmpty())

        val outcome = agent.control(SocialCommand.CONFIRM, null)
        assertTrue(outcome is SocialOutcome.Finished)
        assertEquals(AgentState.COMPLETED, agent.state)
        // A second confirm must not tap share again.
        val again = agent.control(SocialCommand.CONFIRM, null)
        assertEquals(TaskStatus.COMPLETED, agent.currentTask?.status)
        assertTrue(again is SocialOutcome.Finished)
    }

    @Test
    fun `cancel stops the task`() {
        val media = listOf(
            PendingMedia("a", "content://com.myra.assistant.fileprovider/myra_inbox/a.jpg", "image/jpeg", 100, 1_700_000_000_000L)
        )
        val screen = instagramCaptionScreen(1)
        val host = FakeSocialHost(media = media)
        val agent = SocialMediaAgent(driver(screen, screen, screen), host, AgentConfig(), InstantClock())

        agent.submit(SocialRequest(SocialPlatform.INSTAGRAM, SocialAction.POST_MEDIA))
        val outcome = agent.control(SocialCommand.CANCEL, null)
        assertEquals(SocialResultCode.CANCELLED, (outcome as SocialOutcome.Finished).code)
        assertEquals(AgentState.CANCELLED, agent.state)
    }

    @Test
    fun `status is reported without acting`() {
        val host = FakeSocialHost()
        val agent = SocialMediaAgent(driver(), host, AgentConfig(), InstantClock())
        val outcome = agent.control(SocialCommand.STATUS, null)
        assertTrue(outcome is SocialOutcome.Finished)
        assertTrue(host.spoken.isEmpty())
    }

    @Test
    fun `captcha stops the flow and asks for the user`() {
        val captcha = FakeScreenBuilder(1)
            .node(text = "Verify it's you", clickable = false, y = 200)
            .node(desc = "I'm not a robot", clickable = true, y = 800)
            .node(className = "android.widget.Button", desc = "Next", clickable = true, y = 1600)
            .build(windowStamp = 1)

        val guard = FlowGuards.check(captcha)
        assertTrue(guard is FlowGuards.GuardVerdict.Blocked)
        assertEquals(SocialResultCode.USER_ACTION_REQUIRED, (guard as FlowGuards.GuardVerdict.Blocked).code)
    }

    @Test
    fun `password screen is blocked`() {
        val login = FakeScreenBuilder(1)
            .node(className = "android.widget.EditText", password = true, editable = true, y = 300)
            .node(text = "Log in", clickable = true, y = 800)
            .build()
        val guard = FlowGuards.check(login)
        assertTrue(guard is FlowGuards.GuardVerdict.Blocked)
    }

    @Test
    fun `normal caption screen passes the guards`() {
        val guard = FlowGuards.check(instagramCaptionScreen(1))
        assertTrue(guard is FlowGuards.GuardVerdict.Clear)
    }
}
