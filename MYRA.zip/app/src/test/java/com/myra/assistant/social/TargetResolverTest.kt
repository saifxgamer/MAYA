package com.myra.assistant.social

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class TargetResolverTest {

    @Test
    fun `resource id wins over text`() {
        val screen = FakeScreenBuilder(1)
            .node(text = "Next", id = "com.instagram.android:id/other_button", x = 0)
            .node(text = "Next", id = "next_button_textview", x = 500, clickable = true)
            .build()

        val spec = TargetSpec(
            name = "next",
            resourceId = "next_button_textview",
            contentDescription = "Next"
        )
        val result = TargetResolver.resolve(screen, spec)
        assertTrue(result is ResolveResult.Resolved)
        assertEquals(500, result.elementOrNull!!.bounds.left)
        assertEquals(MatchStrategy.RESOURCE_ID, (result as ResolveResult.Resolved).strategy)
    }

    @Test
    fun `bare resource id matches full id`() {
        val screen = FakeScreenBuilder(1)
            .node(id = "com.instagram.android:id/caption_input_text_view", editable = true)
            .build()

        val spec = TargetSpec(
            name = "caption",
            resourceId = "caption_input_text_view",
            requireEditable = true,
            requireClickable = false
        )
        assertNotNull(TargetResolver.resolve(screen, spec).elementOrNull)
    }

    @Test
    fun `long feed caption never matches a short share hint`() {
        val caption = "Tap share with everyone you love today, this is the best day " +
            "ever and I am so happy about all of this wonderful news"
        val screen = FakeScreenBuilder(1)
            .node(text = caption, className = "android.widget.TextView", y = 10)
            .node(text = "Share", id = "share_footer_button", clickable = true, y = 900)
            .build()

        val byHint = TargetSpec(name = "hinted", shortLabelHint = "share", requireClickable = false)
        val result = TargetResolver.resolve(screen, byHint)
        assertNotNull("short Share button should still be found", result.elementOrNull)
        assertEquals("share_footer_button", TargetResolver.bareResourceId(result.elementOrNull!!.resourceId))

        val shareButtonOnly = TargetSpec(
            name = "share_only",
            text = "Share",
            requireClickable = true
        )
        val exact = TargetResolver.resolve(screen, shareButtonOnly)
        assertTrue(exact is ResolveResult.Resolved)
        assertEquals("Share", exact.elementOrNull!!.text)
    }

    @Test
    fun `hint does not match a long label`() {
        val screen = FakeScreenBuilder(1)
            .node(text = "share_footer_button_hide_this_is_a_very_long_label_over_forty_eight_chars", clickable = true)
            .build()
        val spec = TargetSpec(name = "x", shortLabelHint = "share")
        assertNull(TargetResolver.resolve(screen, spec).elementOrNull)
    }

    @Test
    fun `normalized text tolerates punctuation and ellipsis`() {
        val screen = FakeScreenBuilder(1)
            .node(text = "What\u2019s on your mind\u2026", className = "android.widget.Button", clickable = true)
            .build()
        val spec = TargetSpec(name = "composer", text = "What's on your mind?")
        val result = TargetResolver.resolve(screen, spec)
        assertNotNull(result.elementOrNull)
        assertEquals(MatchStrategy.TEXT_NORMALIZED, (result as ResolveResult.Resolved).strategy)
    }

    @Test
    fun `disabled element is rejected when enabled is required`() {
        val screen = FakeScreenBuilder(1)
            .node(text = "Next", clickable = true, enabled = false)
            .build()
        val spec = TargetSpec(name = "next", text = "Next")
        assertTrue(TargetResolver.resolve(screen, spec) is ResolveResult.NotFound)
    }

    @Test
    fun `non clickable title is rejected for a tap spec`() {
        val screen = FakeScreenBuilder(1)
            .node(text = "New post", className = "android.widget.TextView", y = 100, clickable = false)
            .build()
        val spec = TargetSpec(name = "create", text = "New post", requireClickable = true)
        assertTrue(TargetResolver.resolve(screen, spec) is ResolveResult.NotFound)
    }

    @Test
    fun `read only indicator is allowed when clickable is not required`() {
        val screen = FakeScreenBuilder(1)
            .node(text = "Posting\u2026", className = "android.widget.TextView", y = 100)
            .build()
        val spec = TargetSpec(name = "posting", text = "Posting\u2026", requireClickable = false)
        assertNotNull(TargetResolver.resolve(screen, spec).elementOrNull)
    }

    @Test
    fun `post settings SHARE is not confused with story or group rows`() {
        val screen = FakeScreenBuilder(1)
            .node(desc = "SHARE", clickable = true, y = 100, x = 0)
            .node(text = "Share to story...", clickable = true, y = 200, x = 0)
            .node(text = "Share to groups...", clickable = true, y = 300, x = 0)
            .build()
        val spec = TargetSpec(
            name = "fb_post_settings_share",
            contentDescription = "SHARE",
            text = "Share",
            excludeTexts = listOf("Share to story...", "Share to groups..."),
            requireUniqueMatch = true
        )
        val result = TargetResolver.resolve(screen, spec)
        assertTrue(result is ResolveResult.Resolved)
        assertEquals("SHARE", result.elementOrNull!!.contentDescription)
    }

    @Test
    fun `structural anchor finds unlabeled create left of home feed title`() {
        val screen = FakeScreenBuilder(1)
            .node(className = "android.widget.ImageView", x = 40, y = 60, w = 48, h = 48, clickable = true)
            .node(
                desc = "Instagram Home Feed",
                id = "title_logo",
                x = 140, y = 60, w = 120, h = 48
            )
            .node(className = "android.widget.ImageView", x = 800, y = 1400, clickable = true)
            .build()

        val spec = TargetSpec(
            name = "ig_create",
            anchor = StructuralAnchor(
                referenceContentDescription = "Instagram Home Feed",
                candidateClassNames = setOf("ImageView"),
                relation = AnchorRelation.LEFT_OF,
                requireCandidateClickable = true,
                requireSameRow = true
            )
        )
        val result = TargetResolver.resolve(screen, spec)
        assertTrue(result is ResolveResult.Resolved)
        assertEquals(40, result.elementOrNull!!.bounds.left)
        assertEquals(MatchStrategy.STRUCTURAL_ANCHOR, (result as ResolveResult.Resolved).strategy)
    }

    @Test
    fun `structural anchor fails when the reference is absent`() {
        val screen = FakeScreenBuilder(1)
            .node(className = "android.widget.ImageView", x = 40, y = 60, clickable = true)
            .build()
        val spec = TargetSpec(
            name = "ig_create",
            anchor = StructuralAnchor(referenceContentDescription = "Instagram Home Feed")
        )
        assertTrue(TargetResolver.resolve(screen, spec) is ResolveResult.NotFound)
    }

    @Test
    fun `anchor does not match when the candidate is on another row`() {
        val screen = FakeScreenBuilder(1)
            .node(className = "android.widget.ImageView", x = 40, y = 800, clickable = true)
            .node(desc = "Instagram Home Feed", x = 140, y = 60)
            .build()
        val spec = TargetSpec(
            name = "ig_create",
            anchor = StructuralAnchor(
                referenceContentDescription = "Instagram Home Feed",
                candidateClassNames = setOf("ImageView"),
                requireSameRow = true
            )
        )
        assertTrue(TargetResolver.resolve(screen, spec) is ResolveResult.NotFound)
    }

    @Test
    fun `anchor respects vertical relations`() {
        val screen = FakeScreenBuilder(1)
            .node(desc = "Add to story", x = 0, y = 100, w = 200, h = 40)
            .node(text = "Your story", clickable = true, x = 0, y = 20, w = 200, h = 40)
            .build()
        val spec = TargetSpec(
            name = "above",
            anchor = StructuralAnchor(
                referenceContentDescription = "Add to story",
                candidateClassNames = setOf("Button"),
                relation = AnchorRelation.ABOVE
            )
        )
        assertTrue(TargetResolver.resolve(screen, spec) is ResolveResult.NotFound)

        val spec2 = TargetSpec(
            name = "below",
            text = "Your story",
            requireClickable = true,
            anchor = StructuralAnchor(
                referenceContentDescription = "Add to story",
                candidateClassNames = setOf("Button"),
                relation = AnchorRelation.BELOW
            )
        )
        assertTrue(TargetResolver.resolve(screen, spec2) is ResolveResult.Resolved)
    }

    @Test
    fun `password element is never returned`() {
        val screen = FakeScreenBuilder(1)
            .node(text = "secret", password = true, editable = true, className = "android.widget.EditText")
            .build()
        val spec = TargetSpec(
            name = "field",
            className = "EditText",
            requireEditable = true,
            requireClickable = false
        )
        assertTrue(TargetResolver.resolve(screen, spec) is ResolveResult.NotFound)
    }

    @Test
    fun `offscreen element is rejected`() {
        val screen = FakeScreenBuilder(1)
            .node(text = "Next", clickable = true, x = 0, y = 1900, w = 100, h = 48)
            .build()
        val spec = TargetSpec(name = "next", text = "Next")
        assertTrue(TargetResolver.resolve(screen, spec) is ResolveResult.NotFound)
    }

    @Test
    fun `bottom edge element is still accepted`() {
        val screen = FakeScreenBuilder(1)
            .node(text = "Next", clickable = true, x = 0, y = 1700, w = 100, h = 48)
            .build()
        val spec = TargetSpec(name = "next", text = "Next")
        assertTrue(TargetResolver.resolve(screen, spec) is ResolveResult.Resolved)
    }

    @Test
    fun `package allow list blocks other apps`() {
        val screen = FakeScreenBuilder(1)
            .node(text = "Share", clickable = true, packageName = "com.facebook.katana")
            .build()
        val spec = TargetSpec(name = "share", text = "Share")
        val result = TargetResolver.resolve(
            screen, spec, allowedPackages = setOf("com.instagram.android")
        )
        assertTrue(result is ResolveResult.NotFound)
    }

    @Test
    fun `requireUniqueMatch reports ambiguity`() {
        val screen = FakeScreenBuilder(1)
            .node(text = "SHARE", clickable = true, y = 100)
            .node(text = "SHARE", clickable = true, y = 800)
            .build()
        val spec = TargetSpec(name = "share", text = "SHARE", requireUniqueMatch = true)
        assertTrue(TargetResolver.resolve(screen, spec) is ResolveResult.Ambiguous)
    }

    @Test
    fun `structural signature changes when the screen really changes`() {
        val a = FakeScreenBuilder(1).node(text = "Next", clickable = true).build()
        val b = FakeScreenBuilder(2).node(text = "Share", clickable = true).build()
        val c = FakeScreenBuilder(3).node(text = "Next", clickable = true).build()
        assertTrue(a.structuralSignature != b.structuralSignature)
        assertTrue(a.structuralSignature == c.structuralSignature)
    }
}
