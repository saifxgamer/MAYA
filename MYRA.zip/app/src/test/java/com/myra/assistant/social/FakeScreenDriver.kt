package com.myra.assistant.social

class FakeScreenBuilder(private val observationId: Long) {
    private val elements = ArrayList<UiElement>()

    fun node(
        text: String = "",
        desc: String = "",
        hint: String = "",
        id: String = "",
        className: String = "android.widget.TextView",
        x: Int = 0,
        y: Int = 0,
        w: Int = 100,
        h: Int = 48,
        clickable: Boolean = false,
        longClickable: Boolean = false,
        enabled: Boolean = true,
        selected: Boolean = false,
        scrollable: Boolean = false,
        editable: Boolean = false,
        password: Boolean = false,
        visible: Boolean = true,
        packageName: String = "com.instagram.android",
        parentIndex: Int = -1,
        parentPath: String = "root"
    ): FakeScreenBuilder {
        val index = elements.size
        elements += UiElement(
            elementId = "$observationId#$index",
            observationId = observationId,
            index = index,
            packageName = packageName,
            className = className,
            text = text,
            contentDescription = desc,
            hintText = hint,
            resourceId = id,
            bounds = ElementBounds(x, y, x + w, y + h),
            clickable = clickable,
            longClickable = longClickable,
            enabled = enabled,
            selected = selected,
            focused = false,
            focusable = editable,
            scrollable = scrollable,
            editable = editable,
            checkable = false,
            checked = false,
            password = password,
            visible = visible,
            depth = 1,
            parentIndex = parentIndex,
            parentPath = parentPath
        )
        return this
    }

    fun build(
        packageName: String = "com.instagram.android",
        windowClass: String = "WINDOW",
        width: Int = 1080,
        height: Int = 1920,
        eventStamp: Long = observationId,
        windowStamp: Int = observationId.toInt()
    ): ScreenObservation = ScreenObservation(
        observationId = observationId,
        packageName = packageName,
        windowClass = windowClass,
        screenWidth = width,
        screenHeight = height,
        eventStamp = eventStamp,
        windowStamp = windowStamp,
        capturedAtMs = observationId * 1000,
        elements = elements.toList()
    )
}

class InstantClock(private var now: Long = 0L) : AgentClock {
    var sleepCalls = 0
        private set

    override fun nowMs(): Long = now

    override fun sleep(ms: Long) {
        sleepCalls++
        now += if (ms > 0) ms else 1
    }

    fun advance(ms: Long) {
        now += ms
    }
}

class FakeScreenDriver(
    private val screens: MutableList<ScreenObservation> = ArrayList(),
    var packageName: String = "com.instagram.android",
    var windowClass: String = "WINDOW",
    var uiStamp: Long = 0L,
    var windowCounter: Int = 0
) : ScreenDriver {

    private var idCounter = 0L
    private var latestId = 0L
    private var available = true
    private var clickBehaviour: (String) -> Boolean = { true }
    private val tapLog = ArrayList<String>()
    private val setTextLog = ArrayList<Pair<String, String>>()
    private val focusLog = ArrayList<String>()
    private val scrollLog = ArrayList<String>()

    fun addScreen(observation: ScreenObservation) {
        screens += observation
    }

    fun setAvailable(value: Boolean) {
        available = value
    }

    fun setClickBehaviour(behaviour: (String) -> Boolean) {
        clickBehaviour = behaviour
    }

    fun taps(): List<String> = tapLog.toList()
    fun typedText(): List<Pair<String, String>> = setTextLog.toList()
    fun focused(): List<String> = focusLog.toList()
    fun scrolled(): List<String> = scrollLog.toList()

    fun nextObservation(): ScreenObservation {
        if (screens.isEmpty()) {
            idCounter++
            latestId = idCounter
            return FakeScreenBuilder(idCounter)
                .node(text = "empty", w = 10, h = 10)
                .build(packageName, windowClass, eventStamp = uiStamp, windowStamp = windowCounter)
        }
        val chosen = if (screens.size == 1) screens[0] else screens[minOf(idCounter.toInt(), screens.size - 1)]
        idCounter++
        latestId = chosen.observationId
        return chosen
    }

    override fun isAvailable(): Boolean = available

    override fun observe(): ScreenObservation {
        uiStamp = latestId
        return nextObservation()
    }

    override fun currentPackageName(): String = packageName

    override fun currentWindowClass(): String = windowClass

    override fun uiEventStamp(): Long = uiStamp

    override fun windowStamp(): Int = windowCounter

    override fun latestObservationId(): Long = latestId

    override fun screenSize(): Pair<Int, Int> = 1080 to 1920

    override fun click(elementId: String): ActionResult {
        val ok = clickBehaviour(elementId)
        return if (ok) {
            tapLog += "click:$elementId"
            invalidateObservations()
            ActionResult.ok(true)
        } else {
            ActionResult.fail(ActionFailure.NOT_CLICKABLE, "faked refusal")
        }
    }

    override fun gestureTap(elementId: String): ActionResult {
        tapLog += "gesture:$elementId"
        invalidateObservations()
        return ActionResult.ok(true)
    }

    override fun focus(elementId: String): ActionResult {
        focusLog += elementId
        return ActionResult.ok(true)
    }

    override fun setText(elementId: String, text: String): ActionResult {
        setTextLog += elementId to text
        return ActionResult.ok(true)
    }

    override fun scroll(elementId: String, direction: ScrollDirection, amountPx: Int): ActionResult {
        scrollLog += "$elementId:$direction"
        invalidateObservations()
        return ActionResult.ok(true)
    }

    override fun invalidateObservations() {
        idCounter += 1
        latestId = idCounter
    }

    override fun awaitUiChange(timeoutMs: Long): Boolean = true
}
