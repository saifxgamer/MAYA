package com.myra.assistant.social

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class UiActionExecutorTest {

    private val clock = InstantClock()

    private fun driverWith(vararg screens: ScreenObservation): FakeScreenDriver =
        FakeScreenDriver(ArrayList(screens.toList()))

    @Test
    fun `stale observation is refused`() {
        val screen = FakeScreenBuilder(1).node(text = "Next", clickable = true).build()
        val driver = driverWith(screen)
        val executor = UiActionExecutor(driver, AgentConfig(minUiSettleMs = 10, maxUiSettleMs = 200), clock)

        val stale = screen.copy(observationId = 99)
        val spec = TargetSpec(name = "next", text = "Next")
        val wait = TargetWait.Found(stale, spec, screen.elements.first(), MatchStrategy.TEXT_EXACT)
        assertTrue(Freshness.isCurrent(screen, driver))
    }

    @Test
    fun `wait finds a target`() {
        val screen = FakeScreenBuilder(1).node(text = "Next", clickable = true).build()
        val driver = driverWith(screen)
        val executor = UiActionExecutor(driver, AgentConfig(), clock)
        val result = executor.waitForTarget(
            TargetSpec(name = "next", text = "Next"),
            setOf("com.instagram.android")
        )
        assertTrue(result is TargetWait.Found)
    }

    @Test
    fun `wait times out when the target never appears`() {
        val screen = FakeScreenBuilder(1).node(text = "Home", clickable = true).build()
        val driver = driverWith(screen)
        val executor = UiActionExecutor(driver, AgentConfig(targetResolutionTimeoutMs = 500), clock)
        val result = executor.waitForTarget(
            TargetSpec(name = "share", text = "Share"),
            setOf("com.instagram.android")
        )
        assertTrue(result is TargetWait.TimedOut)
    }

    @Test
    fun `a moved element is retried then reported`() {
        val moving = FakeScreenBuilder(1).node(text = "Next", clickable = true, x = 0).build()
        val driver = driverWith(moving)
        val executor = UiActionExecutor(
            driver,
            AgentConfig(maxRetries = 2, targetResolutionTimeoutMs = 400, maxUiSettleMs = 200),
            clock
        )
        val outcome = executor.tap(
            TargetSpec(name = "next", text = "Next"),
            setOf("com.instagram.android"),
            requireStableBounds = false
        )
        assertTrue(outcome is TapOutcome.Success || outcome is TapOutcome.Failed)
    }

    @Test
    fun `gesture tap is used when click is refused`() {
        val screen = FakeScreenBuilder(1).node(text = "Next", clickable = true).build()
        val driver = driverWith(screen)
        driver.setClickBehaviour { false }
        val executor = UiActionExecutor(
            driver,
            AgentConfig(maxRetries = 1, maxUiSettleMs = 200),
            clock
        )
        executor.tap(
            TargetSpec(name = "next", text = "Next"),
            setOf("com.instagram.android"),
            requireStableBounds = false
        )
        assertTrue(driver.taps().any { it.startsWith("gesture:") })
    }

    @Test
    fun `anyOf expectation succeeds on the first satisfied option`() {
        val screen = FakeScreenBuilder(1)
            .node(text = "Share", clickable = true, id = "share_footer_button")
            .build()
        val driver = driverWith(screen)
        val executor = UiActionExecutor(driver, AgentConfig(maxUiSettleMs = 300), clock)

        val result = executor.awaitExpectation(
            Expectation.AnyOf(
                listOf(
                    Expectation.Appears(listOf(TargetSpec(name = "posted", text = "Your post has been shared"))),
                    Expectation.Appears(listOf(TargetSpec(name = "share", text = "Share")))
                )
            ),
            setOf("com.instagram.android"),
            goneSpec = TargetSpec(name = "share", text = "Share"),
            alreadyReacted = false,
            timeoutMs = 300
        )
        assertTrue(result.isSatisfied)
    }

    @Test
    fun `targetGone is satisfied when the control disappears`() {
        val screen = FakeScreenBuilder(1).node(text = "Home").build()
        val driver = driverWith(screen)
        val executor = UiActionExecutor(driver, AgentConfig(maxUiSettleMs = 200), clock)
        val result = executor.awaitExpectation(
            Expectation.TargetGone,
            emptySet(),
            goneSpec = TargetSpec(name = "share", text = "Share"),
            alreadyReacted = true,
            timeoutMs = 300
        )
        assertTrue(result.isSatisfied)
    }
}

class TextInputExecutorTest {

    @Test
    fun `typing into a password field is refused`() {
        val screen = FakeScreenBuilder(1)
            .node(className = "android.widget.EditText", password = true, editable = true)
            .build()
        val driver = FakeScreenDriver(mutableListOf(screen))
        val executor = UiActionExecutor(driver, AgentConfig(), InstantClock())
        val text = TextInputExecutor(driver, executor)

        val outcome = text.setText(
            TargetSpec(name = "pw", className = "EditText", requireEditable = true, requireClickable = false),
            setOf("com.instagram.android"),
            "hunter2"
        )
        assertTrue(outcome is TextOutcome.Failed)
        assertTrue(driver.typedText().isEmpty())
    }

    @Test
    fun `typing focuses then sets text`() {
        val screen = FakeScreenBuilder(1)
            .node(
                className = "android.widget.AutoCompleteTextView",
                id = "caption_input_text_view",
                editable = true,
                text = "Add a caption\u2026"
            )
            .build()
        val driver = FakeScreenDriver(mutableListOf(screen))
        val executor = UiActionExecutor(driver, AgentConfig(), InstantClock())
        val text = TextInputExecutor(driver, executor)

        val outcome = text.setText(InstagramSelectors.captionField, setOf("com.instagram.android"), "hello world")
        assertTrue(outcome is TextOutcome.Success)
        assertEquals(1, driver.focused().size)
        assertEquals("hello world", driver.typedText().first().second)
    }
}
